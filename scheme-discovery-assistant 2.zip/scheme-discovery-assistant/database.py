"""
Database initialization and dummy data seeder for Scheme Discovery Assistant.
Uses SQLite to store users, schemes, applications, documents, notifications, and help centers.
"""

import sqlite3
import os
import json
from datetime import datetime
from werkzeug.security import generate_password_hash

DB_PATH = os.path.join(os.path.dirname(__file__), "schemes.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()

    # 1. Users Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            phone TEXT,
            state TEXT DEFAULT 'All India',
            district TEXT DEFAULT '',
            age INTEGER DEFAULT 25,
            gender TEXT DEFAULT 'All',
            occupation TEXT DEFAULT 'General',
            annual_income REAL DEFAULT 200000,
            social_category TEXT DEFAULT 'General',
            education_level TEXT DEFAULT 'Graduate',
            is_disabled INTEGER DEFAULT 0,
            is_student INTEGER DEFAULT 0,
            is_farmer INTEGER DEFAULT 0,
            avatar_url TEXT DEFAULT '/static/img/avatar.png',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # 2. Schemes Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS schemes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            code TEXT UNIQUE,
            department TEXT NOT NULL,
            category TEXT NOT NULL,
            state TEXT NOT NULL,
            brief TEXT NOT NULL,
            description TEXT NOT NULL,
            benefits TEXT NOT NULL,
            benefit_amount REAL DEFAULT 0,
            benefit_type TEXT DEFAULT 'Financial Grant',
            min_age INTEGER DEFAULT 0,
            max_age INTEGER DEFAULT 120,
            allowed_genders TEXT DEFAULT 'All',
            eligible_occupations TEXT DEFAULT 'All',
            max_income REAL DEFAULT 10000000,
            eligible_categories TEXT DEFAULT 'All',
            eligible_states TEXT DEFAULT 'All India',
            required_docs TEXT NOT NULL,
            application_url TEXT NOT NULL,
            deadline TEXT DEFAULT 'Open Year-Round',
            processing_time TEXT DEFAULT '15-30 Days',
            helpline TEXT DEFAULT '1800-111-555',
            featured INTEGER DEFAULT 0,
            popularity_score INTEGER DEFAULT 85,
            match_score_default INTEGER DEFAULT 85,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # 3. Applications Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            scheme_id INTEGER NOT NULL,
            application_no TEXT UNIQUE NOT NULL,
            status TEXT DEFAULT 'Submitted',
            stage_index INTEGER DEFAULT 1,
            total_stages INTEGER DEFAULT 4,
            submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            notes TEXT,
            timeline_json TEXT,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (scheme_id) REFERENCES schemes (id)
        )
    """)

    # 4. Documents Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            doc_type TEXT NOT NULL,
            title TEXT NOT NULL,
            file_name TEXT NOT NULL,
            file_path TEXT NOT NULL,
            file_size TEXT DEFAULT '1.2 MB',
            status TEXT DEFAULT 'Verified',
            issue_date TEXT,
            expiry_date TEXT,
            doc_number TEXT,
            uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    """)

    # 5. Saved Schemes Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS saved_schemes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            scheme_id INTEGER NOT NULL,
            saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(user_id, scheme_id),
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (scheme_id) REFERENCES schemes (id)
        )
    """)

    # 6. Notifications Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            category TEXT DEFAULT 'Scheme Alert',
            action_url TEXT DEFAULT '/dashboard',
            is_read INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    """)

    # 7. Help Centers Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS help_centers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            center_type TEXT NOT NULL,
            state TEXT NOT NULL,
            district TEXT NOT NULL,
            city TEXT NOT NULL,
            pincode TEXT NOT NULL,
            address TEXT NOT NULL,
            contact_person TEXT,
            phone TEXT NOT NULL,
            email TEXT,
            timings TEXT DEFAULT 'Mon - Sat: 9:30 AM - 6:00 PM',
            services TEXT NOT NULL,
            latitude REAL,
            longitude REAL,
            rating REAL DEFAULT 4.8
        )
    """)

    conn.commit()

    # Seed data if empty
    seed_data(conn)
    conn.close()

def seed_data(conn):
    cursor = conn.cursor()

    # Check if demo user exists
    cursor.execute("SELECT id FROM users WHERE email = ?", ("citizen@example.com",))
    user_row = cursor.fetchone()

    user_id = None
    if not user_row:
        pw_hash = generate_password_hash("Password@123")
        cursor.execute("""
            INSERT INTO users (full_name, email, password_hash, phone, state, district, age, gender, occupation, annual_income, social_category, education_level, is_disabled, is_student, is_farmer)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "Ramesh Kannan",
            "citizen@example.com",
            pw_hash,
            "+91 98765 43210",
            "Tamil Nadu",
            "Chennai",
            28,
            "Male",
            "Small Business Owner",
            180000,
            "OBC",
            "Graduate",
            0,
            0,
            1
        ))
        user_id = cursor.lastrowid
    else:
        user_id = user_row[0]

    # Seed Schemes
    cursor.execute("SELECT count(*) FROM schemes")
    if cursor.fetchone()[0] == 0:
        schemes_data = [
            (
                "PM-Kisan Samman Nidhi",
                "PMKISAN-2026",
                "Ministry of Agriculture and Farmers Welfare",
                "Agriculture",
                "All India",
                "Direct financial benefit of ₹6,000 per year in three equal installments to eligible landholding farmer families.",
                "Pradhan Mantri Kisan Samman Nidhi (PM-KISAN) is a Central Sector scheme with 100% funding from Government of India. The fund is directly transferred to the bank accounts of the beneficiaries through Direct Benefit Transfer (DBT) mode.",
                "₹6,000 per annum (₹2,000 every 4 months)",
                6000,
                "Direct Benefit Transfer",
                18,
                75,
                "All",
                "Farmer,Agricultural Worker,Small Farmer",
                400000,
                "All",
                "All India",
                "Aadhaar Card,Land Ownership Document (Patta/Chitta),Bank Passbook with IFSC,Active Mobile Number",
                "https://pmkisan.gov.in",
                "Open Year-Round",
                "15 Days",
                "155261 / 1800-115-526",
                1,
                98,
                96
            ),
            (
                "Post-Matric Scholarship for SC/ST/OBC Students",
                "PMS-EDU-2026",
                "Ministry of Social Justice and Empowerment",
                "Education",
                "All India",
                "Full tuition fee waiver and maintenance allowance for post-secondary education students.",
                "A flagship initiative aimed at supporting meritorious students from disadvantaged backgrounds to pursue higher education, covering university fees, books, study tours, and monthly maintenance allowance.",
                "100% Tuition Fee + ₹13,500/yr Living Allowance",
                45000,
                "Scholarship & Fee Reimbursement",
                16,
                35,
                "All",
                "Student,Unemployed Youth",
                250000,
                "SC,ST,OBC,EWS",
                "All India",
                "Aadhaar Card,Community Certificate,Income Certificate (Tahshildar),College Admission Proof,Previous Marksheet,Bank Passbook",
                "https://scholarships.gov.in",
                "31 October 2026",
                "20-30 Days",
                "0120-6619540",
                1,
                95,
                94
            ),
            (
                "Kalaignar Magalir Urimai Thogai",
                "KMUT-TN-2026",
                "Department of Social Welfare, Tamil Nadu",
                "Women & Child",
                "Tamil Nadu",
                "Monthly basic income entitlement of ₹1,000 directly credited to bank accounts of female heads of households.",
                "Tamil Nadu Government's historic basic income assistance program to recognize the unpaid domestic labor of women and support family livelihood. Empowered more than 1.15 Crore women across the state.",
                "₹1,000 per month (₹12,000 annually)",
                12000,
                "Monthly Direct Transfer",
                21,
                65,
                "Female",
                "Homemaker,Self Employed,Daily Wage Worker,Agricultural Worker",
                250000,
                "All",
                "Tamil Nadu",
                "Smart Ration Card (Family Card),Aadhaar Card,Aadhaar-Linked Bank Account Passbook,Electricity Consumer Number",
                "https://kmut.tn.gov.in",
                "Open for Registration",
                "10-20 Days",
                "044-25619222",
                1,
                99,
                92
            ),
            (
                "Pudhumai Penn Scheme (Moovalur Ramamirtham Ammaiyar)",
                "TN-PUDHUMAI-2026",
                "Social Welfare and Women Empowerment, Tamil Nadu",
                "Education",
                "Tamil Nadu",
                "Monthly assistance of ₹1,000 for girl students pursuing undergraduate degree, diploma, or ITI courses.",
                "Assists girl students who studied classes 6 to 12 in Government schools of Tamil Nadu to complete higher education without financial distress, significantly raising female gross enrollment ratios.",
                "₹1,000 per month till course completion",
                36000,
                "Monthly Educational Stipend",
                17,
                24,
                "Female",
                "Student",
                300000,
                "All",
                "Tamil Nadu",
                "Govt School Study Certificate (6th-12th),College Admission ID,Aadhaar Card,Bank Passbook with single holder name",
                "https://pudhumaipenn.tn.gov.in",
                "Active Semester Intake",
                "15 Days",
                "1800-425-4567",
                1,
                94,
                90
            ),
            (
                "Ayushman Bharat - PM Jan Arogya Yojana (PM-JAY)",
                "PMJAY-HEALTH-2026",
                "National Health Authority",
                "Healthcare",
                "All India",
                "Cashless health insurance cover of up to ₹5,00,000 per family per year for secondary and tertiary hospitalization.",
                "The world's largest government-funded health assurance scheme. Covers over 12 crore poor and vulnerable families (approximately 55 crore beneficiaries) across 27,000+ empaneled public and private hospitals.",
                "₹5,00,000 cashless health insurance cover per family/year",
                500000,
                "Health Insurance Coverage",
                0,
                110,
                "All",
                "All",
                300000,
                "All",
                "All India",
                "Aadhaar Card,Ration Card / SECC 2011 Confirmation,Family Identity Card",
                "https://pmjay.gov.in",
                "Open Year-Round",
                "Instant Card Generation",
                "14555 / 1800-111-565",
                1,
                99,
                98
            ),
            (
                "Pradhan Mantri Mudra Yojana (PMMY)",
                "MUDRA-LOAN-2026",
                "Department of Financial Services",
                "Business & MSME",
                "All India",
                "Collateral-free micro loans up to ₹20,00,000 for small businesses, trading, service, and manufacturing units.",
                "Provides institutional credit to micro-enterprises under three categories: Shishu (up to ₹50,000), Kishore (₹50,000 to ₹5,00,000), and Tarun/Tarun Plus (up to ₹20,00,000) at subsidized interest rates without collateral security.",
                "Collateral-free loan from ₹50,000 up to ₹20,00,000",
                500000,
                "Subsidized Business Loan",
                18,
                65,
                "All",
                "Self Employed,Artisan,Shopkeeper,Small Business Owner,Entrepreneur",
                1500000,
                "All",
                "All India",
                "Aadhaar Card,PAN Card,Business Registration / Udyam Certificate,Last 6 Months Bank Statement,Business Plan Brief",
                "https://mudra.org.in",
                "Open Year-Round",
                "7-14 Days",
                "1800-180-1111",
                1,
                92,
                88
            ),
            (
                "PM Surya Ghar: Muft Bijli Yojana",
                "SURYA-GHAR-2026",
                "Ministry of New and Renewable Energy",
                "Housing",
                "All India",
                "Up to ₹78,000 direct central financial assistance for installing residential rooftop solar panels with free electricity.",
                "Enables households to install 1 to 3 kW rooftop solar plants, offering up to 300 units of free power each month and allowing citizens to sell surplus green electricity back to grid distribution companies (DISCOMs).",
                "Subsidy up to ₹78,000 + 300 Free Units Electricity/Month",
                78000,
                "Capital Subsidy & Clean Energy",
                18,
                100,
                "All",
                "All",
                1200000,
                "All",
                "All India",
                "Electricity Bill with Consumer Account,House Ownership Proof / Registered Deed,Aadhaar Card,Bank Passbook",
                "https://pmsuryaghar.gov.in",
                "Open for Rooftop Installations",
                "30 Days",
                "15555",
                1,
                90,
                87
            ),
            (
                "PM Vishwakarma Scheme",
                "VISHWAKARMA-2026",
                "Ministry of Micro, Small and Medium Enterprises",
                "Business & MSME",
                "All India",
                "Skill training, ₹15,000 toolkit incentive, and collateral-free enterprise credit up to ₹3,00,000 at 5% interest.",
                "Holistic end-to-end support for traditional artisans and craftspeople working with hands and tools across 18 trades including carpenters, boat makers, blacksmiths, goldsmiths, potters, sculptors, and cobblers.",
                "₹15,000 Modern Toolkit + ₹3,00,000 Loan @ 5% interest",
                315000,
                "Skill Grant & Concessional Credit",
                18,
                65,
                "All",
                "Artisan,Craftsperson,Carpenter,Tailor,Potter,Blacksmith,Mason",
                400000,
                "All",
                "All India",
                "Aadhaar Card,Artisan Trade Proof,Mobile linked with Aadhaar,Bank Account Details,Ration Card",
                "https://pmvishwakarma.gov.in",
                "Open Year-Round",
                "15-20 Days",
                "1800-267-7777",
                1,
                89,
                85
            ),
            (
                "Sukanya Samriddhi Yojana (SSY)",
                "SSY-GIRL-2026",
                "Ministry of Finance / India Post",
                "Women & Child",
                "All India",
                "High-interest (8.2%) government-backed savings scheme for girl children with complete tax exemption under Section 80C.",
                "Small savings deposit scheme launched as part of Beti Bachao Beti Padhao campaign. Can be opened by parents/guardians for a girl child before she attains 10 years of age with sovereign guarantee.",
                "Guaranteed 8.2% Compound Interest + Tax-Free Maturity",
                150000,
                "High Yield Savings & Sovereign Protection",
                0,
                10,
                "Female",
                "Child,Student",
                10000000,
                "All",
                "All India",
                "Birth Certificate of Girl Child,Parent/Guardian Aadhaar & PAN Card,Address Proof,Recent Passport Photos",
                "https://indiapost.gov.in",
                "Open Year-Round",
                "Same Day at Post Office/Bank",
                "1800-266-6868",
                0,
                91,
                84
            ),
            (
                "PM Awas Yojana - Urban & Gramin (PMAY)",
                "PMAY-HOUSING-2026",
                "Ministry of Housing and Urban Affairs",
                "Housing",
                "All India",
                "Financial assistance of up to ₹2.67 Lakh as interest subsidy / direct grant for pucca house construction.",
                "Ensures every eligible homeless family or those living in kutcha/dilapidated houses get an all-weather permanent house equipped with basic amenities such as clean water, toilet, and electricity connection.",
                "Direct subsidy grant of up to ₹2,67,000 for home construction",
                267000,
                "Direct Housing Grant & Interest Subsidy",
                21,
                70,
                "All",
                "All",
                300000,
                "All",
                "All India",
                "Aadhaar Card of all family members,Income Certificate,Land Document / NOC,Affidavit of No Pucca House,Bank Account",
                "https://pmaymis.gov.in",
                "Active Sanctions Phase",
                "45-60 Days",
                "1800-11-3377",
                1,
                96,
                91
            ),
            (
                "PM SVANidhi (Street Vendor's AtmaNirbhar Nidhi)",
                "PMSVANIDHI-2026",
                "Ministry of Housing and Urban Affairs",
                "Business & MSME",
                "All India",
                "Affordable working capital loans of ₹10,000, ₹20,000 and ₹50,000 with 7% interest subsidy and cashback on digital transactions.",
                "Special micro-credit facility empowering urban, peri-urban, and rural street vendors to resume their livelihoods with formal bank credit and digital payment adoption.",
                "Working capital loans up to ₹50,000 + 7% Interest Subsidy",
                50000,
                "Working Capital Loan",
                18,
                70,
                "All",
                "Street Vendor,Hawker,Daily Wage Worker",
                200000,
                "All",
                "All India",
                "Aadhaar Card,Vending Certificate / Urban Local Body ID,Bank Passbook,Mobile linked with Aadhaar",
                "https://pmsvanidhi.mohua.gov.in",
                "Open Year-Round",
                "5-10 Days",
                "1800-11-1979",
                0,
                88,
                83
            ),
            (
                "Atal Pension Yojana (APY)",
                "APY-PENSION-2026",
                "Pension Fund Regulatory and Development Authority",
                "Senior Citizens",
                "All India",
                "Guaranteed monthly pension of ₹1,000 to ₹5,000 after age 60 for unorganized sector workers.",
                "Social security scheme administered by PFRDA through NPS architecture. Government guarantees minimum pension yield with survivor benefits for spouse and nominee return of wealth corpus.",
                "Guaranteed monthly pension of up to ₹5,000 for life",
                60000,
                "Guaranteed Monthly Pension",
                18,
                40,
                "All",
                "Informal Worker,Daily Wage Worker,Self Employed,Farmer",
                600000,
                "All",
                "All India",
                "Aadhaar Card,Savings Bank Account with Auto-Debit Mandate,Active Mobile Number",
                "https://npscra.nsdl.co.in",
                "Open Year-Round",
                "Instant Enrollment",
                "1800-110-069",
                0,
                86,
                82
            ),
            (
                "Lakhpati Didi Scheme",
                "LAKHPATI-DIDI-2026",
                "Ministry of Rural Development",
                "Women & Child",
                "All India",
                "Skill training, financial mentorship, and zero-interest SHG credit to enable women earn at least ₹1 Lakh annually.",
                "Major women empowerment initiative for members of Deendayal Antyodaya Yojana-National Rural Livelihoods Mission (DAY-NRLM) Self-Help Groups (SHGs) across diverse micro-enterprises like solar technicians, dairy, and drones.",
                "₹1,50,000 Low-interest SHG Capital + Enterprise Training",
                150000,
                "Livelihood Training & Micro-Enterprise Grant",
                18,
                55,
                "Female",
                "Self Help Group Member,Homemaker,Farmer,Artisan",
                250000,
                "All",
                "All India",
                "Aadhaar Card,SHG Membership Certificate,Ration Card,Bank Passbook,Community Proof",
                "https://nrlm.gov.in",
                "Open Year-Round",
                "20 Days",
                "011-23381611",
                1,
                93,
                89
            ),
            (
                "Chief Minister Comprehensive Health Insurance Scheme (CMCHIS)",
                "TN-CMCHIS-2026",
                "Health and Family Welfare Department, Tamil Nadu",
                "Healthcare",
                "Tamil Nadu",
                "Cashless medical coverage of up to ₹5,00,000 per family per year across 1,090+ procedures in Tamil Nadu.",
                "Tamil Nadu's renowned universal health protection program providing comprehensive tertiary care, organ transplants, and specialized pediatric surgeries through United India Insurance Company.",
                "₹5,00,000 per year per family cashless hospital treatment",
                500000,
                "Cashless Hospital Insurance",
                0,
                110,
                "All",
                "All",
                120000,
                "All",
                "Tamil Nadu",
                "Ration Card,Income Certificate from Village Administrative Officer (VAO),Aadhaar Card of Family Head",
                "https://cmchistn.com",
                "Open Year-Round",
                "Card Issued at District Collectorate in 24 Hrs",
                "1800-425-3993",
                0,
                97,
                95
            ),
            (
                "National Apprenticeship Promotion Scheme (NAPS)",
                "NAPS-SKILL-2026",
                "Ministry of Skill Development and Entrepreneurship",
                "Education",
                "All India",
                "Monthly stipend support of up to ₹1,500/month by Government alongside industry training for ITI/Diploma/Graduates.",
                "Encourages employers to engage apprentices and provides technical on-the-job training with stipend sharing directly transferred to student bank accounts under DBT.",
                "₹1,500/month govt stipend share + ₹8,000-₹15,000 industry pay",
                25000,
                "Apprenticeship Training & Monthly Stipend",
                18,
                30,
                "All",
                "Student,Unemployed Youth,Technician",
                500000,
                "All",
                "All India",
                "10th/12th/ITI/Diploma Marksheet,Aadhaar Card,Aadhaar Seeded Bank Account,Candidate Registration ID",
                "https://apprenticeshipindia.gov.in",
                "Rolling Intake Every Month",
                "7 Days",
                "011-23458000",
                0,
                85,
                81
            ),
            (
                "Indira Gandhi National Old Age Pension Scheme (IGNOAPS)",
                "IGNOAPS-PENSION-2026",
                "Ministry of Rural Development",
                "Senior Citizens",
                "All India",
                "Monthly direct pension to senior citizens aged 60+ belonging to below poverty line households.",
                "Part of National Social Assistance Programme (NSAP). Beneficiaries aged 60-79 receive monthly pension, with increased allocation for citizens aged 80 and above supplemented by state matching grants.",
                "₹1,000 to ₹1,500 monthly direct cash assistance",
                18000,
                "Monthly Social Pension",
                60,
                120,
                "All",
                "Senior Citizen,Retired,Unemployed",
                100000,
                "All",
                "All India",
                "Age Proof (Aadhaar / Voter ID),BPL Ration Card / SECC Record,Bank Passbook,Passport Photo",
                "https://nsap.nic.in",
                "Open Year-Round",
                "30 Days",
                "1800-111-555",
                0,
                87,
                80
            ),
            (
                "Rythu Bandhu / PM Fasal Bima Yojana",
                "PMFBY-CROP-2026",
                "Ministry of Agriculture & Farmers Welfare",
                "Agriculture",
                "All India",
                "Comprehensive crop insurance coverage against non-preventable natural risks at a very low premium of 1.5% to 2%.",
                "Protects farmers from harvest losses caused by drought, flood, pests, and cyclones. Yield losses are digitally assessed using satellite data and claims are settled directly to farmer bank accounts.",
                "100% Insured Sum value protection for crop loss",
                75000,
                "Crop Loss Compensation",
                18,
                80,
                "All",
                "Farmer,Tenant Farmer,Sharecropper",
                500000,
                "All",
                "All India",
                "Land Record (RoR/Patta/LPC),Sowing Certificate,Aadhaar Card,Cancelled Cheque / Bank Passbook",
                "https://pmfby.gov.in",
                "Kharif/Rabi Sowing Windows",
                "Claims settled in 21 Days",
                "1800-180-1551",
                0,
                90,
                86
            ),
            (
                "Stand-Up India Scheme",
                "STANDUP-INDIA-2026",
                "Department of Financial Services",
                "Business & MSME",
                "All India",
                "Bank loans between ₹10 Lakh and ₹1 Crore to at least one SC/ST and one woman borrower per bank branch.",
                "Fosters greenfield enterprise development in manufacturing, services, or trading sector. Offers composite loan covering term loan and working capital with concessional interest rates.",
                "Bank loan from ₹10 Lakh to ₹1 Crore for greenfield units",
                1000000,
                "Composite Greenfield Business Loan",
                18,
                65,
                "All",
                "Entrepreneur,Women Entrepreneur,Business Owner",
                2000000,
                "SC,ST,Women",
                "All India",
                "Identity Proof,Proof of Residence,Business Address Proof,Detailed Project Report (DPR),Caste Certificate (if SC/ST)",
                "https://standupmitra.in",
                "Open Year-Round",
                "30 Days",
                "1800-180-1111",
                0,
                86,
                80
            ),
            (
                "MahaDBT Rajarshi Chhatrapati Shahu Maharaj Shikshan Shulkh Shishyavrutti",
                "MAHADBT-MAHA-2026",
                "Higher and Technical Education Department, Maharashtra",
                "Education",
                "Maharashtra",
                "50% to 100% Tuition and Exam Fee reimbursement for students enrolled in professional and non-professional degree courses.",
                "Maharashtra Government's scholarship ensuring that students from economically weaker sections do not discontinue higher education due to financial hurdles.",
                "Up to 100% Tuition Fee Waiver for Engineering/Medical/Arts",
                60000,
                "Higher Education Fee Reimbursement",
                17,
                30,
                "All",
                "Student",
                800000,
                "All",
                "Maharashtra",
                "Maharashtra Domicile Certificate,Income Certificate (Sub-Divisional Officer),CAP Allotment Letter,Aadhaar Card,Marksheet",
                "https://mahadbt.maharashtra.gov.in",
                "30 November 2026",
                "30 Days",
                "022-49150800",
                0,
                88,
                84
            ),
            (
                "Yuva Nidhi Scheme",
                "YUVANIDHI-KA-2026",
                "Department of Skill Development and Livelihood, Karnataka",
                "Youth & Employment",
                "Karnataka",
                "Monthly unemployment allowance of ₹3,000 for degree holders and ₹1,500 for diploma holders for up to 2 years.",
                "Provides crucial financial buffer and free skill training vouchers to unemployed youth of Karnataka while they prepare for competitive exams or jobs.",
                "₹3,000/month (Degree) or ₹1,500/month (Diploma)",
                36000,
                "Direct Monthly Unemployment Allowance",
                18,
                29,
                "All",
                "Unemployed Youth,Student",
                300000,
                "All",
                "Karnataka",
                "Karnataka Domicile Certificate (min 6 years),Degree/Diploma Certificate,Aadhaar Card,Seva Sindhu Registration ID",
                "https://sevasindhugs.karnataka.gov.in",
                "Open for Recent Graduates",
                "15 Days",
                "080-22279954",
                0,
                89,
                85
            )
        ]

        cursor.executemany("""
            INSERT INTO schemes (
                title, code, department, category, state, brief, description,
                benefits, benefit_amount, benefit_type, min_age, max_age,
                allowed_genders, eligible_occupations, max_income, eligible_categories,
                eligible_states, required_docs, application_url, deadline,
                processing_time, helpline, featured, popularity_score, match_score_default
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, schemes_data)

    # Seed Documents for Demo User
    cursor.execute("SELECT count(*) FROM documents WHERE user_id = ?", (user_id,))
    if cursor.fetchone()[0] == 0:
        docs_data = [
            (user_id, "Aadhaar Card", "Aadhaar Identification Document", "aadhaar_verified.pdf", "/static/uploads/aadhaar.pdf", "1.4 MB", "Verified", "2018-05-12", "Lifetime", "XXXX-XXXX-8921"),
            (user_id, "Income Certificate", "Annual Household Income Certificate", "income_cert_2026.pdf", "/static/uploads/income_cert.pdf", "850 KB", "Verified", "2026-01-15", "2027-01-14", "TN-INC-2026-90412"),
            (user_id, "Community Certificate", "OBC Caste Certificate", "community_obc.pdf", "/static/uploads/community.pdf", "920 KB", "Verified", "2019-08-20", "Lifetime", "TN-OBC-781290"),
            (user_id, "Bank Passbook", "Canara Bank Savings Passbook & IFSC", "passbook_frontpage.pdf", "/static/uploads/passbook.pdf", "1.8 MB", "Verified", "2023-04-10", "Active", "CNRB0001290"),
            (user_id, "Residence Certificate", "Nativity / Domicile Certificate", "residence_cert.pdf", "/static/uploads/residence.pdf", "740 KB", "Under Review", "2026-03-01", "2031-03-01", "TN-DOM-2026-4410")
        ]
        cursor.executemany("""
            INSERT INTO documents (user_id, doc_type, title, file_name, file_path, file_size, status, issue_date, expiry_date, doc_number)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, docs_data)

    # Seed Applications for Demo User
    cursor.execute("SELECT count(*) FROM applications WHERE user_id = ?", (user_id,))
    if cursor.fetchone()[0] == 0:
        timeline_pmkisan = json.dumps([
            {"title": "Application Submitted", "date": "10 Aug 2026, 11:20 AM", "completed": True, "note": "Submitted via CSC Rural Portal"},
            {"title": "Village Administrative Verification", "date": "14 Aug 2026, 04:15 PM", "completed": True, "note": "Land Patta & Aadhaar authenticated"},
            {"title": "District Agriculture Officer Approval", "date": "22 Aug 2026, 02:40 PM", "completed": True, "note": "State DBT roster cleared"},
            {"title": "Sanctioned & Direct Benefit Transferred", "date": "28 Aug 2026, 10:00 AM", "completed": True, "note": "₹2,000 installment credited to Canara Bank"}
        ])

        timeline_mudra = json.dumps([
            {"title": "Application Lodged", "date": "05 Sep 2026, 03:30 PM", "completed": True, "note": "Loan proposal of ₹3,50,000 lodged"},
            {"title": "Document & Credit Check", "date": "12 Sep 2026, 11:00 AM", "completed": True, "note": "Udyam verification & CIBIL score verified"},
            {"title": "Branch Manager Inspection", "date": "20 Sep 2026, 02:15 PM", "completed": False, "note": "Physical verification scheduled for shop premises"},
            {"title": "Loan Sanction & Disbursal", "date": "Pending", "completed": False, "note": "Awaiting final credit committee stamp"}
        ])

        cursor.execute("""
            INSERT INTO applications (user_id, scheme_id, application_no, status, stage_index, total_stages, submitted_at, notes, timeline_json)
            VALUES (?, 1, 'APP-PMKISAN-2026-8812', 'Approved', 4, 4, '2026-08-10 11:20:00', '17th Installment successfully credited.', ?)
        """, (user_id, timeline_pmkisan))

        cursor.execute("""
            INSERT INTO applications (user_id, scheme_id, application_no, status, stage_index, total_stages, submitted_at, notes, timeline_json)
            VALUES (?, 6, 'APP-MUDRA-2026-4401', 'Under Review', 2, 4, '2026-09-05 15:30:00', 'Branch manager site visit pending next Tuesday.', ?)
        """, (user_id, timeline_mudra))

    # Seed Saved Schemes
    cursor.execute("SELECT count(*) FROM saved_schemes WHERE user_id = ?", (user_id,))
    if cursor.fetchone()[0] == 0:
        cursor.execute("INSERT INTO saved_schemes (user_id, scheme_id) VALUES (?, 5)", (user_id,)) # Ayushman Bharat
        cursor.execute("INSERT INTO saved_schemes (user_id, scheme_id) VALUES (?, 7)", (user_id,)) # PM Surya Ghar

    # Seed Notifications
    cursor.execute("SELECT count(*) FROM notifications WHERE user_id = ?", (user_id,))
    if cursor.fetchone()[0] == 0:
        notifs = [
            (user_id, "Application Approved!", "Your PM-Kisan Samman Nidhi installment has been successfully transferred to your linked bank account.", "Success", "/dashboard", 0),
            (user_id, "Solar Rooftop Subsidy Available", "You are 92% eligible for ₹78,000 direct subsidy under PM Surya Ghar Muft Bijli Yojana.", "Scheme Alert", "/schemes/7", 0),
            (user_id, "Document Expiry Reminder", "Your Income Certificate expires in 4 months. Please schedule an update at your local e-Sevai / CSC Center.", "Reminder", "/documents", 0),
            (user_id, "New Scheme Match for Tamil Nadu", "Tamil Nadu Department of Social Welfare announced updated guidelines for self-employed citizens.", "New Match", "/schemes", 1)
        ]
        cursor.executemany("""
            INSERT INTO notifications (user_id, title, message, category, action_url, is_read)
            VALUES (?, ?, ?, ?, ?, ?)
        """, notifs)

    # Seed Help Centers
    cursor.execute("SELECT count(*) FROM help_centers")
    if cursor.fetchone()[0] == 0:
        centers = [
            (
                "Anna Nagar CSC & e-Sevai Center",
                "e-Sevai Center",
                "Tamil Nadu",
                "Chennai",
                "Chennai",
                "600040",
                "Plot 42, 2nd Avenue, Near Roundtana, Anna Nagar West, Chennai",
                "K. Murugesan",
                "+91 44 2621 8840",
                "esevai.annanagar@tn.gov.in",
                "Mon - Sat: 9:00 AM - 6:30 PM",
                "Aadhaar Enrollment, Patta Chitta Copy, Income Certificate, Community Certificate, PM-Kisan eKYC, Ration Card Services",
                13.0850,
                80.2101,
                4.9
            ),
            (
                "Guindy Industrial District e-Sevai Kendra",
                "Common Service Center (CSC)",
                "Tamil Nadu",
                "Chennai",
                "Chennai",
                "600032",
                "Block C, SIDCO Industrial Estate, Guindy, Chennai",
                "S. Revathi",
                "+91 44 2250 1492",
                "guindy.csc@csc.gov.in",
                "Mon - Sat: 9:30 AM - 6:00 PM",
                "MSME Udyam Registration, Mudra Loan Assistance, Ayushman Card Generation, Senior Pension Verification",
                13.0067,
                80.2026,
                4.8
            ),
            (
                "Madurai Collectorate Citizen Welfare Help Desk",
                "Government Help Desk",
                "Tamil Nadu",
                "Madurai",
                "Madurai",
                "625020",
                "Ground Floor, District Collectorate Complex, Gandhi Nagar, Madurai",
                "P. Soundararajan",
                "+91 452 253 1110",
                "welfare.madurai@tn.nic.in",
                "Mon - Fri: 10:00 AM - 5:45 PM",
                "Grievance Redressal, Social Pension Sanction, Disabled Welfare Scheme Pass, CMCHIS Smart Card",
                9.9252,
                78.1198,
                4.7
            ),
            (
                "Coimbatore Gandhipuram Digital Seva Kendra",
                "Common Service Center (CSC)",
                "Tamil Nadu",
                "Coimbatore",
                "Coimbatore",
                "641012",
                "114, Cross Cut Road, Near Central Bus Stand, Gandhipuram, Coimbatore",
                "M. Selvakumar",
                "+91 422 249 5500",
                "cbe.gandhipuram@csc.gov.in",
                "Mon - Sat: 9:00 AM - 7:00 PM",
                "Aadhaar Biometric Update, Solar Rooftop Subsidy Application, Farmer Registry, Student Scholarship Portals",
                11.0168,
                76.9558,
                4.8
            ),
            (
                "Bengaluru Koramangala BengaluruOne Center",
                "e-Seva Center",
                "Karnataka",
                "Bengaluru Urban",
                "Bengaluru",
                "560034",
                "Municipal Complex, 80 Feet Road, 4th Block, Koramangala, Bengaluru",
                "Anand Gowda",
                "+91 80 2553 4100",
                "koramangala.b1@karnataka.gov.in",
                "Mon - Sun: 8:00 AM - 7:00 PM",
                "Yuva Nidhi Registration, Caste & Income Certificate, Gruha Lakshmi, Ayushman Golden Card",
                12.9352,
                77.6245,
                4.9
            ),
            (
                "Mumbai Dadar Maha e-Seva Kendra",
                "Common Service Center (CSC)",
                "Maharashtra",
                "Mumbai City",
                "Mumbai",
                "400028",
                "Shop 8, Senapati Bapat Marg, Near Dadar Railway Station (West), Mumbai",
                "Pramod Deshmukh",
                "+91 22 2430 9182",
                "dadar.mahaeseva@csc.gov.in",
                "Mon - Sat: 9:30 AM - 6:30 PM",
                "MahaDBT Scholarship Verification, Ladli Behna & Women Welfare, Domicile Certificate, Mudra Loans",
                19.0178,
                72.8478,
                4.8
            ),
            (
                "Lucknow Hazratganj Jan Seva Kendra",
                "Government Help Desk",
                "Uttar Pradesh",
                "Lucknow",
                "Lucknow",
                "226001",
                "Tehsil Sadar Complex, Near GPO, Hazratganj, Lucknow",
                "Virendra Pratap Singh",
                "+91 522 223 8812",
                "sadar.lucknow@up.gov.in",
                "Mon - Sat: 10:00 AM - 5:30 PM",
                "PM-Kisan Farmer Registry, Kanya Sumangala Yojana, Ayushman Bharat Card, Old Age Pension",
                26.8467,
                80.9462,
                4.7
            ),
            (
                "Hyderabad Secunderabad MeeSeva Center",
                "e-Seva Center",
                "Telangana",
                "Hyderabad",
                "Hyderabad",
                "500003",
                "Opposite Clock Tower, Rashtrapati Road, Secunderabad",
                "T. Srinivas Rao",
                "+91 40 2780 4321",
                "meeseva.secunderabad@telangana.gov.in",
                "Mon - Sat: 9:00 AM - 6:00 PM",
                "Rythu Bharosa, MeeSeva Certificates, Ration Card Corrections, Kalyana Lakshmi Scheme",
                17.4399,
                78.4983,
                4.8
            ),
            (
                "Kolkata Salt Lake Bangla Sahayata Kendra (BSK)",
                "Government Help Desk",
                "West Bengal",
                "North 24 Parganas",
                "Kolkata",
                "700091",
                "Bikash Bhavan, Salt Lake Sector 2, Kolkata",
                "Subrata Banerjee",
                "+91 33 2334 7000",
                "bsk.saltlake@wb.gov.in",
                "Mon - Fri: 10:00 AM - 5:00 PM",
                "Lakshmir Bhandar Registration, Swasthya Sathi Card, Student Credit Card, Kanyashree Prakalpa",
                22.5867,
                88.4178,
                4.8
            ),
            (
                "Ahmedabad Navrangpura Jan Seva Kendra",
                "Common Service Center (CSC)",
                "Gujarat",
                "Ahmedabad",
                "Ahmedabad",
                "380009",
                "Civic Center, Near Commerce Six Roads, Navrangpura, Ahmedabad",
                "Bhavin Patel",
                "+91 79 2640 1289",
                "navrangpura.jsk@gujarat.gov.in",
                "Mon - Sat: 9:00 AM - 6:00 PM",
                "PMJAY MAA Card, Solar Subsidy Liaison, Vhali Dikri Yojana, Digital Gujarat Scholarships",
                23.0365,
                72.5539,
                4.9
            )
        ]

        cursor.executemany("""
            INSERT INTO help_centers (name, center_type, state, district, city, pincode, address, contact_person, phone, email, timings, services, latitude, longitude, rating)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, centers)

    conn.commit()

if __name__ == "__main__":
    init_db()
    print("Database initialized successfully at:", DB_PATH)
