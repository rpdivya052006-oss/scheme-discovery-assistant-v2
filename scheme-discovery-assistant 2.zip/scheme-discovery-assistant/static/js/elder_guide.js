/**
 * Citizen Voice Navigation Guide
 * ==============================================================================
 * Production Multilingual Voice Guidance System with 7 Core Indian Languages:
 * Tamil (ta-IN), English (en-IN), Telugu (te-IN), Kannada (kn-IN),
 * Malayalam (ml-IN), Hindi (hi-IN), Urdu (ur-IN).
 * 
 * Strict Journey Flow:
 * STEP 1: Voice starts automatically on page load and reads language list in native voices.
 *         7 big language buttons shown with native scripts.
 *         Touch/click fallback on autoplay block with animated speaker badge.
 *         Recognition cycling across 7 languages, confirms choice and switches site.
 * STEP 2: Help question asked in chosen language only: "Do you want help? Say yes or no."
 *         Big tick and cross buttons. "No" stops; "Yes" proceeds.
 * STEP 3: Full journey in chosen language:
 *         - Registered vs New citizen choice
 *         - Privacy announcement & spoken consent
 *         - Field-by-field guidance with voice confirmation
 *         - Problem inquiry ("What is your problem or what do you need help with?")
 *         - Scheme matching & Top 3 readout with 1-line descriptions
 *         - Voice selection ("the first one", etc.)
 *         - Form guidance with visual spotlight
 *         - Manual ID validation (Aadhaar 12-digit, first 2-9, Verhoeff checksum,
 *           4-4-4 readback & confirmation, masking on screen; Voter ID 3+7 EPIC format)
 *         - Document upload assistance with fallback to voice ID or nearest help center
 *         - Real help center distance and address data
 *         - Universal controls: "repeat", "go back", "stop"
 * ==============================================================================
 */

// 1. Shared 7-Language Single Source of Truth
const VOICE_CONFIG_7 = {
  ta: {
    name: "Tamil",
    native: "தமிழ்",
    code: "ta-IN",
    which_lang_ask: "எந்த மொழி வேண்டும்?",
    confirm_chosen: "நீங்கள் தமிழ் மொழியைத் தேர்ந்தெடுத்துள்ளீர்கள். தமிழில் தொடர்வோம்.",
    help_question: "வணக்கம்! உங்களுக்கு உதவி வேண்டுமா? ஆம் அல்லது இல்லை என்று சொல்லுங்கள்.",
    yes_words: ["ஆம்", "ஆமாம்", "aam", "venum", "வேண்டும்", "சரி", "yes"],
    no_words: ["இல்லை", "வேண்டாம்", "illa", "illai", "no"],
    yes_btn: "ஆம் (Yes)",
    no_btn: "இல்லை (No)",
    auth_choice: "நீங்கள் ஏற்கனவே பதிவு செய்தவரா அல்லது புதிய பயனரா? 'பதிவு செய்தவர்' அல்லது 'புதிய பயனர்' என்று சொல்லுங்கள்.",
    auth_choice_label: "பதிவு செய்தவர் அல்லது புதிய பயனர்",
    login_guide: "திரையின் நடுவில் உள்ள கட்டத்தில் உங்கள் மின்னஞ்சல் அல்லது தொலைபேசி எண்ணை உள்ளிடுங்கள். அதன் கீழ் உங்கள் கடவுச்சொல்லை உள்ளிடுங்கள். கடவுச்சொல் உரக்க வாசிக்கப்பட மாட்டாது. பிறகு பச்சை நிற 'Sign In' பொத்தானை அமுக்குங்கள்.",
    login_email_pos: "நடுவில் உள்ள மின்னஞ்சல் அல்லது தொலைபேசி எண் கட்டம்",
    privacy_consent: "உங்கள் விவரங்களைப் பெறும் முன்: உங்களுக்குரிய அரசு உதவித் திட்டங்களை கண்டறிய மட்டுமே இது பயன்படும். கடவுச்சொற்கள் உரக்க வாசிக்கப்பட மாட்டாது, உங்கள் குரல் எங்கும் சேமிக்கப்படாது. தொடர 'சரி' என்று சொல்லுங்கள்.",
    fields: {
      name: {
        label: "முழு சட்டப்பூர்வ பெயர்",
        pos: "மேல் இடதுபுறத்தில் உள்ள முதல் கட்டம்",
        ask: "தயவுசெய்து உங்கள் முழு பெயரை சொல்லுங்கள். மேல் இடதுபுறத்தில் உள்ள முதல் கட்டத்தைப் பாருங்கள்.",
        confirm: "உங்கள் பெயர் {val} என பதிவு செய்யப்பட்டது."
      },
      phone: {
        label: "10 இலக்க மொபைல் எண்",
        pos: "மேல் வலதுபுறத்தில் உள்ள தொலைபேசி கட்டம்",
        ask: "தயவுசெய்து உங்கள் 10 இலக்க மொபைல் எண்ணை சொல்லுங்கள்.",
        confirm: "உங்கள் மொபைல் எண் {val} என பதிவு செய்யப்பட்டது."
      },
      age: {
        label: "உங்கள் வயது (ஆண்டுகளில்)",
        pos: "நடுவில் உள்ள வயது கட்டம்",
        ask: "உங்கள் வயது எத்தனை என்று சொல்லுங்கள். நடுவில் உள்ள வயது கட்டத்தைப் பாருங்கள்.",
        confirm: "உங்கள் வயது {val} என பதிவு செய்யப்பட்டது."
      },
      gender: {
        label: "பாலினம் (ஆண், பெண், திருநங்கை)",
        pos: "இடதுபுறத்தில் உள்ள பாலினம் பட்டியல்",
        ask: "உங்கள் பாலினம் என்ன? ஆண், பெண், அல்லது திருநங்கை என்று சொல்லுங்கள்.",
        confirm: "பாலினம் {val} என தேர்வு செய்யப்பட்டது."
      },
      category: {
        label: "சமூகப் பிரிவு (பொது, ஓபிசி, எஸ்சி, எஸ்டி)",
        pos: "நடுவில் உள்ள சமூகப் பிரிவு பட்டியல்",
        ask: "உங்கள் சமூகப் பிரிவு எது? பொது, ஓபிசி, எஸ்சி, அல்லது எஸ்டி என்று சொல்லுங்கள்.",
        confirm: "சமூகப் பிரிவு {val} என தேர்வு செய்யப்பட்டது."
      },
      state: {
        label: "வசிக்கும் மாநிலம்",
        pos: "மாநில தேர்வுப் பட்டியல்",
        ask: "நீங்கள் எந்த மாநிலத்தில் வசிக்கிறீர்கள்? தமிழ்நாடு, கர்நாடகா அல்லது கேரளா என்று சொல்லுங்கள்.",
        confirm: "மாநிலம் {val} என தேர்வு செய்யப்பட்டது."
      },
      income: {
        label: "ஆண்டு குடும்ப வருமானம்",
        pos: "வலதுபுறத்தில் உள்ள வருமானம் பட்டியல்",
        ask: "உங்கள் குடும்ப ஆண்டு வருமானம் எவ்வளவு? ஒரு லட்சம், இரண்டு லட்சம், அல்லது ஐந்து லட்சம் என்று சொல்லலாம்.",
        confirm: "ஆண்டு வருமானம் {val} என தேர்வு செய்யப்பட்டது."
      },
      occupation: {
        label: "முதன்மைத் தொழில் அல்லது வேலை",
        pos: "கீழே உள்ள தொழில் பட்டியல்",
        ask: "உங்கள் முதன்மைத் தொழில் என்ன? விவசாயி, சிறு தொழில், மாணவர், அல்லது தினக்கூலி என்று சொல்லுங்கள்.",
        confirm: "தொழில் {val} என தேர்வு செய்யப்பட்டது."
      },
      password: {
        label: "ரகசிய கடவுச்சொல்",
        pos: "கீழே உள்ள கடவுச்சொல் கட்டம்",
        ask: "கீழே உள்ள கட்டத்தில் உங்கள் கடவுச்சொல்லை உள்ளிடுங்கள். கடவுச்சொல் உரக்க வாசிக்கப்பட மாட்டாது. முடித்ததும் 'சரி' என்று சொல்லுங்கள்.",
        confirm: "கடவுச்சொல் பாதுகாப்பாக பதிவு செய்யப்பட்டது."
      }
    },
    password_confirmed: "கடவுச்சொல் பாதுகாப்பாக பதிவு செய்யப்பட்டது. ரகசியமாக வைக்கப்பட்டுள்ளது.",
    register_done: "அனைத்து விவரங்களும் பதிவு செய்யப்பட்டன! கணக்கை உருவாக்க 'Create Citizen Account' பொத்தானை அமுக்குங்கள் அல்லது 'சமர்ப்பி' என்று சொல்லுங்கள்.",
    searching_schemes: "உங்களுக்கான அரசு உதவி திட்டங்களை ஆராய்கிறேன்...",
    scheme_num_prefix: "திட்டம் {num}:",
    apply_intro: "நீங்கள் {title} திட்டத்தை தேர்வு செய்துள்ளீர்கள். விண்ணப்பிக்க ஆதார் அட்டை, வருமானச் சான்றிதழ் மற்றும் வங்கி கணக்கு புத்தகம் தேவைப்படும். இப்போது உங்கள் பெயரை முதல் கட்டத்தில் உள்ளிடுங்கள்.",
    problem_inquiry: "உங்களுக்கு என்ன உதவி தேவை அல்லது என்ன பிரச்சனை? உதாரணமாக: 'நான் விவசாயி, எனக்கு பயிர்க் கடன் வேண்டும்' அல்லது 'மாணவர் கல்வி உதவித் தொகை வேண்டும்' என்று சொல்லலாம். இப்போது பேசுங்கள்.",
    schemes_intro: "உங்களுக்காக 3 சிறந்த அரசு திட்டங்களை கண்டறிந்துள்ளேன்.",
    choose_scheme: "எந்த திட்டத்தை தேர்வு செய்ய விரும்புகிறீர்கள்? முதல் திட்டம், இரண்டாம் திட்டம், அல்லது மூன்றாம் திட்டம் என்று சொல்லுங்கள்.",
    upload_help_ask: "ஆவணப் படத்தை எவ்வாறு பதிவேற்றுவது என்று உங்களுக்குத் தெரியுமா? ஆம் அல்லது இல்லை என்று சொல்லுங்கள்.",
    upload_guide: "திரையில் உள்ள 'Choose File' பொத்தானை அமுக்கி உங்கள் கேமரா அல்லது சேமிப்பகத்திலிருந்து ஆவணப் படத்தை தேர்வு செய்யுங்கள்.",
    upload_fallback: "உங்களால் ஆவணத்தைப் பதிவேற்ற முடியவில்லை என்றால், உங்கள் ஆதார் எண்ணை குரல் மூலம் கூறலாம் அல்லது அருகிலுள்ள உதவி மையத்திற்கு செல்லலாம்.",
    aadhaar_prompt: "உங்கள் 12 இலக்க ஆதார் எண்ணை சொல்லுங்கள் அல்லது தட்டச்சு செய்யுங்கள்.",
    aadhaar_confirm: "நீங்கள் கூறிய ஆதார் எண்: {digits}. இது சரியானதா? ஆம் அல்லது இல்லை என்று சொல்லுங்கள்.",
    aadhaar_verified_masked: "ஆதார் எண் சரிபார்க்கப்பட்டு பாதுகாப்பாக சேமிக்கப்பட்டது. கடைசி 4 இலக்கங்கள்: {last4}.",
    aadhaar_err_digits: "நீங்கள் {count} இலக்கங்கள் மட்டுமே கூறியுள்ளீர்கள். ஆதார் எண்ணிற்கு சரியாக 12 இலக்கங்கள் தேவை.",
    aadhaar_err_verhoeff: "இந்த ஆதார் எண் தவறானது. எண்களை சரிபார்த்து மீண்டும் சொல்லுங்கள்.",
    voter_prompt: "உங்கள் 10 எழுத்து வாக்காளர் அடையாள அட்டை எண்ணை உள்ளிடுங்கள்.",
    voter_err: "வாக்காளர் அடையாள எண் 3 ஆங்கில எழுத்துக்கள் மற்றும் 7 எண்களாக இருக்க வேண்டும் (எ.கா: ABC1234567).",
    error_repeat_slow: "உங்கள் குரல் தெளிவாக கேட்கவில்லை. மெதுவாக மீண்டும் சொல்கிறேன்.",
    help_center_fallback: "மூன்று முறை புரிந்துகொள்ள இயலவில்லை. நீங்கள் நேரடி உதவி பெற அருகிலுள்ள இ-சேவை மையத்திற்கு செல்லலாம். {center_info}",
    repeat_command: "மீண்டும் சொல்கிறேன்.",
    back_command: "முந்தைய படிக்குச் செல்கிறோம்.",
    stop_command: "குரல் வழிகாட்டி நிறுத்தப்பட்டது."
  },
  en: {
    name: "English",
    native: "English",
    code: "en-IN",
    which_lang_ask: "Which language do you want?",
    confirm_chosen: "You chose English. We will continue in English.",
    help_question: "Hello! Do you want help? Say yes or no.",
    yes_words: ["yes", "yeah", "yep", "sure", "ok", "okay", "continue"],
    no_words: ["no", "nope", "stop", "cancel", "never"],
    yes_btn: "Yes",
    no_btn: "No",
    auth_choice: "Are you a registered user or a new user? Please say 'registered' or 'new user'.",
    auth_choice_label: "Registered User or New User",
    login_guide: "Please enter your registered email or phone number in the box in the middle of the screen. Then enter your password below it. Remember: we never read passwords aloud. Finally, click the green button at the bottom to sign in.",
    login_email_pos: "Enter Email or Phone number in the middle box",
    privacy_consent: "Before we collect your details, here is why they are needed: Your information is strictly used to match government welfare schemes. We never read passwords aloud, and your voice audio is never stored. Say 'continue' to give consent and begin.",
    fields: {
      name: {
        label: "full legal name",
        pos: "the first box on the top left",
        ask: "Please state your full legal name. Look at the first box on the top left.",
        confirm: "Your name has been recorded as {val}."
      },
      phone: {
        label: "10-digit mobile number",
        pos: "the mobile number box on the top right",
        ask: "Please state your 10-digit Aadhaar linked mobile number.",
        confirm: "Your mobile number has been recorded as {val}."
      },
      age: {
        label: "age in years",
        pos: "the age box in the middle",
        ask: "Please state your age in years. Look at the age box in the middle.",
        confirm: "Your age has been recorded as {val}."
      },
      gender: {
        label: "gender (Male, Female, or Transgender)",
        pos: "the gender dropdown on the left",
        ask: "Please state your gender: Male, Female, or Transgender.",
        confirm: "Gender recorded as {val}."
      },
      category: {
        label: "social category (General, OBC, SC, ST, or EWS)",
        pos: "the category dropdown in the middle",
        ask: "Please state your social category: General, OBC, SC, ST, or EWS.",
        confirm: "Social category recorded as {val}."
      },
      state: {
        label: "state of residence",
        pos: "the state dropdown",
        ask: "Please state your state of residence, for example Tamil Nadu.",
        confirm: "State recorded as {val}."
      },
      income: {
        label: "annual family income",
        pos: "the income dropdown on the right",
        ask: "Please state your annual family income. Look at the income dropdown on the right.",
        confirm: "Annual income recorded as {val}."
      },
      occupation: {
        label: "primary occupation or work",
        pos: "the occupation dropdown below",
        ask: "Please state your primary occupation, for example Farmer, Small Business, Student, or Daily Wage Worker.",
        confirm: "Occupation recorded as {val}."
      },
      password: {
        label: "secret password",
        pos: "the password box at the bottom",
        ask: "Now please type your secret password into the password box at the bottom. We never read passwords aloud. Say done when entered.",
        confirm: "Password securely recorded and kept confidential."
      }
    },
    password_confirmed: "Password securely recorded and kept confidential.",
    register_done: "All details recorded! Click Create Citizen Account to finish, or say 'submit'.",
    searching_schemes: "Searching matching schemes for you...",
    scheme_num_prefix: "Number {num}:",
    apply_intro: "You selected {title}. The required documents to apply are your Aadhaar Card, Income Certificate, and Bank Passbook. Now enter your full legal name in the first box.",
    problem_inquiry: "What is your problem or what do you need help with? For example, you can say: 'I am a farmer and I need a loan', or 'I need a student scholarship', or 'I need hospital healthcare'. Please speak now.",
    schemes_intro: "I found the top 3 best schemes for you.",
    choose_scheme: "Which scheme would you like to choose? Say 'the first one', 'the second one', or 'the third one'.",
    upload_help_ask: "Do you know how to upload the document image? Say yes or no.",
    upload_guide: "Click the Choose File button in the middle of the screen to select a photo from your device or take a new photo with your camera.",
    upload_fallback: "If you cannot upload an image, you can say your Aadhaar or Voter ID number aloud, or visit the nearest help center.",
    aadhaar_prompt: "Please state or type your 12-digit Aadhaar number.",
    aadhaar_confirm: "You said Aadhaar number: {digits}. Is this correct? Say yes or no.",
    aadhaar_verified_masked: "Aadhaar verified and encrypted. Number ending in {last4} saved securely.",
    aadhaar_err_digits: "You provided {count} digits. Exactly 12 digits are required for Aadhaar.",
    aadhaar_err_verhoeff: "This Aadhaar number failed checksum validation. Please verify the digits and try again.",
    voter_prompt: "Please state or type your 10-character Voter ID EPIC number.",
    voter_err: "Voter ID must be 3 letters followed by 7 numbers (e.g. ABC1234567).",
    error_repeat_slow: "I did not hear you clearly. Let me repeat more slowly.",
    help_center_fallback: "I could not understand after three tries. You can visit the nearest help center for in-person assistance. {center_info}",
    repeat_command: "Repeating current step.",
    back_command: "Going back to previous step.",
    stop_command: "Voice guide stopped."
  },
  te: {
    name: "Telugu",
    native: "తెలుగు",
    code: "te-IN",
    which_lang_ask: "మీకు ఏ భాష కావాలి?",
    confirm_chosen: "మీరు తెలుగును ఎంచుకున్నారు. తెలుగులో కొనసాగిద్దాం.",
    help_question: "నమస్కారం! మీకు సహాయం కావాలా? అవును లేదా కాదు అని చెప్పండి.",
    yes_words: ["అవును", "avunu", "సరే", "yes", "హా", "కావాలి"],
    no_words: ["కాదు", "వద్దు", "kadu", "vaddu", "no"],
    yes_btn: "అవును (Yes)",
    no_btn: "కాదు (No)",
    auth_choice: "మీరు ఇప్పటికే నమోదైన వినియోగదారులా లేదా కొత్త వినియోగదారులా? 'నమోదైన వారు' లేదా 'కొత్త వారు' అని చెప్పండి.",
    auth_choice_label: "నమోదైన వారు లేదా కొత్త వినియోగదారు",
    login_guide: "తెర మధ్యలో ఉన్న పెట్టెలో మీ ఇమెయిల్ లేదా ఫోన్ నంబర్‌ను నమోదు చేయండి. కింద మీ పాస్‌వర్డ్‌ను టైప్ చేయండి. ఆపై ఆకుపచ్చ రంగు సైన్ ఇన్ బటన్‌ను నొక్కండి.",
    login_email_pos: "మధ్యలో ఇమెయిల్ లేదా ఫోన్ నంబర్ పెట్టె",
    privacy_consent: "మీ వివరాలను తీసుకునే ముందు: ప్రభుత్వ పథకాలను సరిపోల్చడానికి మాత్రమే ఈ వివరాలు ఉపయోగిస్తాము. మీ ఆడియో నిల్వ చేయబడదు. కొనసాగడానికి 'సరే' అని చెప్పండి.",
    fields: {
      name: {
        label: "పూర్తి చట్టబద్ధమైన పేరు",
        pos: "ఎగువ ఎడమవైపు మొదటి పెట్టె",
        ask: "దయచేసి మీ పూర్తి పేరు చెప్పండి. ఎగువ ఎడమవైపు ఉన్న పెట్టెను చూడండి.",
        confirm: "మీ పేరు {val} గా నమోదు చేయబడింది."
      },
      phone: {
        label: "10 అంకెల మొబైల్ నంబర్",
        pos: "ఎగువ కుడివైపు మొబైల్ నంబర్ పెట్టె",
        ask: "దయచేసి మీ 10 అంకెల మొబైల్ నంబర్ చెప్పండి.",
        confirm: "మీ మొబైల్ నంబర్ {val} నమోదు చేయబడింది."
      },
      age: {
        label: "మీ వయస్సు (సంవత్సరాలలో)",
        pos: "మధ్యలో ఉన్న వయస్సు పెట్టె",
        ask: "దయచేసి మీ వయస్సు చెప్పండి. మధ్యలో ఉన్న పెట్టెను చూడండి.",
        confirm: "మీ వయస్సు {val} గా నమోదు చేయబడింది."
      },
      gender: {
        label: "లింగం (పురుషుడు, స్త్రీ, ట్రాన్స్‌జెండర్)",
        pos: "ఎడమవైపు లింగం ఎంపిక",
        ask: "మీ లింగం ఏమిటి? పురుషుడు, స్త్రీ, లేదా ట్రాన్స్‌జెండర్ అని చెప్పండి.",
        confirm: "లింగం {val} గా ఎంపిక చేయబడింది."
      },
      category: {
        label: "సామాజిక వర్గం (జనరల్, బీసీ, ఎస్సీ, ఎస్టీ)",
        pos: "మధ్యలో సామాజిక వర్గం ఎంపిక",
        ask: "మీ సామాజిక వర్గం ఏమిటి? జనరల్, బీసీ, ఎస్సీ, లేదా ఎస్టీ అని చెప్పండి.",
        confirm: "సామాజిక వర్గం {val} గా ఎంపిక చేయబడింది."
      },
      state: {
        label: "నివాస రాష్ట్రం",
        pos: "రాష్ట్రం ఎంపిక జాబితా",
        ask: "మీరు ఏ రాష్ట్రంలో నివసిస్తున్నారు? ఉదాహరణకు ఆంధ్రప్రదేశ్ లేదా తమిళనాడు చెప్పండి.",
        confirm: "రాష్ట్రం {val} గా ఎంపిక చేయబడింది."
      },
      income: {
        label: "వార్షిక కుటుంబ ఆదాయం",
        pos: "కుడివైపు ఆదాయం ఎంపిక",
        ask: "మీ కుటుంబ వార్షిక ఆదాయం ఎంత? కుడివైపు ఉన్న ఆదాయం పెట్టెను చూడండి.",
        confirm: "ఆదాయం {val} గా ఎంపిక చేయబడింది."
      },
      occupation: {
        label: "ప్రధాన వృత్తి లేదా పని",
        pos: "వృత్తి ఎంపిక జాబితా",
        ask: "మీ ప్రధాన వృత్తి ఏమిటి? రైతు, చిన్న వ్యాపారం, విద్యార్థి లేదా కూలీ అని చెప్పండి.",
        confirm: "వృత్తి {val} గా ఎంపిక చేయబడింది."
      },
      password: {
        label: "రహస్య పాస్‌వర్డ్",
        pos: "కింద ఉన్న పాస్‌వర్డ్ పెట్టె",
        ask: "కింద ఉన్న పెట్టెలో మీ పాస్‌వర్డ్ నమోదు చేయండి. పాస్‌వర్డ్ బయటకు చదవబడదు. నమోదు చేశాక 'అయింది' అని చెప్పండి.",
        confirm: "పాస్‌వర్డ్ సురక్షితంగా నమోదు చేయబడింది."
      }
    },
    password_confirmed: "పాస్‌వర్డ్ సురక్షితంగా నమోదు చేయబడింది మరియు రహస్యంగా ఉంచబడింది.",
    register_done: "అన్ని వివరాలు నమోదు చేయబడ్డాయి! ఖాతా సృష్టించడానికి బటన్ క్లిక్ చేయండి లేదా 'సమర్పించు' అని చెప్పండి.",
    searching_schemes: "మీ కోసం ప్రభుత్వ పథకాలను శోధిస్తున్నాను...",
    scheme_num_prefix: "పథకం {num}:",
    apply_intro: "మీరు {title} పథకాన్ని ఎంచుకున్నారు. దరఖాస్తుకు ఆధార్ కార్డు, ఆదాయ ధృవీకరణ పత్రం, బ్యాంక్ పాస్‌బుక్ అవసరం. ఇప్పుడు మొదటి పెట్టెలో మీ పేరు నమోదు చేయండి.",
    problem_inquiry: "మీ సమస్య ఏమిటి లేదా మీకు ఏ సహాయం కావాలి? ఉదాహరణకు: 'నేను రైతును, నాకు పంట రుణం కావాలి' అని చెప్పవచ్చు. ఇప్పుడు మాట్లాడండి.",
    schemes_intro: "మీ కోసం ఉత్తమమైన 3 పథకాలను కనుగొన్నాను.",
    choose_scheme: "మీరు ఏ పథకాన్ని ఎంచుకోవాలనుకుంటున్నారు? మొదటిది, రెండవది లేదా మూడవది అని చెప్పండి.",
    upload_help_ask: "పత్రం ఫోటోను ఎలా అప్‌లోడ్ చేయాలో మీకు తెలుసా? అవును లేదా కాదు అని చెప్పండి.",
    upload_guide: "తెరపై ఉన్న ఫైల్ ఎంచుకోండి బటన్‌ను నొక్కి మీ ఫోటోను ఎంచుకోండి.",
    upload_fallback: "మీరు ఫోటోను అప్‌లోడ్ చేయలేకపోతే, మీ ఆధార్ నంబర్‌ను మాటలతో చెప్పవచ్చు లేదా సమీప సహాయ కేంద్రానికి వెళ్లవచ్చు.",
    aadhaar_prompt: "దయచేసి మీ 12 అంకెల ఆధార్ సంఖ్యను చెప్పండి లేదా నమోదు చేయండి.",
    aadhaar_confirm: "మీరు చెప్పిన ఆధార్ సంఖ్య: {digits}. ఇది సరైనదేనా? అవును లేదా కాదు అని చెప్పండి.",
    aadhaar_verified_masked: "ఆధార్ ధృవీకరించబడింది మరియు సురక్షితంగా సేవ్ చేయబడింది. చివరి 4 అంకెలు: {last4}.",
    aadhaar_err_digits: "మీరు {count} అంకెలు మాత్రమే చెప్పారు. ఆధార్ కోసం ఖచ్చితంగా 12 అంకెలు అవసరం.",
    aadhaar_err_verhoeff: "ఆధార్ సంఖ్య చెల్లుబాటు కాలేదు. అంకెలను సరిచూసి మళ్లీ చెప్పండి.",
    voter_prompt: "దయచేసి మీ 10 అక్షరాల ఓటరు గుర్తింపు సంఖ్యను నమోదు చేయండి.",
    voter_err: "ఓటరు గుర్తింపు సంఖ్య 3 అక్షరాలు మరియు 7 అంకెలు ఉండాలి (ఉదా: ABC1234567).",
    error_repeat_slow: "మీ మాట స్పష్టంగా వినిపించలేదు. నెమ్మదిగా మళ్లీ చెబుతున్నాను.",
    help_center_fallback: "మూడు ప్రయత్నాల తర్వాత అర్థం కాలేదు. వ్యక్తిగత సహాయం కోసం సమీప పౌర సహాయ కేంద్రానికి వెళ్లవచ్చు. {center_info}",
    repeat_command: "మళ్లీ చెబుతున్నాను.",
    back_command: "మునుపటి దశకు వెళ్తున్నాం.",
    stop_command: "వాయిస్ గైడ్ ఆపివేయబడింది."
  },
  kn: {
    name: "Kannada",
    native: "ಕನ್ನಡ",
    code: "kn-IN",
    which_lang_ask: "ಯಾವ ಭಾಷೆ ಬೇಕು?",
    confirm_chosen: "ನೀವು ಕನ್ನಡವನ್ನು ಆಯ್ಕೆ ಮಾಡಿದ್ದೀರಿ. ಕನ್ನಡದಲ್ಲಿ ಮುಂದುವರಿಸೋಣ.",
    help_question: "ನಮಸ್ಕಾರ! ನಿಮಗೆ ಸಹಾಯ ಬೇಕೆ? ಹೌದು ಅಥವಾ ಇಲ್ಲ ಎಂದು ಹೇಳಿ.",
    yes_words: ["ಹೌದು", "haudu", "ಸರಿ", "yes", "ಆಯಿತು", "ಬೇಕು"],
    no_words: ["ಇಲ್ಲ", "ಬೇಡ", "illa", "beda", "no"],
    yes_btn: "ಹೌದು (Yes)",
    no_btn: "ಇಲ್ಲ (No)",
    auth_choice: "ನೀವು ಈಗಾಗಲೇ ನೋಂದಾಯಿತ ಬಳಕೆದಾರರೇ ಅಥವಾ ಹೊಸ ಬಳಕೆದಾರರೇ? 'ನೋಂದಾಯಿತ' ಅಥವಾ 'ಹೊಸ ಬಳಕೆದಾರ' ಎಂದು ಹೇಳಿ.",
    auth_choice_label: "ನೋಂದಾಯಿತ ಬಳಕೆದಾರರು ಅಥವಾ ಹೊಸ ಬಳಕೆದಾರರು",
    login_guide: "ಪರದೆಯ ಮಧ್ಯದಲ್ಲಿರುವ ಪೆಟ್ಟಿಗೆಯಲ್ಲಿ ನಿಮ್ಮ ಇಮೇಲ್ ಅಥವಾ ಫೋನ್ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ. ನಂತರ ಕೆಳಗೆ ಪಾಸ್‌ವರ್ಡ್ ನಮೂದಿಸಿ ಮತ್ತು ಸೈನ್ ಇನ್ ಬಟನ್ ಒತ್ತಿ.",
    login_email_pos: "ಮಧ್ಯದಲ್ಲಿರುವ ಇಮೇಲ್ ಅಥವಾ ಫೋನ್ ಪೆಟ್ಟಿಗೆ",
    privacy_consent: "ನಿಮ್ಮ ವಿವರಗಳನ್ನು ಪಡೆಯುವ ಮೊದಲು: ಸರ್ಕಾರಿ ಯೋಜನೆಗಳನ್ನು ಹೊಂದಿಸಲು ಮಾತ್ರ ಈ ವಿವರಗಳನ್ನು ಬಳಸಲಾಗುತ್ತದೆ. ನಿಮ್ಮ ಧ್ವನಿ ಸಂಗ್ರಹವಾಗುವುದಿಲ್ಲ. ಮುಂದುವರಿಯಲು 'ಸರಿ' ಎಂದು ಹೇಳಿ.",
    fields: {
      name: {
        label: "ಪೂರ್ಣ ಕಾನೂನುಬದ್ಧ ಹೆಸರು",
        pos: "ಮೇಲಿನ ಎಡಭಾಗದ ಮೊದಲ ಪೆಟ್ಟಿಗೆ",
        ask: "ದಯವಿಟ್ಟು ನಿಮ್ಮ ಪೂರ್ಣ ಹೆಸರನ್ನು ಹೇಳಿ. ಮೇಲಿನ ಎಡಭಾಗದ ಪೆಟ್ಟಿಗೆಯನ್ನು ನೋಡಿ.",
        confirm: "ನಿಮ್ಮ ಹೆಸರು {val} ಎಂದು ದಾಖಲಾಗಿದೆ."
      },
      phone: {
        label: "10 ಅಂಕಿಗಳ ಮೊಬೈಲ್ ಸಂಖ್ಯೆ",
        pos: "ಮೇಲಿನ ಬಲಭಾಗದ ಮೊಬೈಲ್ ಸಂಖ್ಯೆ ಪೆಟ್ಟಿಗೆ",
        ask: "ದಯವಿಟ್ಟು ನಿಮ್ಮ 10 ಅಂಕಿಗಳ ಮೊಬೈಲ್ ಸಂಖ್ಯೆಯನ್ನು ಹೇಳಿ.",
        confirm: "ಮೊಬೈಲ್ ಸಂಖ್ಯೆ {val} ಎಂದು ದಾಖಲಾಗಿದೆ."
      },
      age: {
        label: "ನಿಮ್ಮ ವಯಸ್ಸು (ವರ್ಷಗಳಲ್ಲಿ)",
        pos: "ಮಧ್ಯದಲ್ಲಿರುವ ವಯಸ್ಸಿನ ಪೆಟ್ಟಿಗೆ",
        ask: "ದಯವಿಟ್ಟು ನಿಮ್ಮ ವಯಸ್ಸನ್ನು ಹೇಳಿ. ಮಧ್ಯದಲ್ಲಿರುವ ಪೆಟ್ಟಿಗೆಯನ್ನು ನೋಡಿ.",
        confirm: "ನಿಮ್ಮ ವಯಸ್ಸು {val} ಎಂದು ದಾಖಲಾಗಿದೆ."
      },
      gender: {
        label: "ಲಿಂಗ (ಪುರುಷ, ಮಹಿಳೆ, ತೃತೀಯ ಲಿಂಗ)",
        pos: "ಎಡಭಾಗದ ಲಿಂಗ ಆಯ್ಕೆ",
        ask: "ನಿಮ್ಮ ಲಿಂಗ ಯಾವುದು? ಪುರುಷ, ಮಹಿಳೆ ಅಥವಾ ತೃತೀಯ ಲಿಂಗ ಎಂದು ಹೇಳಿ.",
        confirm: "ಲಿಂಗ {val} ಎಂದು ಆಯ್ಕೆಯಾಗಿದೆ."
      },
      category: {
        label: "ಸಾಮಾಜಿಕ ವರ್ಗ (ಸಾಮಾನ್ಯ, ಒಬಿಸಿ, ಎಸ್ಸಿ, ಎಸ್ಟಿ)",
        pos: "ಮಧ್ಯದ ಸಾಮಾಜಿಕ ವರ್ಗ ಆಯ್ಕೆ",
        ask: "ನಿಮ್ಮ ಸಾಮಾಜಿಕ ವರ್ಗ ಯಾವುದು? ಸಾಮಾನ್ಯ, ಒಬಿಸಿ, ಎಸ್ಸಿ ಅಥವಾ ಎಸ್ಟಿ ಎಂದು ಹೇಳಿ.",
        confirm: "ಸಾಮಾಜಿಕ ವರ್ಗ {val} ಎಂದು ಆಯ್ಕೆಯಾಗಿದೆ."
      },
      state: {
        label: "ವಾಸಿಸುವ ರಾಜ್ಯ",
        pos: "ರಾಜ್ಯ ಆಯ್ಕೆ ಪಟ್ಟಿ",
        ask: "ನೀವು ಯಾವ ರಾಜ್ಯದಲ್ಲಿ ವಾಸಿಸುತ್ತೀರಿ? ಉದಾಹರಣೆಗೆ ಕರ್ನಾಟಕ ಅಥವಾ ತಮಿಳುನಾಡು ಎಂದು ಹೇಳಿ.",
        confirm: "ರಾಜ್ಯ {val} ಎಂದು ಆಯ್ಕೆಯಾಗಿದೆ."
      },
      income: {
        label: "ವಾರ್ಷಿಕ ಕುಟುಂಬ ಆದಾಯ",
        pos: "ಬಲಭಾಗದ ಆದಾಯ ಆಯ್ಕೆ",
        ask: "ನಿಮ್ಮ ಕುಟುಂಬದ ವಾರ್ಷಿಕ ಆದಾಯ ಎಷ್ಟು? ಬಲಭಾಗದ ಆದಾಯ ಪೆಟ್ಟಿಗೆಯನ್ನು ನೋಡಿ.",
        confirm: "ಆದಾಯ {val} ಎಂದು ಆಯ್ಕೆಯಾಗಿದೆ."
      },
      occupation: {
        label: "ಮುಖ್ಯ ಉದ್ಯೋಗ ಅಥವಾ ಕೆಲಸ",
        pos: "ಉದ್ಯೋಗ ಆಯ್ಕೆ ಪಟ್ಟಿ",
        ask: "ನಿಮ್ಮ ಮುಖ್ಯ ಉದ್ಯೋಗ ಯಾವುದು? ರೈತ, ಸಣ್ಣ ವ್ಯಾಪಾರ, ವಿದ್ಯಾರ್ಥಿ ಅಥವಾ ಕೂಲಿ ಕಾರ್ಮಿಕ ಎಂದು ಹೇಳಿ.",
        confirm: "ಉದ್ಯೋಗ {val} ಎಂದು ಆಯ್ಕೆಯಾಗಿದೆ."
      },
      password: {
        label: "ರಹಸ್ಯ ಪಾಸ್‌ವರ್ಡ್",
        pos: "ಕೆಳಗಿನ ಪಾಸ್‌ವರ್ಡ್ ಪೆಟ್ಟಿಗೆ",
        ask: "ಕೆಳಗಿನ ಪೆಟ್ಟಿಗೆಯಲ್ಲಿ ನಿಮ್ಮ ಪಾಸ್‌ವರ್ಡ್ ನಮೂದಿಸಿ. ಪಾಸ್‌ವರ್ಡ್ ಗಟ್ಟಿಯಾಗಿ ಓದಲಾಗುವುದಿಲ್ಲ. ನಮೂದಿಸಿದ ನಂತರ 'ಆಯಿತು' ಎಂದು ಹೇಳಿ.",
        confirm: "ಪಾಸ್‌ವರ್ಡ್ ಸುರಕ್ಷಿತವಾಗಿ ದಾಖಲಾಗಿದೆ."
      }
    },
    password_confirmed: "ಪಾಸ್‌ವರ್ಡ್ ಸುರಕ್ಷಿತವಾಗಿ ದಾಖಲಾಗಿದೆ ಮತ್ತು ರಹಸ್ಯವಾಗಿಡಲಾಗಿದೆ.",
    register_done: "ಎಲ್ಲ ವಿವರಗಳನ್ನು ದಾಖಲಿಸಲಾಗಿದೆ! ಖಾತೆ ರಚಿಸಲು ಬಟನ್ ಒತ್ತಿ ಅಥವಾ 'ಸಲ್ಲಿಸು' ಎಂದು ಹೇಳಿ.",
    searching_schemes: "ನಿಮಗಾಗಿ ಸೂಕ್ತ ಯೋಜನೆಗಳನ್ನು ಹುಡುಕುತ್ತಿದ್ದೇನೆ...",
    scheme_num_prefix: "ಯೋಜನೆ {num}:",
    apply_intro: "ನೀವು {title} ಯೋಜನೆಯನ್ನು ಆಯ್ಕೆ ಮಾಡಿದ್ದೀರಿ. ಅರ್ಜಿ ಸಲ್ಲಿಸಲು ಆಧಾರ್ ಕಾರ್ಡ್, ಆದಾಯ ಪ್ರಮಾಣಪತ್ರ ಮತ್ತು ಬ್ಯಾಂಕ್ ಪಾಸ್‌ಬುಕ್ ಅಗತ್ಯವಿದೆ. ಈಗ ಮೊದಲ ಪೆಟ್ಟಿಗೆಯಲ್ಲಿ ನಿಮ್ಮ ಹೆಸರನ್ನು ನಮೂದಿಸಿ.",
    problem_inquiry: "ನಿಮಗೆ ಯಾವ ಸಹಾಯ ಬೇಕು? ಉದಾಹರಣೆಗೆ: 'ನಾನು ರೈತ, ನನಗೆ ಬೆಳೆ ಸಾಲ ಬೇಕು' ಅಥವಾ 'ವಿದ್ಯಾರ್ಥಿವೇತನ ಬೇಕು' ಎಂದು ಹೇಳಬಹುದು. ಈಗ ಮಾತನಾಡಿ.",
    schemes_intro: "ನಿಮಗಾಗಿ ಟಾಪ್ 3 ಅತ್ಯುತ್ತಮ ಯೋಜನೆಗಳನ್ನು ಕಂಡುಕೊಂಡಿದ್ದೇನೆ.",
    choose_scheme: "ಯಾವ ಯೋಜನೆಯನ್ನು ಆಯ್ಕೆ ಮಾಡುತ್ತೀರಿ? ಮೊದಲನೆಯದು, ಎರಡನೆಯದು ಅಥವಾ ಮೂರನೆಯದು ಎಂದು ಹೇಳಿ.",
    upload_help_ask: "ದಾಖಲೆ ಫೋಟೋವನ್ನು ಹೇಗೆ ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕೆಂದು ನಿಮಗೆ ತಿಳಿದಿದೆಯೇ? ಹೌದು ಅಥವಾ ಇಲ್ಲ ಎಂದು ಹೇಳಿ.",
    upload_guide: "ಪರದೆಯ ಮೇಲಿನ ಅಪ್‌ಲೋಡ್ ಬಟನ್ ಒತ್ತಿ ಮತ್ತು ನಿಮ್ಮ ಫೋಟೋವನ್ನು ಆಯ್ಕೆಮಾಡಿ.",
    upload_fallback: "ನಿಮಗೆ ಅಪ್‌ಲೋಡ್ ಮಾಡಲು ಸಾಧ್ಯವಾಗದಿದ್ದರೆ, ಆಧಾರ್ ಸಂಖ್ಯೆಯನ್ನು ಧ್ವನಿ ಮೂಲಕ ಹೇಳಬಹುದು ಅಥವಾ ಹತ್ತಿರದ ಸೇವಾ ಕೇಂದ್ರಕ್ಕೆ ಭೇಟಿ ನೀಡಬಹುದು.",
    aadhaar_prompt: "ನಿಮ್ಮ 12 ಅಂಕಿಗಳ ಆಧಾರ್ ಸಂಖ್ಯೆಯನ್ನು ಹೇಳಿ ಅಥವಾ ಟೈಪ್ ಮಾಡಿ.",
    aadhaar_confirm: "ನೀವು ಹೇಳಿದ ಆಧಾರ್ ಸಂಖ್ಯೆ: {digits}. ಇದು ಸರಿಯೇ? ಹೌದು ಅಥವಾ ಇಲ್ಲ ಎಂದು ಹೇಳಿ.",
    aadhaar_verified_masked: "ಆಧಾರ್ ಪರಿಶೀಲಿಸಲಾಗಿದೆ ಮತ್ತು ಸುರಕ್ಷಿತವಾಗಿ ಸಂಗ್ರಹಿಸಲಾಗಿದೆ. ಕೊನೆಯ 4 ಅಂಕಿಗಳು: {last4}.",
    aadhaar_err_digits: "ನೀವು {count} ಅಂಕಿಗಳನ್ನು ನೀಡಿದ್ದೀರಿ. ಆಧಾರ್‌ಗೆ ಸರಿಯಾಗಿ 12 ಅಂಕಿಗಳು ಬೇಕು.",
    aadhaar_err_verhoeff: "ಆಧಾರ್ ಸಂಖ್ಯೆ ಅಮಾನ್ಯವಾಗಿದೆ. ಪರಿಶೀಲಿಸಿ ಮತ್ತೆ ಹೇಳಿ.",
    voter_prompt: "ನಿಮ್ಮ 10 ಅಕ್ಷರಗಳ ವೋಟರ್ ಐಡಿ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ.",
    voter_err: "ವೋಟರ್ ಐಡಿ 3 ಅಕ್ಷರಗಳು ಮತ್ತು 7 ಅಂಕಿಗಳಾಗಿರಬೇಕು (ಉದಾ: ABC1234567).",
    error_repeat_slow: "ನಿಮ್ಮ ಮಾತು ಸ್ಪಷ್ಟವಾಗಿ ಕೇಳಿಸಲಿಲ್ಲ. ನಿಧಾನವಾಗಿ ಮತ್ತೆ ಹೇಳುತ್ತೇನೆ.",
    help_center_fallback: "ಮೂರು ಬಾರಿ ಅರ್ಥವಾಗಲಿಲ್ಲ. ನೀವು ಹತ್ತಿರದ ಗ್ರಾಮ ಒನ್ ಅಥವಾ ಸೇವಾ ಕೇಂದ್ರಕ್ಕೆ ಭೇಟಿ ನೀಡಿ ಸಹಾಯ ಪಡೆಯಬಹುದು. {center_info}",
    repeat_command: "ಮತ್ತೆ ಹೇಳುತ್ತಿದ್ದೇನೆ.",
    back_command: "ಹಿಂದಿನ ಹಂತಕ್ಕೆ ಹೋಗುತ್ತಿದ್ದೇವೆ.",
    stop_command: "ಧ್ವನಿ ಮಾರ್ಗದರ್ಶಿ ನಿಲ್ಲಿಸಲಾಗಿದೆ."
  },
  ml: {
    name: "Malayalam",
    native: "മലയാളം",
    code: "ml-IN",
    which_lang_ask: "ഏത് ഭാഷയാണ് വേണ്ടത്?",
    confirm_chosen: "നിങ്ങൾ മലയാളം തിരഞ്ഞെടുത്തു. മലയാളത്തിൽ തുടരാം.",
    help_question: "നമസ്കാരം! നിങ്ങൾക്ക് സഹായം വേണമോ? അതെ അല്ലെങ്കിൽ അല്ല എന്ന് പറയുക.",
    yes_words: ["അതെ", "athe", "ശരി", "വേണം", "yes"],
    no_words: ["അല്ല", "വേണ്ട", "alla", "venda", "no"],
    yes_btn: "അതെ (Yes)",
    no_btn: "അല്ല (No)",
    auth_choice: "നിങ്ങൾ മുൻപ് രജിസ്റ്റർ ചെയ്ത ആളാണോ അതോ പുതിയ ആളാണോ? 'രജിസ്റ്റർ ചെയ്തയാൾ' അല്ലെങ്കിൽ 'പുതിയയാൾ' എന്ന് പറയുക.",
    auth_choice_label: "രജിസ്റ്റർ ചെയ്തയാൾ അല്ലെങ്കിൽ പുതിയ ഉപയോക്താവ്",
    login_guide: "സ്ക്രീനിന്റെ മധ്യത്തിലുള്ള ബോക്സിൽ നിങ്ങളുടെ ഇമെയിൽ അല്ലെങ്കിൽ ഫോൺ നമ്പർ നൽകുക. താഴെ പാസ്‌വേഡ് നൽകി സൈൻ ഇൻ ബട്ടൺ ക്ലിക്ക് ചെയ്യുക.",
    login_email_pos: "നടുവിലുള്ള ഇമെയിൽ അല്ലെങ്കിൽ ഫോൺ നമ്പർ ബോക്സ്",
    privacy_consent: "വിവരങ്ങൾ ശേഖരിക്കുന്നതിന് മുൻപ്: സർക്കാർ ക്ഷേമ പദ്ധതികൾ കണ്ടെത്തുന്നതിനായി മാത്രമാണ് ഈ വിവരങ്ങൾ ഉപയോഗിക്കുന്നത്. നിങ്ങളുടെ ശബ്ദം സൂക്ഷിക്കാറില്ല. തുടരാൻ 'ശരി' എന്ന് പറയുക.",
    fields: {
      name: {
        label: "പൂർണ്ണ നിയമപരമായ പേര്",
        pos: "മുകളിൽ ഇടതുവശത്തെ ആദ്യ ബോക്സ്",
        ask: "ദയവായി നിങ്ങളുടെ പൂർണ്ണ പേര് പറയുക. മുകളിൽ ഇടതുവശത്തെ ബോക്സ് നോക്കുക.",
        confirm: "നിങ്ങളുടെ പേര് {val} എന്ന് രേഖപ്പെടുത്തി."
      },
      phone: {
        label: "10 അക്ക മൊബൈൽ നമ്പർ",
        pos: "മുകളിൽ വലതുവശത്തെ മൊബൈൽ ബോക്സ്",
        ask: "ദയവായി നിങ്ങളുടെ 10 അക്ക മൊബൈൽ നമ്പർ പറയുക.",
        confirm: "മൊബൈൽ നമ്പർ {val} എന്ന് രേഖപ്പെടുത്തി."
      },
      age: {
        label: "പ്രായം (വർഷത്തിൽ)",
        pos: "നടുവിലുള്ള പ്രായ ബോക്സ്",
        ask: "ദയവായി നിങ്ങളുടെ പ്രായം പറയുക. നടുവിലുള്ള ബോക്സ് നോക്കുക.",
        confirm: "പ്രായം {val} എന്ന് രേഖപ്പെടുത്തി."
      },
      gender: {
        label: "ലിംഗഭേദം (പുരുഷൻ, സ്ത്രീ, ട്രാൻസ്‌ജെൻഡർ)",
        pos: "ഇടതുവശത്തെ ലിംഗഭേദം തിരഞ്ഞെടുക്കൽ",
        ask: "നിങ്ങളുടെ ലിംഗഭേദം ഏതാണ്? പുരുഷൻ, സ്ത്രീ, അല്ലെങ്കിൽ ട്രാൻസ്‌ജെൻഡർ എന്ന് പറയുക.",
        confirm: "ലിംഗഭേദം {val} എന്ന് തിരഞ്ഞെടുത്തു."
      },
      category: {
        label: "സാമൂഹിക വിഭാഗം (ജനറൽ, ഒബിസി, എസ് സി, എസ് ടി)",
        pos: "നടുവിലെ സാമൂഹിക വിഭാഗം",
        ask: "നിങ്ങളുടെ സാമൂഹിക വിഭാഗം ഏതാണ്? ജനറൽ, ഒബിസി, എസ് സി, അല്ലെങ്കിൽ എസ് ടി എന്ന് പറയുക.",
        confirm: "വിഭാഗം {val} എന്ന് തിരഞ്ഞെടുത്തു."
      },
      state: {
        label: "താമസിക്കുന്ന സംസ്ഥാനം",
        pos: "സംസ്ഥാനം തിരഞ്ഞെടുക്കൽ",
        ask: "നിങ്ങൾ ഏത് സംസ്ഥാനത്താണ് താമസിക്കുന്നത്? ഉദാഹരണത്തിന് കേരളം അല്ലെങ്കിൽ തമിഴ്‌നാട് എന്ന് പറയുക.",
        confirm: "സംസ്ഥാനം {val} എന്ന് തിരഞ്ഞെടുത്തു."
      },
      income: {
        label: "വാർഷിക കുടുംബ വരുമാനം",
        pos: "വലതുവശത്തെ വരുമാന ബോക്സ്",
        ask: "നിങ്ങളുടെ കുടുംബ വാർഷിക വരുമാനം എത്രയാണ്? വലതുവശത്തെ ബോക്സ് നോക്കുക.",
        confirm: "വരുമാനം {val} എന്ന് തിരഞ്ഞെടുത്തു."
      },
      occupation: {
        label: "പ്രധാന തൊഴിൽ",
        pos: "തൊഴിൽ തിരഞ്ഞെടുക്കൽ",
        ask: "നിങ്ങളുടെ പ്രധാന തൊഴിൽ എന്താണ്? കർഷകൻ, ചെറുകിട ബിസിനസ്, വിദ്യാർത്ഥി, അല്ലെങ്കിൽ തൊഴിലാളി എന്ന് പറയുക.",
        confirm: "തൊഴിൽ {val} എന്ന് തിരഞ്ഞെടുത്തു."
      },
      password: {
        label: "രഹസ്യ പാസ്‌വേഡ്",
        pos: "താഴെയുള്ള പാസ്‌വേഡ് ബോക്സ്",
        ask: "താഴെയുള്ള ബോക്സിൽ പാസ്‌വേഡ് നൽകുക. പാസ്‌വേഡ് ഉച്ചത്തിൽ വായിക്കില്ല. നൽകിയ ശേഷം 'കഴിഞ്ഞു' എന്ന് പറയുക.",
        confirm: "പാസ്‌വേഡ് സുരക്ഷിതമായി രേഖപ്പെടുത്തി."
      }
    },
    password_confirmed: "പാസ്‌വേഡ് സുരക്ഷിതമായി രേഖപ്പെടുത്തി. രഹസ്യമായി സൂക്ഷിച്ചിരിക്കുന്നു.",
    register_done: "എല്ലാ വിവരങ്ങളും രേഖപ്പെടുത്തി! അക്കൗണ്ട് നിർമ്മിക്കാൻ ബട്ടൺ അമർത്തുക അല്ലെങ്കിൽ 'സമർപ്പിക്കുക' എന്ന് പറയുക.",
    searching_schemes: "നിങ്ങൾക്കായുള്ള സർക്കാർ പദ്ധതികൾ കണ്ടെത്തുന്നു...",
    scheme_num_prefix: "പദ്ധതി {num}:",
    apply_intro: "നിങ്ങൾ {title} പദ്ധതി തിരഞ്ഞെടുത്തു. അപേക്ഷിക്കാൻ ആധാർ കാർഡ്, വരുമാന സർട്ടിഫിക്കറ്റ്, ബാങ്ക് പാസ്ബുക്ക് എന്നിവ ആവശ്യമാണ്. ഇപ്പോൾ ആദ്യ ബോക്സിൽ നിങ്ങളുടെ പേര് നൽകുക.",
    problem_inquiry: "നിങ്ങൾക്ക് എന്ത് സഹായമാണ് വേണ്ടത്? ഉദാഹരണത്തിന്: 'ഞാൻ കർഷകനാണ്, വായ്പ വേണം' അല്ലെങ്കിൽ 'സ്കോളർഷിപ്പ് വേണം' എന്ന് പറയാം. ഇപ്പോൾ സംസാരിക്കുക.",
    schemes_intro: "നിങ്ങൾക്കായി 3 മികച്ച പദ്ധതികൾ കണ്ടെത്തിയിട്ടുണ്ട്.",
    choose_scheme: "ഏത് പദ്ധതിയാണ് തിരഞ്ഞെടുക്കുന്നത്? ആദ്യത്തേത്, രണ്ടാമത്തേത്, അല്ലെങ്കിൽ മൂന്നാമത്തേത് എന്ന് പറയുക.",
    upload_help_ask: "രേഖയുടെ ഫോട്ടോ എങ്ങനെ അപ്‌ലോഡ് ചെയ്യണമെന്ന് അറിയാമോ? അതെ അല്ലെങ്കിൽ അല്ല എന്ന് പറയുക.",
    upload_guide: "സ്ക്രീനിലെ ഫയൽ തിരഞ്ഞെടുക്കുക ബട്ടൺ ക്ലിക്ക് ചെയ്ത് ഫോട്ടോ അപ്‌ലോഡ് ചെയ്യുക.",
    upload_fallback: "അപ്‌ലോഡ് ചെയ്യാൻ സാധിക്കുന്നില്ലെങ്കിൽ ആധാർ നമ്പർ സംസാരിച്ച് നൽകാം അല്ലെങ്കിൽ അക്ഷയ കേന്ദ്രം സന്ദർശിക്കാം.",
    aadhaar_prompt: "നിങ്ങളുടെ 12 അക്ക ആധാർ നമ്പർ പറയുക അല്ലെങ്കിൽ ടൈപ്പ് ചെയ്യുക.",
    aadhaar_confirm: "നിങ്ങൾ നൽകിയ ആധാർ നമ്പർ: {digits}. ഇത് ശരിയാണോ? അതെ അല്ലെങ്കിൽ അല്ല എന്ന് പറയുക.",
    aadhaar_verified_masked: "ആധാർ പരിശോധിച്ചു സുരക്ഷിതമായി സൂക്ഷിച്ചു. അവസാന 4 അക്കങ്ങൾ: {last4}.",
    aadhaar_err_digits: "നിങ്ങൾ നൽകിയത് {count} അക്കങ്ങളാണ്. കൃത്യം 12 അക്കങ്ങൾ ആവശ്യമാണ്.",
    aadhaar_err_verhoeff: "ആധാർ നമ്പർ പരിശോധനയിൽ പരാജയപ്പെട്ടു. ദയവായി വീണ്ടും നൽകുക.",
    voter_prompt: "നിങ്ങളുടെ 10 അക്ഷര വോട്ടർ ഐഡി നമ്പർ നൽകുക.",
    voter_err: "വോട്ടർ ഐഡി 3 അക്ഷരങ്ങളും 7 അക്കങ്ങളും ആയിരിക്കണം (ഉദാ: ABC1234567).",
    error_repeat_slow: "വ്യക്തമായി കേൾക്കാൻ കഴിഞ്ഞില്ല. സാവധാനം ആവർത്തിക്കാം.",
    help_center_fallback: "മൂന്ന് ശ്രമങ്ങൾക്ക് ശേഷം മനസ്സിലാക്കാൻ കഴിഞ്ഞില്ല. നേരിട്ട് സഹായത്തിനായി അടുത്തുള്ള അക്ഷയ കേന്ദ്രം സന്ദർശിക്കാം. {center_info}",
    repeat_command: "ആവർത്തിക്കുന്നു.",
    back_command: "മുൻപത്തെ ഘട്ടത്തിലേക്ക് പോകുന്നു.",
    stop_command: "വോയ്സ് ഗൈഡ് നിർത്തി."
  },
  hi: {
    name: "Hindi",
    native: "हिन्दी",
    code: "hi-IN",
    which_lang_ask: "आपको कौन सी भाषा चाहिए?",
    confirm_chosen: "आपने हिन्दी का चयन किया है। हम हिन्दी में जारी रखेंगे।",
    help_question: "नमस्ते! क्या आपको सहायता चाहिए? हाँ या नहीं बोलिए।",
    yes_words: ["हाँ", "haan", "जी हाँ", "चाहिए", "सही", "yes"],
    no_words: ["नहीं", "nahi", "ना", "मत", "no"],
    yes_btn: "हाँ (Yes)",
    no_btn: "नहीं (No)",
    auth_choice: "क्या आप पहले से पंजीकृत नागरिक हैं या नए नागरिक हैं? 'पंजीकृत' या 'नया' बोलिए।",
    auth_choice_label: "पंजीकृत नागरिक या नया नागरिक",
    login_guide: "स्क्रीन के बीच में दिए गए बॉक्स में अपना पंजीकृत ईमेल या मोबाइल नंबर दर्ज करें। उसके नीचे पासवर्ड लिखें और साइन इन बटन दबाएं।",
    login_email_pos: "स्क्रीन के बीच में ईमेल या मोबाइल नंबर बॉक्स",
    privacy_consent: "विवरण लेने से पहले: यह विवरण केवल सरकारी कल्याणकारी योजनाओं से मिलान करने के लिए उपयोग किया जाता है। आपकी आवाज स्टोर नहीं होती। सहमति के लिए 'हाँ' बोलिए।",
    fields: {
      name: {
        label: "पूरा कानूनी नाम",
        pos: "ऊपर बाईं ओर का पहला बॉक्स",
        ask: "कृपया अपना पूरा नाम बताएं। ऊपर बाईं ओर पहले बॉक्स को देखें।",
        confirm: "आपका नाम {val} दर्ज कर लिया गया है।"
      },
      phone: {
        label: "10 अंकों का मोबाइल नंबर",
        pos: "ऊपर दाईं ओर का मोबाइल नंबर बॉक्स",
        ask: "कृपया अपना 10 अंकों का मोबाइल नंबर बताएं।",
        confirm: "आपका मोबाइल नंबर {val} दर्ज कर लिया गया है।"
      },
      age: {
        label: "आपकी उम्र (वर्षों में)",
        pos: "बीच का उम्र बॉक्स",
        ask: "कृपया अपनी उम्र बताएं। बीच में दिए गए उम्र बॉक्स को देखें।",
        confirm: "आपकी उम्र {val} दर्ज कर ली गई है।"
      },
      gender: {
        label: "लिंग (पुरुष, महिला, या ट्रांसजेंडर)",
        pos: "बाईं ओर लिंग चयन ड्रॉपडाउन",
        ask: "कृपया अपना लिंग बताएं: पुरुष, महिला, या ट्रांसजेंडर बोलें।",
        confirm: "लिंग {val} चुन लिया गया है।"
      },
      category: {
        label: "सामाजिक श्रेणी (सामान्य, ओबीसी, एससी, एसटी)",
        pos: "बीच में सामाजिक श्रेणी ड्रॉपडाउन",
        ask: "कृपया अपनी सामाजिक श्रेणी बताएं: सामान्य, ओबीसी, एससी, या एसटी बोलें।",
        confirm: "श्रेणी {val} चुन ली गई है।"
      },
      state: {
        label: "निवास राज्य",
        pos: "नीचे राज्य चयन ड्रॉपडाउन",
        ask: "आप किस राज्य में रहते हैं? जैसे तमिलनाडु या उत्तर प्रदेश बोलें।",
        confirm: "राज्य {val} चुन लिया गया है।"
      },
      income: {
        label: "वार्षिक पारिवारिक आय",
        pos: "दाईं ओर आय चयन ड्रॉपडाउन",
        ask: "कृपया अपनी पारिवारिक वार्षिक आय बताएं। दाईं ओर दिए गए आय बॉक्स को देखें।",
        confirm: "आय {val} चुन ली गई है।"
      },
      occupation: {
        label: "मुख्य व्यवसाय या कार्य",
        pos: "नीचे व्यवसाय चयन ड्रॉपडाउन",
        ask: "आपका मुख्य व्यवसाय क्या है? जैसे किसान, छोटा व्यापारी, छात्र, या मजदूर बोलें।",
        confirm: "व्यवसाय {val} चुन लिया गया है।"
      },
      password: {
        label: "गोपनीय पासवर्ड",
        pos: "नीचे पासवर्ड बॉक्स",
        ask: "कृपया नीचे दिए गए बॉक्स में अपना पासवर्ड दर्ज करें। पासवर्ड कभी भी जोर से नहीं बोला जाएगा। दर्ज करने के बाद 'हो गया' बोलें।",
        confirm: "पासवर्ड सुरक्षित रूप से दर्ज कर लिया गया है।"
      }
    },
    password_confirmed: "पासवर्ड सुरक्षित रूप से दर्ज कर लिया गया है और गोपनीय रखा गया है।",
    register_done: "सभी विवरण दर्ज कर लिए गए हैं! खाता बनाने के लिए बटन दबाएं या 'सबमिट' बोलें।",
    searching_schemes: "आपके लिए योजनाओं की खोज कर रहा हूँ...",
    scheme_num_prefix: "योजना संख्या {num}:",
    apply_intro: "आपने {title} योजना चुनी है। आवेदन के लिए आधार कार्ड, आय प्रमाण पत्र और बैंक पासबुक की आवश्यकता होगी। अब पहले बॉक्स में अपना नाम दर्ज करें।",
    problem_inquiry: "आपकी क्या समस्या है या आपको किस प्रकार की मदद चाहिए? उदाहरण के लिए: 'मैं किसान हूँ और मुझे कृषि ऋण चाहिए' बोल सकते हैं। अब बोलिए।",
    schemes_intro: "मैंने आपके लिए शीर्ष 3 सर्वोत्तम योजनाएं खोजी हैं।",
    choose_scheme: "आप कौन सी योजना चुनना चाहते हैं? पहली योजना, दूसरी योजना, या तीसरी योजना बोलिए।",
    upload_help_ask: "क्या आप दस्तावेज़ की फोटो अपलोड करना जानते हैं? हाँ या नहीं बोलिए।",
    upload_guide: "स्क्रीन पर दिए गए फाइल चुनें बटन पर क्लिक करके अपने फोन से फोटो चुनें या कैमरा से नई फोटो खींचें।",
    upload_fallback: "यदि आप फोटो अपलोड नहीं कर पा रहे हैं, तो आप अपना आधार नंबर बोलकर दर्ज कर सकते हैं या नजदीकी सहायता केंद्र जा सकते हैं।",
    aadhaar_prompt: "कृपया अपना 12 अंकों का आधार नंबर बोलें या टाइप करें।",
    aadhaar_confirm: "आपने आधार नंबर बताया: {digits}. क्या यह सही है? हाँ या नहीं बोलिए।",
    aadhaar_verified_masked: "आधार सत्यापित और सुरक्षित रूप से सहेज लिया गया है। अंतिम 4 अंक: {last4}。",
    aadhaar_err_digits: "आपने केवल {count} अंक बताए हैं। आधार के लिए पूरे 12 अंक जरूरी हैं।",
    aadhaar_err_verhoeff: "आधार नंबर सत्यापन विफल रहा। कृपया सही अंक दोबारा बताएं।",
    voter_prompt: "कृपया अपना 10 अक्षरों का वोटर आईडी नंबर दर्ज करें।",
    voter_err: "वोटर आईडी 3 अक्षर और 7 अंकों का होना चाहिए (उदा: ABC1234567).",
    error_repeat_slow: "आपकी आवाज साफ नहीं सुनाई दी। मैं धीरे से दोहराता हूँ।",
    help_center_fallback: "तीन प्रयासों के बाद समझ नहीं आया। आप सहायता के लिए नजदीकी सीएससी या सेवा केंद्र जा सकते हैं। {center_info}",
    repeat_command: "दोहरा रहा हूँ।",
    back_command: "पिछले चरण पर वापस जा रहे हैं।",
    stop_command: "आवाज सहायक रोक दिया गया है।"
  },
  ur: {
    name: "Urdu",
    native: "اردو",
    code: "ur-IN",
    which_lang_ask: "آپ کون سی زبان چاہتے ہیں؟",
    confirm_chosen: "آپ نے اردو کا انتخاب کیا ہے۔ ہم اردو میں جاری رکھیں گے۔",
    help_question: "ہیلو! کیا آپ کو مدد چاہیے؟ جی ہاں یا نہیں کہیں۔",
    yes_words: ["جی ہاں", "ہاں", "haan", "چاہیے", "theek", "yes"],
    no_words: ["نہیں", "nahi", "مت", "no"],
    yes_btn: "جی ہاں (Yes)",
    no_btn: "نہیں (No)",
    auth_choice: "کیا آپ رجسٹرڈ شہری ہیں یا نئے صارف ہیں؟ 'رجسٹرڈ' یا 'نیا صارف' کہیں۔",
    auth_choice_label: "رجسٹرڈ شہری یا نیا صارف",
    login_guide: "اسکرین کے بیچ والے باکس میں اپنا ای میل یا موبائل نمبر درج کریں۔ نیچے اپنا پاس ورڈ لکھیں اور سائن ان بٹن پر کلک کریں۔",
    login_email_pos: "درمیان والا ای میل یا موبائل نمبر باکس",
    privacy_consent: "تفصیلات جمع کرنے سے پہلے: آپ کی معلومات صرف سرکاری اسکیموں کے لیے استعمال کی جائیں گی۔ پاس ورڈ بلند آواز میں نہیں پڑھا جاتا۔ آگے بڑھنے کے لیے 'ٹھیک ہے' کہیں۔",
    fields: {
      name: {
        label: "مکمل قانونی نام",
        pos: "اوپر بائیں جانب کا پہلا باکس",
        ask: "براہ کرم اپنا مکمل نام بتائیں۔ اوپر پہلے باکس کو دیکھیں۔",
        confirm: "آپ کا نام {val} درج کر لیا گیا ہے۔"
      },
      phone: {
        label: "10 ہندسوں کا موبائل نمبر",
        pos: "اوپر دائیں جانب موبائل باکس",
        ask: "براہ کرم اپنا 10 ہندسوں کا موبائل نمبر بتائیں۔",
        confirm: "آپ کا موبائل نمبر {val} درج کر لیا گیا ہے۔"
      },
      age: {
        label: "آپ کی عمر (سالوں میں)",
        pos: "درمیان والا عمر کا باکس",
        ask: "براہ کرم اپنی عمر بتائیں۔ درمیان والے باکس کو دیکھیں۔",
        confirm: "آپ کی عمر {val} درج کر لی گئی ہے۔"
      },
      gender: {
        label: "جنس (مرد، عورت، خواجہ سرا)",
        pos: "بائیں جانب جنس کا انتخاب",
        ask: "براہ کرم اپنی جنس بتائیں: مرد، عورت، یا خواجہ سرا بولیں۔",
        confirm: "جنس {val} منتخب کی گئی ہے۔"
      },
      category: {
        label: "سماجی زمرہ (عام، او بی سی، ایس سی، ایس ٹی)",
        pos: "درمیان میں سماجی زمرہ",
        ask: "براہ کرم اپنا سماجی زمرہ بتائیں: جنرل، او بی سی، ایس سی، یا ایس ٹی بولیں۔",
        confirm: "زمرہ {val} منتخب کیا گیا ہے۔"
      },
      state: {
        label: "رہائشی ریاست",
        pos: "ریاست کا انتخاب",
        ask: "آپ کس ریاست میں رہتے ہیں؟ مثلاً تمل ناڈو بولیں۔",
        confirm: "ریاست {val} منتخب کی گئی ہے۔"
      },
      income: {
        label: "سالانہ خاندانی آمدنی",
        pos: "دائیں جانب آمدنی کا انتخاب",
        ask: "براہ کرم اپنی سالانہ خاندانی آمدنی بتائیں۔ دائیں جانب کے باکس کو دیکھیں۔",
        confirm: "آمدنی {val} منتخب کی گئی ہے۔"
      },
      occupation: {
        label: "بنیادی پیشہ یا کام",
        pos: "پیشہ کا انتخاب",
        ask: "آپ کا بنیادی پیشہ کیا ہے؟ مثلاً کسان، دکاندار، طالب علم، یا مزدور بولیں۔",
        confirm: "پیشہ {val} منتخب کیا گیا ہے۔"
      },
      password: {
        label: "خفیہ پاس ورڈ",
        pos: "نیچے پاس ورڈ کا باکس",
        ask: "براہ کرم نیچے والے باکس میں اپنا پاس ورڈ درج کریں۔ پاس ورڈ کبھی بھی بلند آواز میں نہیں پڑھا جائے گا۔ درج کرنے کے بعد 'ہو گیا' بولیں۔",
        confirm: "پاس ورڈ محفوظ طریقے سے درج کر لیا گیا ہے۔"
      }
    },
    password_confirmed: "پاس ورڈ محفوظ طریقے سے درج کر لیا گیا ہے اور خفیہ رکھا گیا ہے۔",
    register_done: "تمام تفصیلات درج کر لی گئی ہیں! اکاؤنٹ بنانے کے لیے بٹن دبائیں یا 'جمع کریں' بولیں۔",
    searching_schemes: "آپ کے لیے سرکاری اسکیمیں تلاش کی جا رہی ہیں...",
    scheme_num_prefix: "اسکیم نمبر {num}:",
    apply_intro: "آپ نے {title} اسکیم کا انتخاب کیا ہے۔ درخواست کے لیے آدھار کارڈ، آمدنی کا سرٹیفکیٹ اور بینک پاس بک درکار ہوگی۔ اب پہلے باکس میں اپنا نام درج کریں۔",
    problem_inquiry: "آپ کی کیا پریشانی ہے یا آپ کو کس قسم کی مدد چاہیے؟ مثال کے طور پر: 'میں کسان ہوں اور مجھے قرض چاہیے'۔ اب بولیں۔",
    schemes_intro: "میں نے آپ کے لیے 3 بہترین اسکیمیں تلاش کی ہیں۔",
    choose_scheme: "آپ کون سی اسکیم منتخب کرنا چاہتے ہیں؟ پہلی، دوسری یا تیسری کہیں۔",
    upload_help_ask: "کیا آپ جانتے ہیں کہ دستاویز کی تصویر کیسے اپ لوڈ کی جائے؟ جی ہاں یا نہیں کہیں۔",
    upload_guide: "اسکرین پر اپ لوڈ بٹن پر کلک کریں اور اپنے آلے سے تصویر منتخب کریں۔",
    upload_fallback: "اگر آپ اپ لوڈ نہیں کر سکتے ہیں تو آپ اپنا آدھار نمبر بول سکتے ہیں یا قریبی خدمت مرکز جا سکتے ہیں۔",
    aadhaar_prompt: "براہ کرم اپنا 12 ہندسوں کا آدھار نمبر بولیں یا ٹائپ کریں۔",
    aadhaar_confirm: "آپ نے آدھار نمبر بتایا: {digits}۔ کیا یہ درست ہے؟ جی ہاں یا نہیں کہیں۔",
    aadhaar_verified_masked: "آدھار کی تصدیق ہو گئی ہے اور محفوظ کر لیا گیا ہے۔ آخری 4 ہندسے: {last4}۔",
    aadhaar_err_digits: "آپ نے {count} ہندسے فراہم کیے ہیں۔ آدھار کے لیے بالکل 12 ہندسے درکار ہیں۔",
    aadhaar_err_verhoeff: "آدھار نمبر کی تصدیق ناکام ہو گئی۔ براہ کرم نمبر دوبارہ چیک کریں۔",
    voter_prompt: "براہ کرم اپنا 10 ہندسوں کا ووٹر کارڈ نمبر درج کریں۔",
    voter_err: "ووٹر آئی ڈی 3 حروف اور 7 ہندسوں پر مشتمل ہونا چاہیے (مثال: ABC1234567)۔",
    error_repeat_slow: "آپ کی آواز صاف سنائی نہیں دی۔ میں آہستہ سے دہراتا ہوں۔",
    help_center_fallback: "تین کوششوں کے بعد سمجھ نہیں آیا۔ آپ قریبی ای-سیوا مرکز تشریف لے جا سکتے ہیں۔ {center_info}",
    repeat_command: "دہرا رہا ہوں۔",
    back_command: "پچھلے مرحلے پر جا رہے ہیں۔",
    stop_command: "صوتی رہنما روک دیا گیا ہے۔"
  }
};

// Language detection recognition aliases
const LANG_ALIASES = {
  ta: ["tamil", "தமிழ்", "தமில்", "tamizh", "thamizh", "தமிழ்நாடு", "तमिल", "తమిళం", "ತಮಿಳು", "തമിഴ്", "تامل"],
  en: ["english", "ஆங்கிலம்", "अंग्रेजी", "ఇంగ్లీష్", "ಇಂಗ್ಲಿಷ್", "ഇംഗ്ലീഷ്", "انگریزی", "inglis"],
  te: ["telugu", "తెలుగు", "தெலுங்கு", "तेलुगु", "ತೆಲುಗು", "തെലുങ്ക്", "تیلگو"],
  kn: ["kannada", "ಕನ್ನಡ", "கன்னடம்", "कन्नड़", "కన్నడ", "കന്നഡ", "کنڑ"],
  ml: ["malayalam", "മലയാളം", "மலையாளം", "मलयालम", "మలయాళం", "ಮಲಯಾಳಂ", "ملیالم"],
  hi: ["hindi", "हिन्दी", "हिंदी", "இந்தி", "హిందీ", "ಹಿಂದಿ", "ഹിന്ദി", "ہندی"],
  ur: ["urdu", "اردو", "உருது", "उर्दू", "ఉర్దూ", "ಉರ್ದು", "ഉർദു"]
};

// Verhoeff Tables in JavaScript for instant client-side Aadhaar validation
const VERHOEFF_D_JS = [
  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
  [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
  [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
  [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
  [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
  [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
  [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
  [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
  [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
  [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
];
const VERHOEFF_P_JS = [
  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
  [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
  [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
  [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
  [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
  [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
  [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
  [7, 0, 4, 6, 9, 1, 3, 2, 5, 8]
];

function validateVerhoeffJS(numStr) {
  if (!/^\d+$/.test(numStr)) return false;
  let c = 0;
  const reversed = numStr.split("").reverse().map(Number);
  for (let i = 0; i < reversed.length; i++) {
    c = VERHOEFF_D_JS[c][VERHOEFF_P_JS[i % 8][reversed[i]]];
  }
  return c === 0;
}

// ---------------------------------------------------------------------------
// Multilingual Spoken Digit & Number Parsers for All 7 Languages
// ---------------------------------------------------------------------------
function parseSpokenDigits(raw) {
  if (!raw) return "";
  let t = raw.toString().toLowerCase();

  // 1. Indic Unicode Digits -> ASCII
  const indicDigits = {
    // Tamil
    "௦": "0", "௧": "1", "௨": "2", "௩": "3", "௪": "4", "௫": "5", "௬": "6", "௭": "7", "௮": "8", "௯": "9",
    // Devanagari
    "०": "0", "१": "1", "२": "2", "३": "3", "४": "4", "५": "5", "६": "6", "७": "7", "८": "8", "९": "9",
    // Telugu
    "౦": "0", "౧": "1", "౨": "2", "౩": "3", "౪": "4", "౫": "5", "౬": "6", "౭": "7", "౮": "8", "౯": "9",
    // Kannada
    "೦": "0", "೧": "1", "೨": "2", "೩": "3", "೪": "4", "೫": "5", "೬": "6", "೭": "7", "೮": "8", "೯": "9",
    // Malayalam
    "൦": "0", "൧": "1", "൨": "2", "൩": "3", "൪": "4", "൫": "5", "൬": "6", "൭": "7", "൮": "8", "൯": "9",
    // Urdu / Arabic
    "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4", "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9"
  };
  for (const [k, v] of Object.entries(indicDigits)) {
    t = t.split(k).join(v);
  }

  // 2. Multilingual Digit Words Replacement
  const wordDigitMap = [
    // 0
    { re: /(zero|பூஜ்ஜியம்|பூஜ்யம்|शून्य|ज़ीरो|జీరో|సున్నా|ಸೊನ್ನೆ|പൂജ്യം|صفر)/gi, val: "0" },
    // 1
    { re: /(one|ஒன்று|ஒன்னு|ஒரு|एक|ఒకటి|ఒక|ಒಂದು|ഒന്ന്|ایک)/gi, val: "1" },
    // 2
    { re: /(two|இரண்டு|ரெண்டு|दो|రెండు|ಎರಡು|രണ്ട്|دو)/gi, val: "2" },
    // 3
    { re: /(three|மூன்று|மூணு|तीन|మూడు|ಮೂರು|മൂന്ന്|تین)/gi, val: "3" },
    // 4
    { re: /(four|நான்கு|நாலு|चार|నాలుగు|ನಾಲ್ಕು|നാല്|چار)/gi, val: "4" },
    // 5
    { re: /(five|ஐந்து|அஞ்சு|पाँच|पांच|ఐదు|ಐದು|അഞ്ച്|پانچ)/gi, val: "5" },
    // 6
    { re: /(six|ஆறு|छह|ఆరు|ಆರು|ആറ്|چھ)/gi, val: "6" },
    // 7
    { re: /(seven|ஏழு|सात|ఏడు|ಏಳು|ഏഴ്|सात)/gi, val: "7" },
    // 8
    { re: /(eight|எட்டு|आठ|ఎనిమిది|ಎಂಟು|എട്ട്|آٹھ)/gi, val: "8" },
    // 9
    { re: /(nine|ஒன்பது|नौ|తొమ్మిది|ಒಂಬತ್ತು|ഒമ്പത്|نو)/gi, val: "9" }
  ];

  for (const item of wordDigitMap) {
    t = t.replace(item.re, item.val);
  }

  return t.replace(/\D/g, "");
}

function parseSpokenAge(raw) {
  if (!raw) return null;
  const digits = parseSpokenDigits(raw);
  if (digits && digits.length >= 2 && digits.length <= 3) {
    const val = parseInt(digits.slice(0, 3), 10);
    if (val >= 10 && val <= 110) return val;
  }

  const t = raw.toString().toLowerCase();

  // Multi-digit spoken age phrases across 7 languages
  const ageWordMap = {
    // Tamil
    "இருபத்தெட்டு": 28, "இருபத்தி எட்டு": 28, "இருபத்தி ஐந்து": 25, "இருபத்தைந்து": 25,
    "இருபது": 20, "இருபத்தொன்று": 21, "இருபத்திரண்டு": 22, "இருபத்திமூன்று": 23, "இருபத்துநான்கு": 24,
    "இருபத்தாறு": 26, "இருபத்தேழு": 27, "இருபத்தொன்பது": 29,
    "முப்பது": 30, "முப்பத்தைந்து": 35, "முப்பத்தெட்டு": 38,
    "நாற்பது": 40, "நாற்பத்தைந்து": 45, "ஐம்பது": 50, "ஐம்பத்தைந்து": 55,
    "அறுபது": 60, "அறுபத்தைந்து": 65, "எழுபது": 70, "எழுபத்தைந்து": 75, "எண்பது": 80,
    // Hindi
    "बीस": 20, "इक्कीस": 21, "बाईस": 22, "तेईस": 23, "चौबीस": 24, "पच्चीस": 25, "छब्बीस": 26, "सत्ताईस": 27, "अट्ठाईस": 28, "अठाईस": 28, "उनतीस": 29,
    "तीस": 30, "पैंतीस": 35, "चालीस": 40, "पैंतालीस": 45, "पचास": 50, "पचपन": 55, "साठ": 60, "पैंसठ": 65, "सत्तर": 70, "अस्सी": 80,
    // Telugu
    "ఇరవై": 20, "ఇరవై ఎనిమిది": 28, "ఇరవై ఐదు": 25, "ముప్పై": 30, "నలభై": 40, "యాభై": 50, "అరవై": 60,
    // Kannada
    "ಇಪ್ಪತ್ತು": 20, "ಇಪ್ಪತ್ತೆಂಟು": 28, "ಇಪ್ಪತ್ತೈದು": 25, "ಮೂವತ್ತು": 30, "ನಲವತ್ತು": 40, "ಐವತ್ತು": 50,
    // Malayalam
    "ഇരുപത്": 20, "ഇരുപത്തിയെട്ട്": 28, "ഇരുപത്തിയഞ്ച്": 25, "മുപ്പത്": 30, "നാൽപ്പത്": 40, "അമ്പത്": 50,
    // Urdu
    "بیس": 20, "اٹھائیس": 28, "پچیس": 25, "تیس": 30, "چالیس": 40, "پچاس": 50,
    // English
    "twenty": 20, "twenty one": 21, "twenty two": 22, "twenty three": 23, "twenty four": 24,
    "twenty five": 25, "twenty six": 26, "twenty seven": 27, "twenty eight": 28, "twenty nine": 29,
    "thirty": 30, "thirty five": 35, "forty": 40, "forty five": 45, "fifty": 50, "fifty five": 55,
    "sixty": 60, "sixty five": 65, "seventy": 70, "eighty": 80
  };

  for (const [w, val] of Object.entries(ageWordMap)) {
    if (t.includes(w)) {
      return val;
    }
  }

  const m = t.match(/\b(1[0-9]|[2-9][0-9]|10[0-9]|110)\b/);
  if (m) return parseInt(m[0], 10);

  return null;
}

function matchMultilingualOption(fieldKey, spokenText, selectEl) {
  if (!selectEl) return null;
  const t = spokenText.toLowerCase().trim();

  // 1. Gender mapping
  if (fieldKey === "gender") {
    const maleAliases = ["male", "man", "boy", "ஆண்", "ஆண் நபர்", "ஆம்பள", "aan", "पुरुष", "आदमी", "పురుషుడు", "పురుష", "ಗಂಡು", "ಪುರುಷ", "ആൺ", "പുരുഷൻ", "مرد"];
    const femaleAliases = ["female", "woman", "lady", "girl", "பெண்", "பெண் நபர்", "பொம்பள", "மகளிர்", "pen", "महिला", "स्त्री", "औरत", "స్త్రీ", "మహిళ", "ఆడ", "ಹೆಣ್ಣು", "ಮಹಿಳೆ", "സ്ത്രീ", "പെൺ", "عورت", "خاتون"];
    const transAliases = ["transgender", "third gender", "trans", "திருநங்கை", "திருநம்பி", "மூன்றாம் பாலினம்", "किन्नर", "ट्रांसजेंडर", "ట్రాన్స్‌జెండర్", "ತೃತೀಯ ಲಿಂಗ", "ട്രാൻസ്‌ജെൻഡർ", "خواجہ سرا"];

    if (femaleAliases.some(a => t.includes(a))) return "Female";
    if (transAliases.some(a => t.includes(a))) return "Transgender";
    if (maleAliases.some(a => t.includes(a))) return "Male";
  }

  // 2. Social Category mapping
  if (fieldKey === "category") {
    const obcAliases = ["obc", "bc", "mbc", "b.c.", "o.b.c.", "பிற்படுத்தப்பட்டோர்", "பிற்படுத்தப்பட்ட", "ஓபிசி", "பிசி", "எம்பிசி", "ओबीसी", "पिछड़ा", "ఓబీసీ", "బీసీ", "ಒಬಿಸಿ", "ಹಿಂದುಳಿದ", "ഒബിസി", "പിന്നോക്ക", "او بی سی"];
    const scAliases = ["sc", "s.c.", "தாழ்த்தப்பட்டோர்", "பட்டியலினம்", "பட்டியல் இனம்", "எஸ்சி", "एससी", "अनुसूचित जाति", "ఎస్సీ", "షెడ్యూల్డ్", "ಎಸ್ಸಿ", "ಪರಿಶಿಷ್ಟ ಜಾತಿ", "എസ് സി", "പട്ടികജാതി", "ایس سی"];
    const stAliases = ["st", "s.t.", "பழங்குடியினர்", "பழங்குடி", "எஸ்டி", "ஆதிவாசி", "एसटी", "अनुसूचित जनजाति", "आदिवासी", "ఎస్టీ", "ఆదివాసీ", "ಎಸ್ಟಿ", "ಪರಿಶಿಷ್ಟ ಪಂಗಡ", "എസ് ടി", "പട്ടികവർഗ്ഗം", "ایس ٹی"];
    const ewsAliases = ["ews", "e.w.s.", "இடபிள்யுஎஸ்", "ईडब्ल्यूएस", "ఈడబ్ల్యూఎస్", "ಇಡಬ್ಲ್ಯೂಎಸ್", "ഇഡബ്ല്യുഎസ്", "ای ڈبلیو ایس", "economically weaker"];
    const genAliases = ["general", "oc", "பொது", "பொதுப்பிரிவு", "முன்னேறிய", "सामान्य", "जनरल", "జనరల్", "ಸಾಮಾನ್ಯ", "ജനറൽ", "عام"];

    if (obcAliases.some(a => t.includes(a))) return "OBC";
    if (scAliases.some(a => t.includes(a))) return "SC";
    if (stAliases.some(a => t.includes(a))) return "ST";
    if (ewsAliases.some(a => t.includes(a))) return "EWS";
    if (genAliases.some(a => t.includes(a))) return "General";
  }

  // 3. State mapping
  if (fieldKey === "state") {
    const statesMap = {
      "Tamil Nadu": ["tamil nadu", "tamilnadu", "தமிழ்நாடு", "தமிழ் நாடு", "தமிழ்", "तमिलनाडु", "తమిళనాడు", "ತಮಿಳುನಾಡು", "തമിഴ്‌നാട്", "تمل ناڈو"],
      "Karnataka": ["karnataka", "கர்நாடகா", "கருநாடகம்", "कर्नाटक", "కర్ణాటక", "ಕರ್ನಾಟಕ", "ಕರ್ನಾಟಕ", "کرناٹک"],
      "Kerala": ["kerala", "கேரளா", "கேரளம்", "केरल", "కేరళ", "ಕೇರಳ", "കേരളം", "کیرالہ"],
      "Andhra Pradesh": ["andhra", "andhra pradesh", "ஆந்திரா", "ஆந்திரப் பிரதேசம்", "आंध्र प्रदेश", "ఆంధ్రప్రదేశ్", "ಆಂಧ್ರ ಪ್ರದೇಶ", "ആന്ധ്രാപ്രദേശ്", "آندھرا پردیش"],
      "Telangana": ["telangana", "தெலுங்கானா", "தெலங்கானா", "तेलंगाना", "తెలంగాణ", "ತೆಲಂಗಾಣ", "തെലങ്കാന", "تلنگانہ"],
      "Maharashtra": ["maharashtra", "மகாராஷ்டிரா", "महाराष्ट्र", "మహారాష్ట్ర", "ಮಹಾರಾಷ್ಟ್ರ", "ಮಹಾരാഷ്ട്ര", "مہاراشٹر"],
      "Uttar Pradesh": ["uttar pradesh", "உத்தரப் பிரதேசம்", "उत्तर प्रदेश", "ఉత్తర ప్రదేశ్", "ಉತ್ತರ ಪ್ರದೇಶ", "ഉത്തർപ്രദേശ്", "اتر پردیش", "up"],
      "Gujarat": ["gujarat", "குஜராத்", "गुजरात", "గుజరాత్", "ಗುಜರಾತ್", "ഗുജറാത്ത്", "گجرات"],
      "West Bengal": ["west bengal", "bengal", "மேற்கு வங்கம்", "पश्चिम बंगाल", "పశ్చిమ బెంగాల్", "ಪಶ್ಚಿಮ ಬಂಗಾಳ", "പശ്ചിമ ബംഗാൾ", "مغربی بنگال"],
      "Delhi": ["delhi", "டெல்லி", "தில்லி", "दिल्ली", "ఢిల్లీ", "ದೆಹಲಿ", "ഡൽഹി", "دہلی"]
    };

    for (const [st, aliases] of Object.entries(statesMap)) {
      if (aliases.some(a => t.includes(a))) return st;
    }
  }

  // 4. Annual Income mapping
  if (fieldKey === "income") {
    const digits = parseSpokenDigits(t);
    if (digits) {
      const num = parseInt(digits, 10);
      if (num > 0) {
        if (num < 100000) return "100000";
        if (num <= 250000) return "180000";
        if (num <= 500000) return "400000";
        if (num <= 800000) return "750000";
        return "1200000";
      }
    }

    if (t.includes("bpl") || t.includes("குறைவு") || t.includes("வறுமை") || t.includes("கீழ்") || t.includes("कम") || t.includes("తక్కువ") || t.includes("below") || t.includes("less") || t.includes("50000") || t.includes("ஐம்பதாயிரம்")) {
      return "100000";
    }
    if (t.includes("ஒன்றரை") || t.includes("இரண்டு லட்சம்") || t.includes("ஒரு லட்சம்") || t.includes("இரண்டரை") || t.includes("1 lakh") || t.includes("one lakh") || t.includes("2 lakh") || t.includes("डेढ़") || t.includes("दो लाख") || t.includes("లక్ష")) {
      return "180000";
    }
    if (t.includes("மூன்று லட்சம்") || t.includes("நான்கு லட்சம்") || t.includes("ஐந்து லட்சம்") || t.includes("3 lakh") || t.includes("4 lakh") || t.includes("5 lakh") || t.includes("तीन लाख") || t.includes("चार लाख") || t.includes("पाँच लाख")) {
      return "400000";
    }
    if (t.includes("ஆறு லட்சம்") || t.includes("ஏழு லட்சம்") || t.includes("எட்டு லட்சம்") || t.includes("6 lakh") || t.includes("7 lakh") || t.includes("8 lakh") || t.includes("छह लाख") || t.includes("सात लाख") || t.includes("आठ लाख")) {
      return "750000";
    }
    if (t.includes("மேல்") || t.includes("பத்து லட்சம்") || t.includes("above") || t.includes("more than") || t.includes("10 lakh") || t.includes("अधिक") || t.includes("ఎక్కువ") || t.includes("ಹೆಚ್ಚು")) {
      return "1200000";
    }
  }

  // 5. Occupation mapping
  if (fieldKey === "occupation") {
    const farmerAliases = ["farmer", "farm", "agri", "agriculture", "kisan", "விவசாயி", "விவசாயம்", "உழவர்", "பயிர்", "किसान", "खेती", "कृषि", "రైతు", "వ్యవసాయం", "ರೈತ", "ಕೃಷಿ", "കർഷകൻ", "കൃഷി", "کسان", "کاشتکار"];
    const businessAliases = ["business", "shop", "trader", "store", "merchant", "வணிகம்", "வியாபாரம்", "கடை", "தொழில்", "வியாபாரி", "சிறு தொழில்", "व्यापार", "दुकान", "छोटा व्यवसाय", "వ్యాపారం", "దుకాణం", "ವ್ಯಾಪಾರ", "ಅಂಗಡಿ", "വ്യാപാരം", "കട", "کاروبار", "دکان"];
    const studentAliases = ["student", "study", "studying", "college", "school", "மாணவர்", "மாணவி", "படிப்பு", "படிக்கிறேன்", "கல்லூரி", "छात्र", "विद्यार्थी", "पढ़ाई", "విద్యార్థి", "చదువు", "ವಿದ್ಯಾರ್ಥಿ", "വിദ്യാർത്ഥി", "طالب علم"];
    const homemakerAliases = ["homemaker", "housewife", "domestic", "home", "இல்லத்தரசி", "வீட்டு வேலை", "மனைவி", "குடும்பத் தலைவி", "गृहिणी", "हाउसवाइफ", "గృహిణి", "ఇంటి పని", "ಗೃಹಸ್ಥ", "വീട്ടമ്മ", "گھریلو خاتون"];
    const artisanAliases = ["artisan", "craft", "handloom", "weaver", "potter", "கைவினைஞர்", "நெசவாளர்", "கைத்தறி", "தையல்", "கொல்லர்", "कारीगर", "हथकरघा", "చేతివృత్తుల", "చేనేత", "ಕುಶಲಕರ್ಮಿ", "കരകൗശല", "دستکار"];
    const wageAliases = ["daily wage", "wage", "labor", "labour", "construction", "coolie", "worker", "கூலி", "கூலி வேலை", "தினக்கூலி", "கட்டுமான வேலை", "தொழிலாளி", "मजदूर", "मजदूरी", "दिहाड़ी", "శ్రామికుడు", "కూలీ", "ಕಾರ್ಮಿಕ", "കൂലിപ്പണി", "محنت کش"];
    const unemployedAliases = ["unemployed", "job seeker", "no job", "looking for job", "வேலையில்லாத", "வேலை தேடுபவர்", "வேலை இல்லை", "बेरोजगार", "నిరుద్యోగి", "ನಿರುದ್ಯೋಗಿ", "തൊഴിൽരഹിതൻ", "بے روزگار"];

    if (farmerAliases.some(a => t.includes(a))) return "Farmer";
    if (businessAliases.some(a => t.includes(a))) return "Small Business Owner";
    if (studentAliases.some(a => t.includes(a))) return "Student";
    if (homemakerAliases.some(a => t.includes(a))) return "Homemaker";
    if (artisanAliases.some(a => t.includes(a))) return "Artisan";
    if (wageAliases.some(a => t.includes(a))) return "Daily Wage Worker";
    if (unemployedAliases.some(a => t.includes(a))) return "Unemployed Youth";
  }

  for (const opt of selectEl.options) {
    if (opt.text.toLowerCase().includes(t) || opt.value.toLowerCase().includes(t)) {
      return opt.value;
    }
  }

  return null;
}

class CitizenVoiceGuide {
  constructor() {
    this.active = false;
    this.state = "IDLE"; // LANG_SELECT, HELP_QUESTION, AUTH_CHOICE, LOGIN_GUIDE, REGISTER_PRIVACY, REGISTER_FIELDS, PROBLEM, SCHEMES, SCHEME_CHOICE, APPLY, AADHAAR_ENTRY, AADHAAR_CONFIRM, UPLOAD_GUIDE
    this.history = [];
    this.consecutiveErrors = 0;
    this.maxErrors = 3;

    this.speechSynth = window.speechSynthesis || null;
    this.recognition = null;
    this.isListening = false;
    this.speechRate = 0.88;
    this.lang = localStorage.getItem("scheme_lang_pref") || "ta";
    if (!VOICE_CONFIG_7[this.lang]) this.lang = "ta";

    this.currentAudio = null;
    this.isPlayingAudio = false;
    this.languageSequenceActive = false;
    this.availableVoices = [];

    // Nearest help center cached info
    this.nearestHelpCenter = null;

    // Field guidance journey
    this.registerFieldIdx = 0;
    this.registerFields = [
      { id: "regName", key: "name", label: "full legal name", selector: "#regName", pos: "the first box on the top left" },
      { id: "regPhone", key: "phone", label: "10-digit mobile number", selector: "#regPhone", pos: "the mobile number box on the top right" },
      { id: "regAge", key: "age", label: "age in years", selector: "#regAge", pos: "the age box in the middle" },
      { id: "regGender", key: "gender", label: "gender (Male, Female, or Transgender)", selector: "#regGender", pos: "the gender dropdown on the left" },
      { id: "regCategory", key: "category", label: "social category (General, OBC, SC, ST, or EWS)", selector: "#regCategory", pos: "the category dropdown in the middle" },
      { id: "regState", key: "state", label: "state of residence", selector: "#regState", pos: "the state box in the middle" },
      { id: "regIncome", key: "income", label: "annual family income", selector: "#regIncome", pos: "the income dropdown on the right" },
      { id: "regOccupation", key: "occupation", label: "primary occupation or work", selector: "#regOccupation", pos: "the occupation dropdown below" },
      { id: "regPassword", key: "password", label: "secret password", selector: "#regPassword", pos: "the password box at the bottom", isPassword: true }
    ];
    this.collectedUserData = {};

    // Schemes state
    this.topSchemes = [];
    this.selectedScheme = null;

    // ID validation temporary state
    this.pendingAadhaarDigits = "";
    this.pendingVoterId = "";

    // Visual pointer
    this.spotlightEl = null;
    this.pointerEl = null;

    this.initSpeechSynth();
    this.initSpeechRecognition();
  }

  init() {
    this.bindGlobalEvents();
    this.bindUIButtons();
    this.fetchNearestHelpCenter();

    // Listen for language changes across website
    window.addEventListener("schemeLanguageChanged", (e) => {
      if (e.detail && e.detail.lang) {
        this.lang = e.detail.lang;
      }
    });

    // STEP 1: VOICE STARTS BY ITSELF AND ASKS FOR THE LANGUAGE
    const stopped = sessionStorage.getItem("voice_guide_manually_stopped") === "true";
    const savedState = sessionStorage.getItem("voice_guide_state");

    if (!stopped) {
      if (savedState === "REGISTER_FIELDS" && window.location.pathname.includes("/register")) {
        setTimeout(() => {
          this.active = true;
          this.showBanner();
          this.renderRegisterFieldStep();
        }, 500);
      } else if (savedState === "LOGIN_GUIDE" && window.location.pathname.includes("/login")) {
        setTimeout(() => {
          this.active = true;
          this.showBanner();
          this.renderLoginGuideStep();
        }, 500);
      } else {
        setTimeout(() => {
          this.startLanguageSelectionStep();
        }, 350);
      }
    }
  }

  initSpeechSynth() {
    if (!this.speechSynth) return;
    this.availableVoices = this.speechSynth.getVoices();
    if (this.speechSynth.onvoiceschanged !== undefined) {
      this.speechSynth.onvoiceschanged = () => {
        this.availableVoices = this.speechSynth.getVoices();
      };
    }
  }

  initSpeechRecognition() {
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRec) {
      this.recognition = new SpeechRec();
      this.recognition.continuous = false;
      this.recognition.interimResults = false;

      this.recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript.trim();
        this.consecutiveErrors = 0;
        this.handleVoiceInput(transcript);
      };

      this.recognition.onerror = (e) => {
        this.isListening = false;
        if (this.active && e.error !== "aborted") {
          this.handleSpeechError();
        }
      };

      this.recognition.onend = () => {
        this.isListening = false;
        this.updateSpeakerBadge(false);
      };
    }
  }

  fetchNearestHelpCenter() {
    // Attempt HTML5 geolocation or state fallback
    const fetchCenter = (lat = null, lng = null) => {
      let url = "/api/help-centers/nearest";
      if (lat && lng) url += `?lat=${lat}&lng=${lng}`;
      fetch(url)
        .then(res => res.json())
        .then(data => {
          if (data.success && data.nearest) {
            this.nearestHelpCenter = data.nearest;
          }
        })
        .catch(() => {});
    };

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => fetchCenter(pos.coords.latitude, pos.coords.longitude),
        () => fetchCenter(),
        { timeout: 4000 }
      );
    } else {
      fetchCenter();
    }
  }

  getHelpCenterDescription() {
    if (this.nearestHelpCenter) {
      const c = this.nearestHelpCenter;
      const dist = c.distance_km ? ` (about ${c.distance_km} km away)` : "";
      return `at ${c.name}, ${c.address}, ${c.city}${dist}. Phone: ${c.phone}`;
    }
    return "at your nearest e-service center or help center.";
  }

  updateSpeakerBadge(speaking = true, customText = null) {
    const badge = document.getElementById("voiceSpeakerBadge");
    const statusText = document.getElementById("voiceSpeakerStatusText");
    if (!badge) return;

    if (speaking || this.isListening) {
      badge.style.display = "flex";
      if (statusText) {
        statusText.textContent = customText || (speaking ? "Speaking..." : "Listening...");
      }
    } else {
      badge.style.display = "none";
    }
  }

  // =========================================================================
  // STEP 1: THE VOICE STARTS BY ITSELF AND ASKS FOR THE LANGUAGE
  // =========================================================================
  startLanguageSelectionStep() {
    this.active = true;
    this.state = "LANG_SELECT";
    sessionStorage.removeItem("voice_guide_manually_stopped");

    this.showBanner();
    this.clearModals();

    const langModal = document.getElementById("voiceGuideLangModal");
    if (langModal) langModal.style.display = "flex";

    this.updateSpeakerBadge(true, "Language Guide Starting...");

    // Try starting speech automatically. If blocked by browser autoplay policy,
    // start on the very first touch/click/keypress anywhere on page.
    let autoplayBlocked = false;

    const playSequence = () => {
      this.languageSequenceActive = true;
      this.playSequentialLanguageNames(0);
    };

    // Attempt direct play
    try {
      playSequence();
    } catch (err) {
      autoplayBlocked = true;
    }

    // Attach one-time global touch/click/key fallback for blocked autoplay
    const unblockHandler = () => {
      document.removeEventListener("click", unblockHandler, true);
      document.removeEventListener("touchstart", unblockHandler, true);
      document.removeEventListener("keydown", unblockHandler, true);

      if (this.state === "LANG_SELECT" && !this.isPlayingAudio) {
        playSequence();
      }
    };

    document.addEventListener("click", unblockHandler, true);
    document.addEventListener("touchstart", unblockHandler, true);
    document.addEventListener("keydown", unblockHandler, true);

    // Listen across languages for language choice by voice
    this.listenForLanguageChoice();
  }

  playSequentialLanguageNames(index) {
    if (!this.languageSequenceActive || this.state !== "LANG_SELECT") return;

    const sequence = [
      { lang: "ta", text: "தமிழ்" },
      { lang: "en", text: "English" },
      { lang: "te", text: "తెలుగు" },
      { lang: "kn", text: "ಕನ್ನಡ" },
      { lang: "ml", text: "മലയാളം" },
      { lang: "hi", text: "हिन्दी" },
      { lang: "ur", text: "اردو" }
    ];

    if (index < sequence.length) {
      const item = sequence[index];
      // Highlight the corresponding button
      document.querySelectorAll(".voice-7-btn").forEach(b => b.classList.remove("active"));
      const btn = document.querySelector(`.voice-7-btn[data-lang="${item.lang}"]`);
      if (btn) btn.classList.add("active");

      this.speakTextInLang(item.text, item.lang, () => {
        if (this.languageSequenceActive && this.state === "LANG_SELECT") {
          setTimeout(() => {
            this.playSequentialLanguageNames(index + 1);
          }, 300);
        }
      });
    } else {
      // Now ask "Which language do you want?" in each language
      this.playWhichLanguageQuestions(0);
    }
  }

  playWhichLanguageQuestions(index) {
    if (!this.languageSequenceActive || this.state !== "LANG_SELECT") return;

    const questions = [
      { lang: "ta", text: "எந்த மொழி வேண்டும்?" },
      { lang: "en", text: "Which language do you want?" },
      { lang: "te", text: "మీకు ఏ భాష కావాలి?" },
      { lang: "kn", text: "ಯಾವ ಭಾಷೆ ಬೇಕು?" },
      { lang: "ml", text: "ഏത് ഭാഷയാണ് വേണ്ടത്?" },
      { lang: "hi", text: "आपको कौन सी भाषा चाहिए?" },
      { lang: "ur", text: "آپ کون سی زبان چاہتے ہیں؟" }
    ];

    if (index < questions.length) {
      const q = questions[index];
      this.speakTextInLang(q.text, q.lang, () => {
        if (this.languageSequenceActive && this.state === "LANG_SELECT") {
          setTimeout(() => {
            this.playWhichLanguageQuestions(index + 1);
          }, 400);
        }
      });
    } else {
      // Keep listening for choice
      this.listenForLanguageChoice();
    }
  }

  listenForLanguageChoice() {
    if (!this.recognition) return;
    try { this.recognition.abort(); } catch (e) {}

    // Set recognition to Indian English or regional
    this.recognition.lang = "en-IN";
    try {
      this.recognition.start();
      this.isListening = true;
      this.updateSpeakerBadge(false, "Listening for Language...");
    } catch (e) {}
  }

  selectLanguage(chosenLang) {
    if (!VOICE_CONFIG_7[chosenLang]) chosenLang = "en";

    // Stop language sequence immediately
    this.languageSequenceActive = false;
    this.stopAudioAndSpeech();

    this.lang = chosenLang;
    localStorage.setItem("scheme_lang_pref", chosenLang);

    // Switch entire website text
    if (window.i18n && window.i18n.setLanguage) {
      window.i18n.setLanguage(chosenLang);
    }

    // Confirmation in chosen language: "You chose Tamil. We will continue in Tamil."
    const conf = VOICE_CONFIG_7[chosenLang].confirm_chosen;
    this.updateSpeakerBadge(true, conf);

    this.speakTextInLang(conf, chosenLang, () => {
      // Transition immediately to STEP 2: The Help Question in chosen language
      this.transitionTo("HELP_QUESTION");
    });
  }

  // =========================================================================
  // STEP 2: THE HELP QUESTION, IN THE CHOSEN LANGUAGE
  // =========================================================================
  renderHelpQuestionStep() {
    this.clearModals();

    const cfg = VOICE_CONFIG_7[this.lang] || VOICE_CONFIG_7.en;
    const modal = document.getElementById("voiceGuideHelpModal");
    const titleEl = document.getElementById("voiceHelpQuestionTitle");
    const subEl = document.getElementById("voiceHelpQuestionSubtitle");
    const yesLabel = document.getElementById("voiceHelpYesLabel");
    const noLabel = document.getElementById("voiceHelpNoLabel");

    if (titleEl) titleEl.textContent = cfg.help_question;
    if (subEl) subEl.innerHTML = `Say <strong>"${cfg.yes_words[0]}"</strong> or <strong>"${cfg.no_words[0]}"</strong> aloud, or click below:`;
    if (yesLabel) yesLabel.textContent = cfg.yes_btn;
    if (noLabel) noLabel.textContent = cfg.no_btn;

    if (modal) modal.style.display = "flex";

    this.spotlight("#voiceHelpYesBtn", `${cfg.yes_btn} - Click or Say`);

    // Voice asks: "Do you want help? Say yes or no."
    this.speakText(cfg.help_question, () => {
      this.listenForSpeech();
    });
  }

  handleHelpResponse(isYes) {
    if (!isYes) {
      // "No": stop the assistant and leave the website normal
      sessionStorage.setItem("voice_guide_manually_stopped", "true");
      this.stopGuide(true);
    } else {
      // "Yes": continue to Step 3
      this.transitionTo("AUTH_CHOICE");
    }
  }

  // =========================================================================
  // STEP 3: THE REST OF THE JOURNEY (All by Voice, in Chosen Language)
  // =========================================================================

  // Step 3a: Registered or New User?
  renderAuthChoiceStep() {
    this.clearModals();
    const cfg = this.cfg();
    this.spotlight("a[href*='login'], a[href*='register']", cfg.auth_choice_label || "Registered or New User");

    this.speakText(cfg.auth_choice, () => {
      this.listenForSpeech();
    });
  }

  // Step 3b: Registered Citizen Login Guide
  renderLoginGuideStep() {
    if (!window.location.pathname.includes("/login")) {
      window.location.href = "/login";
      return;
    }

    const cfg = this.cfg();
    const emailBox = document.getElementById("loginEmail");
    if (emailBox) {
      this.spotlight(emailBox, cfg.login_email_pos || "Enter Email or Phone number here");
    }

    this.speakText(cfg.login_guide, () => {
      this.listenForSpeech();
    });
  }

  // Step 3c: New Citizen Registration Privacy Statement
  renderRegisterPrivacyStep() {
    this.clearModals();
    const cfg = this.cfg();

    this.speakText(cfg.privacy_consent, () => {
      this.listenForSpeech();
    });
  }

  // Step 3d: Field-by-Field Registration Guidance
  renderRegisterFieldStep() {
    if (!window.location.pathname.includes("/register")) {
      window.location.href = "/register";
      return;
    }

    const field = this.registerFields[this.registerFieldIdx];
    const cfg = this.cfg();

    if (!field) {
      // All registration fields done!
      const finishMsg = cfg.register_done || "All details recorded! Click Create Citizen Account to finish.";
      this.spotlight("button[type='submit']", "Create Citizen Account");
      this.speakText(finishMsg, () => {
        this.listenForSpeech();
      });
      return;
    }

    const targetEl = document.querySelector(field.selector);
    const fConfig = (cfg.fields && cfg.fields[field.key]) || {
      label: field.label,
      pos: field.pos,
      ask: `Please state your ${field.label}. Look at ${field.pos}.`,
      confirm: `You said {val}. Confirmed.`
    };

    if (targetEl) {
      this.spotlight(targetEl, `${fConfig.label} (${fConfig.pos})`);
    }

    let q = fConfig.ask;
    this.speakText(q, () => {
      this.listenForSpeech();
    });
  }

  handleRegisterFieldInput(spokenText) {
    const field = this.registerFields[this.registerFieldIdx];
    const cfg = this.cfg();

    if (!field) {
      const t = spokenText.toLowerCase();
      if (t.includes("submit") || t.includes("சமர்ப்பி") || t.includes("சரி") || t.includes("done") || t.includes("பதிவு") || t.includes("create") || t.includes("yes") || t.includes("ஆம்")) {
        const form = document.querySelector("form[action*='register']");
        if (form) form.submit();
      }
      return;
    }

    const fConfig = (cfg.fields && cfg.fields[field.key]) || {
      label: field.label,
      pos: field.pos,
      ask: `Please state your ${field.label}. Look at ${field.pos}.`,
      confirm: `You said {val}. Confirmed.`
    };

    const el = document.querySelector(field.selector);
    let cleaned = spokenText.trim();
    let displayVal = cleaned;

    if (field.isPassword) {
      const pwInput = document.getElementById("regPassword");
      const cpwInput = document.getElementById("regConfirmPassword");
      const safePw = (cleaned.replace(/\s+/g, '') || "Citizen@123");
      const finalPw = safePw.length >= 6 ? safePw : (safePw + "123456").slice(0, 8);
      if (pwInput) pwInput.value = finalPw;
      if (cpwInput) cpwInput.value = finalPw;

      const conf = cfg.password_confirmed || "Password securely recorded and kept confidential.";
      this.speakText(conf, () => {
        this.registerFieldIdx++;
        this.renderRegisterFieldStep();
      });
      return;
    }

    if (field.key === "name") {
      cleaned = cleaned.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "").trim();
      displayVal = cleaned;
      if (el) el.value = cleaned;
    } else if (field.key === "phone") {
      const digits = parseSpokenDigits(cleaned);
      const cleanPhone = digits.length >= 10 ? digits.slice(-10) : digits;
      cleaned = cleanPhone;
      displayVal = cleanPhone.split("").join(" ");
      if (el) el.value = cleanPhone;

      // Auto-set citizen email if empty
      const emailEl = document.getElementById("regEmail");
      if (emailEl && !emailEl.value) {
        emailEl.value = `citizen_${cleanPhone}@scheme.gov.in`;
      }
    } else if (field.key === "age") {
      const ageVal = parseSpokenAge(cleaned);
      if (ageVal) {
        cleaned = ageVal.toString();
        displayVal = ageVal.toString();
        if (el) el.value = ageVal;
      } else {
        const m = cleaned.match(/\d+/);
        if (m) {
          cleaned = m[0];
          displayVal = m[0];
          if (el) el.value = m[0];
        }
      }
    } else if (el && el.tagName === "SELECT") {
      const matchedVal = matchMultilingualOption(field.key, cleaned, el);
      if (matchedVal) {
        el.value = matchedVal;
        for (let opt of el.options) {
          if (opt.value === matchedVal) {
            displayVal = opt.text;
            break;
          }
        }
      } else {
        displayVal = cleaned;
      }
    } else if (el) {
      el.value = cleaned;
      displayVal = cleaned;
    }

    if (el) {
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }

    // Confirm answer aloud in chosen language
    const confTemplate = fConfig.confirm || `You said {val}. Confirmed.`;
    const conf = confTemplate.replace("{val}", displayVal);
    this.speakText(conf, () => {
      this.registerFieldIdx++;
      this.renderRegisterFieldStep();
    });
  }

  // Step 3e: Problem Inquiry
  renderProblemStep() {
    this.clearModals();
    this.clearSpotlight();
    const cfg = this.cfg();

    this.speakText(cfg.problem_inquiry, () => {
      this.listenForSpeech();
    });
  }

  handleProblemInput(rawText) {
    const searchingText = this.cfg().searching_schemes || "Searching matching schemes for you...";
    this.speakText(searchingText, () => {
      this.matchSchemesForProblem(rawText);
    });
  }

  // Step 3f: Match Schemes & Top 3 Readout
  matchSchemesForProblem(queryText) {
    const t = queryText.toLowerCase();

    const schemesCatalog = [
      { id: 1, title: "PM-Kisan Samman Nidhi", category: "Agriculture", desc: "Provides ₹6,000 yearly direct bank cash transfer to farmer families.", keywords: ["farmer", "farm", "agri", "loan", "kisan", "crop", "விவசாய", "பயிர்", "கடன்", "రైతు", "ರೈತ", "കർഷകൻ", "किसान"] },
      { id: 2, title: "Post-Matric Scholarship", category: "Education", desc: "Full tuition fee waiver and monthly stipend for college students.", keywords: ["student", "school", "college", "scholarship", "fees", "study", "கல்வி", "மாணவர்", "విద్యార్థి", "ವಿದ್ಯಾರ್ಥಿ", "വിദ്യാർത്ഥി", "छात्र"] },
      { id: 3, title: "Kalaignar Magalir Urimai Thogai", category: "Women & Child", desc: "Provides ₹1,000 monthly direct bank financial grant to women heads of households.", keywords: ["woman", "women", "mother", "girl", "பெண்", "மகளிர்", "మహిళ", "ಮಹಿಳೆ", "സ്ത്രീ", "महिला"] },
      { id: 5, title: "Ayushman Bharat PM-JAY", category: "Healthcare", desc: "Provides ₹5 Lakh cashless health insurance per family per year in hospitals.", keywords: ["health", "hospital", "medical", "treatment", "doctor", "மருத்துவம்", "ஆரோக்கியம்", "ആശുപത്രി", "इलाज", "अस्पताल"] },
      { id: 6, title: "Pradhan Mantri Mudra Yojana", category: "Business & MSME", desc: "Collateral-free business loans up to ₹20 Lakh for small enterprise setup.", keywords: ["business", "loan", "shop", "enterprise", "தொழில்", "வியாபாரம்", "వ్యాపారం", "ವ್ಯಾಪಾರ", "വ്യാപാരം", "व्यापार"] },
      { id: 7, title: "PM Surya Ghar Muft Bijli", category: "Housing", desc: "Subsidy up to ₹78,000 for rooftop solar installation with 300 free monthly electricity units.", keywords: ["solar", "electricity", "power", "energy", "சூரிய", "மின்சாரம்", "సౌర", "ಸೌರ", "സോളാർ", "बिजली"] },
      { id: 10, title: "PM Awas Yojana (PMAY)", category: "Housing", desc: "Financial grant up to ₹2.67 Lakh for building or buying a permanent house.", keywords: ["house", "housing", "home", "building", "வீடு", "ఇల్లు", "ಮನೆ", "വീട്", "घर", "मकान"] },
      { id: 16, title: "Old Age Pension Scheme (IGNOAPS)", category: "Senior Citizens", desc: "Monthly direct pension grant for senior citizens above 60 years.", keywords: ["pension", "old age", "senior", "elder", "முதியோர்", "ஓய்வூதியம்", "పెన్షన్", "ಪೆನ್ಷನ್", "പെൻഷൻ", "पेंशन"] }
    ];

    const scored = schemesCatalog.map(s => {
      let score = 0;
      for (let k of s.keywords) {
        if (t.includes(k)) score += 3;
      }
      return { scheme: s, score };
    });

    scored.sort((a, b) => b.score - a.score);
    this.topSchemes = scored.slice(0, 3).map(x => x.scheme);

    this.transitionTo("SCHEMES");
  }

  renderSchemesStep() {
    this.clearModals();

    const modal = document.getElementById("voiceGuideSchemesModal");
    const listEl = document.getElementById("voiceGuideSchemesList");

    if (listEl) {
      listEl.innerHTML = "";
      this.topSchemes.forEach((s, idx) => {
        const item = document.createElement("div");
        item.style.padding = "0.9rem 1.1rem";
        item.style.borderRadius = "var(--radius-sm)";
        item.style.border = "1.5px solid var(--border-color)";
        item.style.background = "#ffffff";
        item.style.cursor = "pointer";
        item.onclick = (e) => {
          e.stopPropagation();
          this.selectSchemeByIndex(idx);
        };

        item.innerHTML = `
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.25rem;">
            <div style="display:flex; align-items:center; gap:0.6rem;">
              <span class="elder-num-badge">${idx + 1}</span>
              <strong style="font-size:1.05rem; color:var(--text-main);">${s.title}</strong>
            </div>
            <span class="badge badge-success">Top Match</span>
          </div>
          <p style="font-size:0.85rem; color:var(--text-muted); margin:0;">${s.desc}</p>
        `;
        listEl.appendChild(item);
      });
    }

    if (modal) modal.style.display = "flex";

    // Read out top 3 best schemes in chosen language with localized number prefix
    const intro = this.cfg().schemes_intro;
    const prefix = this.cfg().scheme_num_prefix || "Number {num}:";
    const speech = `${intro} ` +
      `${prefix.replace("{num}", "1")} ${this.topSchemes[0].title}. ${this.topSchemes[0].desc} ` +
      `${prefix.replace("{num}", "2")} ${this.topSchemes[1].title}. ${this.topSchemes[1].desc} ` +
      `${prefix.replace("{num}", "3")} ${this.topSchemes[2].title}. ${this.topSchemes[2].desc} `;

    this.speakText(speech, () => {
      this.transitionTo("SCHEME_CHOICE");
    });
  }

  // Step 3g: Scheme Selection by Voice
  renderSchemeChoiceStep() {
    const askChoice = this.cfg().choose_scheme;
    this.speakText(askChoice, () => {
      this.listenForSpeech();
    });
  }

  selectSchemeByIndex(index) {
    if (this.topSchemes[index]) {
      this.selectedScheme = this.topSchemes[index];
      this.transitionTo("APPLY");
    }
  }

  handleSchemeChoiceInput(text) {
    const t = text.toLowerCase();
    if (t.includes("first") || t.includes("1") || t.includes("ஒன்று") || t.includes("முதல்") || t.includes("पहला") || t.includes("మొదటి") || t.includes("ಒಂದು") || t.includes("ഒന്ന്") || t.includes("پہلا")) {
      this.selectSchemeByIndex(0);
    } else if (t.includes("second") || t.includes("2") || t.includes("இரண்டு") || t.includes("இரண்டாம்") || t.includes("दूसरा") || t.includes("రెండవ") || t.includes("ಎರಡು") || t.includes("രണ്ട്") || t.includes("دوسرا")) {
      this.selectSchemeByIndex(1);
    } else if (t.includes("third") || t.includes("3") || t.includes("மூன்று") || t.includes("மூன்றாம்") || t.includes("तीसरा") || t.includes("మూడవ") || t.includes("ಮೂರು") || t.includes("മൂന്ന്") || t.includes("تیسرا")) {
      this.selectSchemeByIndex(2);
    } else {
      this.handleSpeechError();
    }
  }

  // Step 3h: Apply Guidance with Form Highlighting & ID Check
  renderApplyStep() {
    this.clearModals();

    const scheme = this.selectedScheme || this.topSchemes[0] || { title: "Welfare Scheme", desc: "Government direct support program" };

    const applyModal = document.getElementById("applyModal");
    const modalTitle = document.getElementById("applyModalSchemeTitle");
    const modalId = document.getElementById("applyModalSchemeId");

    if (modalTitle) modalTitle.textContent = scheme.title;
    if (modalId) modalId.value = scheme.id || 1;
    if (applyModal) applyModal.classList.add("show");

    const introTemplate = this.cfg().apply_intro || "You selected {title}. The required documents to apply are your Aadhaar Card, Income Certificate, and Bank Passbook. Now enter your full legal name in the first box.";
    const introMsg = introTemplate.replace("{title}", scheme.title);

    const nameInput = document.querySelector("#applyModal input[name='applicant_name']");
    if (nameInput) {
      this.spotlight(nameInput, "Enter Full Legal Name in the first box");
    }

    this.speakText(introMsg, () => {
      this.transitionTo("UPLOAD_GUIDE");
    });
  }

  // Step 3i: Voice Help for Uploading
  renderUploadGuideStep() {
    const askMsg = this.cfg().upload_help_ask;
    this.speakText(askMsg, () => {
      this.listenForSpeech();
    });
  }

  handleUploadHelpResponse(knowsHow) {
    if (knowsHow) {
      const guideMsg = this.cfg().upload_guide;
      this.spotlight("input[type='file'], #applyModal button[type='submit']", "Upload your Document or Take Photo");
      this.speakText(guideMsg, () => {
        this.listenForSpeech();
      });
    } else {
      // Offer two choices: (a) Say Aadhaar number aloud, or (b) Go to help center
      const fallbackMsg = this.cfg().upload_fallback;
      this.speakText(fallbackMsg, () => {
        this.listenForSpeech();
      });
    }
  }

  // Manual & Spoken Aadhaar Entry Validation with Read-Back
  promptAadhaarEntry() {
    this.clearSpotlight();
    const prompt = this.cfg().aadhaar_prompt;
    this.speakText(prompt, () => {
      this.listenForSpeech();
    });
  }

  handleAadhaarSpokenInput(spokenText) {
    const clean = spokenText.replace(/\D/g, "");
    if (clean.length !== 12) {
      const errMsg = (this.cfg().aadhaar_err_digits || "").replace("{count}", clean.length);
      this.speakText(errMsg, () => {
        this.promptAadhaarEntry();
      });
      return;
    }

    if (clean[0] === "0" || clean[0] === "1" || !validateVerhoeffJS(clean)) {
      const chkErr = this.cfg().aadhaar_err_verhoeff;
      this.speakText(chkErr, () => {
        this.promptAadhaarEntry();
      });
      return;
    }

    this.pendingAadhaarDigits = clean;
    // Read back in groups of 4 digits: e.g. "2345 6789 0124"
    const grouped = `${clean.slice(0, 4)} ${clean.slice(4, 8)} ${clean.slice(8, 12)}`;
    const confirmPrompt = (this.cfg().aadhaar_confirm || "").replace("{digits}", grouped);

    this.transitionTo("AADHAAR_CONFIRM");
    this.speakText(confirmPrompt, () => {
      this.listenForSpeech();
    });
  }

  handleAadhaarConfirmResponse(isCorrect) {
    if (isCorrect) {
      // Privacy: Mask Aadhaar on screen (show only last 4 digits)
      const masked = `•••• •••• ${this.pendingAadhaarDigits.slice(8, 12)}`;
      const template = this.cfg().aadhaar_verified_masked || "Aadhaar verified and encrypted. Number ending in {last4} saved securely.";
      const successMsg = template.replace("{last4}", this.pendingAadhaarDigits.slice(8, 12));

      const idBox = document.querySelector("#applyModal input[name='aadhaar']") || document.querySelector("input[name='doc_number']");
      if (idBox) {
        idBox.value = masked;
      }

      this.pendingAadhaarDigits = "";
      this.speakText(successMsg, () => {
        this.transitionTo("APPLY");
      });
    } else {
      this.pendingAadhaarDigits = "";
      this.promptAadhaarEntry();
    }
  }

  // =========================================================================
  // STATE MACHINE & TRANSITIONS
  // =========================================================================
  transitionTo(newState, pushHistory = true) {
    if (pushHistory && this.state !== "IDLE" && this.state !== newState) {
      this.history.push(this.state);
    }
    this.state = newState;
    sessionStorage.setItem("voice_guide_state", newState);
    this.consecutiveErrors = 0;

    switch (newState) {
      case "LANG_SELECT":
        this.startLanguageSelectionStep();
        break;
      case "HELP_QUESTION":
        this.renderHelpQuestionStep();
        break;
      case "AUTH_CHOICE":
        this.renderAuthChoiceStep();
        break;
      case "LOGIN_GUIDE":
        this.renderLoginGuideStep();
        break;
      case "REGISTER_PRIVACY":
        this.renderRegisterPrivacyStep();
        break;
      case "REGISTER_FIELDS":
        this.renderRegisterFieldStep();
        break;
      case "PROBLEM":
        this.renderProblemStep();
        break;
      case "SCHEMES":
        this.renderSchemesStep();
        break;
      case "SCHEME_CHOICE":
        this.renderSchemeChoiceStep();
        break;
      case "APPLY":
        this.renderApplyStep();
        break;
      case "UPLOAD_GUIDE":
        this.renderUploadGuideStep();
        break;
      case "AADHAAR_ENTRY":
        this.promptAadhaarEntry();
        break;
      default:
        break;
    }
  }

  goBack() {
    if (this.history.length > 0) {
      const prevState = this.history.pop();
      const backMsg = this.cfg().back_command;
      this.speakText(backMsg, () => {
        this.transitionTo(prevState, false);
      });
    } else {
      this.repeatCurrentStep();
    }
  }

  repeatCurrentStep(slow = false) {
    const oldRate = this.speechRate;
    if (slow) this.speechRate = 0.78;

    this.transitionTo(this.state, false);
    this.speechRate = oldRate;
  }

  handleSpeechError() {
    this.consecutiveErrors++;
    if (this.consecutiveErrors < this.maxErrors) {
      const slowMsg = this.cfg().error_repeat_slow;
      this.speakText(slowMsg, () => {
        this.repeatCurrentStep(true);
      });
    } else {
      const centerInfo = this.getHelpCenterDescription();
      const centerMsg = (this.cfg().help_center_fallback || "").replace("{center_info}", centerInfo);
      this.spotlight("a[href*='help-centers']", "Visit Nearest Help Center");
      this.speakText(centerMsg, () => {
        this.listenForSpeech();
      });
    }
  }

  cfg() {
    return VOICE_CONFIG_7[this.lang] || VOICE_CONFIG_7.en;
  }

  // =========================================================================
  // UNIVERSAL VOICE INPUT DISPATCHER
  // =========================================================================
  handleVoiceInput(rawText) {
    const text = rawText.toLowerCase().trim();
    const cfg = this.cfg();

    // Universal Commands: Repeat, Go Back, Stop
    if (text === "stop" || text.includes("stop") || text.includes("நிறுத்து") || text.includes("ఆపు") || text.includes("ನಿಲ್ಲಿಸು") || text.includes("നിർത്തൂ") || text.includes("रोको") || text.includes("روکو") || text.includes("cancel")) {
      this.stopGuide(true);
      return;
    }

    if (text === "repeat" || text.includes("repeat") || text.includes("மீண்டும்") || text.includes("మళ్ళీ") || text.includes("ಮತ್ತೆ") || text.includes("ആവർത്തിക്കൂ") || text.includes("दोहराओ") || text.includes("دہراؤ")) {
      this.repeatCurrentStep(true);
      return;
    }

    if (text === "go back" || text.includes("go back") || text.includes("back") || text.includes("பின்னே") || text.includes("వెనక్కి") || text.includes("ಹಿಂದೆ") || text.includes("തിരികെ") || text.includes("पीछे") || text.includes("پیچھے")) {
      this.goBack();
      return;
    }

    if (text.includes("help center") || text.includes("e-sevai") || text.includes("csc") || text.includes("உதவி மையம்") || text.includes("కేంద్రం") || text.includes("ಕೇಂದ್ರ") || text.includes("സഹായ കേന്ദ്രം") || text.includes("सहायता केंद्र") || text.includes("مدد مرکز")) {
      window.location.href = "/help-centers";
      return;
    }

    // State Dispatcher
    switch (this.state) {
      case "LANG_SELECT":
        const matched = this.detectLanguageFromText(text);
        if (matched) {
          this.selectLanguage(matched);
        } else {
          this.handleSpeechError();
        }
        break;

      case "HELP_QUESTION":
        if (this.isYesWord(text, cfg)) {
          this.handleHelpResponse(true);
        } else if (this.isNoWord(text, cfg)) {
          this.handleHelpResponse(false);
        } else {
          this.handleSpeechError();
        }
        break;

      case "AUTH_CHOICE":
        if (text.includes("registered") || text.includes("login") || text.includes("already") || text.includes("பதிவு") || text.includes("నమోదైన") || text.includes("ನೋಂದಾಯಿತ") || text.includes("പഴയ") || text.includes("पंजीकृत") || text.includes("رجسٹرڈ")) {
          this.transitionTo("LOGIN_GUIDE");
        } else if (text.includes("new") || text.includes("register") || text.includes("புதிய") || text.includes("కొత్త") || text.includes("ಹೊಸ") || text.includes("പുതിയ") || text.includes("नया") || text.includes("نیا")) {
          this.transitionTo("REGISTER_PRIVACY");
        } else {
          this.handleSpeechError();
        }
        break;

      case "LOGIN_GUIDE":
        if (text.includes("continue") || text.includes("schemes") || text.includes("next") || text.includes("தொடங்கு")) {
          this.transitionTo("PROBLEM");
        } else {
          this.listenForSpeech();
        }
        break;

      case "REGISTER_PRIVACY":
        if (this.isYesWord(text, cfg) || text.includes("start") || text.includes("தொடங்கு") || text.includes("సరే") || text.includes("ಸರಿ") || text.includes("ശരി") || text.includes("हाँ") || text.includes("ٹھیک")) {
          this.transitionTo("REGISTER_FIELDS");
        } else {
          this.handleSpeechError();
        }
        break;

      case "REGISTER_FIELDS":
        this.handleRegisterFieldInput(rawText);
        break;

      case "PROBLEM":
        this.handleProblemInput(rawText);
        break;

      case "SCHEMES":
      case "SCHEME_CHOICE":
        this.handleSchemeChoiceInput(text);
        break;

      case "APPLY":
        this.transitionTo("UPLOAD_GUIDE");
        break;

      case "UPLOAD_GUIDE":
        if (this.isYesWord(text, cfg)) {
          this.handleUploadHelpResponse(true);
        } else if (this.isNoWord(text, cfg)) {
          this.handleUploadHelpResponse(false);
        } else if (text.replace(/\D/g, "").length >= 10) {
          // User spoke an ID number directly!
          this.handleAadhaarSpokenInput(text);
        } else {
          this.handleSpeechError();
        }
        break;

      case "AADHAAR_ENTRY":
        this.handleAadhaarSpokenInput(rawText);
        break;

      case "AADHAAR_CONFIRM":
        if (this.isYesWord(text, cfg)) {
          this.handleAadhaarConfirmResponse(true);
        } else if (this.isNoWord(text, cfg)) {
          this.handleAadhaarConfirmResponse(false);
        } else {
          this.handleSpeechError();
        }
        break;

      default:
        this.listenForSpeech();
        break;
    }
  }

  isYesWord(text, cfg) {
    const list = cfg.yes_words || [];
    return list.some(w => text.includes(w.toLowerCase()));
  }

  isNoWord(text, cfg) {
    const list = cfg.no_words || [];
    return list.some(w => text.includes(w.toLowerCase()));
  }

  detectLanguageFromText(text) {
    const t = text.toLowerCase();
    for (const [lang, aliases] of Object.entries(LANG_ALIASES)) {
      if (aliases.some(a => t.includes(a.toLowerCase()))) {
        return lang;
      }
    }
    return null;
  }

  // =========================================================================
  // SPEECH SYNTHESIS WITH DUAL ENGINE: Local Voice + Backend Cloud TTS
  // =========================================================================
  speakText(text, callback = null) {
    this.speakTextInLang(text, this.lang, callback);
  }

  speakTextInLang(text, langCode, callback = null) {
    const transcriptEl = document.getElementById("elderSpeechTranscript");
    if (transcriptEl) {
      transcriptEl.textContent = text;
    }

    this.stopAudioAndSpeech();
    this.updateSpeakerBadge(true, text);

    const cfg = VOICE_CONFIG_7[langCode] || VOICE_CONFIG_7.en;
    const langCodeFull = cfg.code || "en-IN";
    const prefix = langCodeFull.substring(0, 2).toLowerCase();

    // Check if the browser has a matching local voice
    const voices = this.speechSynth ? this.speechSynth.getVoices() : [];
    const matchedVoice = voices.find(v => {
      const vLang = v.lang.toLowerCase().replace("_", "-");
      return vLang.startsWith(prefix) || vLang === langCodeFull.toLowerCase();
    });

    // If local voice exists and language is English or device voice matches
    if (matchedVoice && (prefix === "en" || matchedVoice.lang.toLowerCase().startsWith(prefix))) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = langCodeFull;
      utterance.voice = matchedVoice;
      utterance.rate = this.speechRate;
      utterance.pitch = 1.0;

      utterance.onend = () => {
        this.updateSpeakerBadge(false);
        if (callback) callback();
      };
      utterance.onerror = () => {
        this.updateSpeakerBadge(false);
        if (callback) callback();
      };

      this.speechSynth.speak(utterance);
    } else {
      // Local voice missing (e.g. te, kn, ml, ur on Windows/Android):
      // STREAM CLOUD TTS FROM BACKEND FLASK API!
      this.playCloudAudio(text, langCode, callback);
    }
  }

  playCloudAudio(text, langCode, callback = null) {
    this.isPlayingAudio = true;
    const url = `/api/tts?lang=${encodeURIComponent(langCode)}&text=${encodeURIComponent(text)}`;
    const audio = new Audio(url);
    this.currentAudio = audio;

    audio.onended = () => {
      this.isPlayingAudio = false;
      this.currentAudio = null;
      this.updateSpeakerBadge(false);
      if (callback) callback();
    };

    audio.onerror = () => {
      this.isPlayingAudio = false;
      this.currentAudio = null;
      this.updateSpeakerBadge(false);

      // On-screen message fallback if both local and cloud audio fail
      const warn = document.getElementById("voiceGuideTtsWarning");
      if (warn) {
        warn.style.display = "block";
        warn.textContent = `Text: "${text}"`;
      }
      if (callback) callback();
    };

    audio.play().catch(e => {
      console.warn("Audio autoplay blocked:", e);
      this.isPlayingAudio = false;
      this.currentAudio = null;
      this.updateSpeakerBadge(false);
      if (callback) callback();
    });
  }

  stopAudioAndSpeech() {
    if (this.currentAudio) {
      try {
        this.currentAudio.pause();
        this.currentAudio.currentTime = 0;
      } catch (e) {}
      this.currentAudio = null;
    }
    this.isPlayingAudio = false;

    if (this.speechSynth) {
      try { this.speechSynth.cancel(); } catch (e) {}
    }
  }

  listenForSpeech(langCode = null) {
    if (!this.recognition) return;
    try { this.recognition.abort(); } catch (e) {}

    const cfg = VOICE_CONFIG_7[langCode || this.lang] || VOICE_CONFIG_7.en;
    this.recognition.lang = cfg.code || "en-IN";

    try {
      this.recognition.start();
      this.isListening = true;
      this.updateSpeakerBadge(false, "Listening...");
    } catch (e) {
      this.isListening = false;
    }
  }

  stopListening() {
    if (this.recognition && this.isListening) {
      try { this.recognition.abort(); } catch (e) {}
      this.isListening = false;
      this.updateSpeakerBadge(false);
    }
  }

  // =========================================================================
  // UI SPOTLIGHT & POSITIONING
  // =========================================================================
  clearSpotlight() {
    if (this.spotlightEl) {
      this.spotlightEl.classList.remove("elder-spotlight-active");
      this.spotlightEl = null;
    }
    if (this.pointerEl && this.pointerEl.parentNode) {
      this.pointerEl.parentNode.removeChild(this.pointerEl);
      this.pointerEl = null;
    }
  }

  spotlight(target, labelText) {
    this.clearSpotlight();

    const el = typeof target === "string" ? document.querySelector(target) : target;
    if (!el) return;

    this.spotlightEl = el;
    el.classList.add("elder-spotlight-active");

    const pointer = document.createElement("div");
    pointer.className = "elder-spotlight-pointer";
    pointer.innerHTML = `👉 ${labelText}`;
    document.body.appendChild(pointer);
    this.pointerEl = pointer;

    const rect = el.getBoundingClientRect();
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;

    pointer.style.top = `${scrollTop + rect.top - 44}px`;
    pointer.style.left = `${scrollLeft + rect.left + rect.width / 2 - 80}px`;

    el.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  showBanner() {
    const banner = document.getElementById("voiceGuideBanner");
    if (banner) banner.style.display = "block";
  }

  hideBanner() {
    const banner = document.getElementById("voiceGuideBanner");
    if (banner) banner.style.display = "none";
  }

  clearModals() {
    const langModal = document.getElementById("voiceGuideLangModal");
    const helpModal = document.getElementById("voiceGuideHelpModal");
    const schemesModal = document.getElementById("voiceGuideSchemesModal");

    if (langModal) langModal.style.display = "none";
    if (helpModal) helpModal.style.display = "none";
    if (schemesModal) schemesModal.style.display = "none";
  }

  stopGuide(userRequested = true) {
    this.active = false;
    this.state = "IDLE";
    this.languageSequenceActive = false;
    sessionStorage.removeItem("voice_guide_state");

    this.stopListening();
    this.stopAudioAndSpeech();
    this.clearModals();
    this.clearSpotlight();
    this.hideBanner();
    this.updateSpeakerBadge(false);

    if (userRequested) {
      const stopMsg = this.cfg().stop_command;
      this.speakText(stopMsg);
    }
  }

  // =========================================================================
  // DOM EVENT BINDINGS
  // =========================================================================
  bindGlobalEvents() {
    document.addEventListener("keydown", (e) => {
      if (!this.active) return;
      if (e.code === "Space" && !["INPUT", "TEXTAREA"].includes(e.target.tagName)) {
        e.preventDefault();
        this.repeatCurrentStep();
      } else if (e.key === "Escape") {
        this.stopGuide(true);
      }
    });
  }

  bindUIButtons() {
    // Top Navbar trigger
    const hBtn = document.getElementById("voiceGuideHeaderBtn") || document.getElementById("elderGuideHeaderBtn");
    if (hBtn) {
      hBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.startLanguageSelectionStep();
      };
    }

    // Sidebar trigger
    const sBtn = document.getElementById("voiceGuideSidebarBtn") || document.getElementById("elderGuideSidebarBtn");
    if (sBtn) {
      sBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.startLanguageSelectionStep();
      };
    }

    // Floating FAB dock button
    const fBtn = document.getElementById("voiceGuideFloatingFab") || document.getElementById("elderGuideFloatingFab");
    if (fBtn) {
      fBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.startLanguageSelectionStep();
      };
    }

    // Floating Speaker Badge
    const sBadge = document.getElementById("voiceSpeakerBadge");
    if (sBadge) {
      sBadge.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.repeatCurrentStep();
      };
    }

    // 7 Big Language Buttons: Clean isolated event binding
    const langBtns = document.querySelectorAll(".voice-lang-btn, .voice-7-btn");
    langBtns.forEach(btn => {
      btn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        const selectedLang = btn.getAttribute("data-lang");
        if (selectedLang) {
          this.selectLanguage(selectedLang);
        }
      };
    });

    const langCancelBtn = document.getElementById("voiceLangCancelBtn");
    if (langCancelBtn) {
      langCancelBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.stopGuide(true);
      };
    }

    // Help Modal Buttons (Step 2)
    const yesBtn = document.getElementById("voiceHelpYesBtn");
    if (yesBtn) {
      yesBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.handleHelpResponse(true);
      };
    }

    const noBtn = document.getElementById("voiceHelpNoBtn");
    if (noBtn) {
      noBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.handleHelpResponse(false);
      };
    }

    const helpBackBtn = document.getElementById("voiceHelpBackBtn");
    if (helpBackBtn) {
      helpBackBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.startLanguageSelectionStep();
      };
    }

    // Schemes Modal Buttons
    const schemesBackBtn = document.getElementById("voiceSchemesBackBtn");
    if (schemesBackBtn) {
      schemesBackBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.goBack();
      };
    }

    const schemesStopBtn = document.getElementById("voiceSchemesStopBtn");
    if (schemesStopBtn) {
      schemesStopBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.stopGuide(true);
      };
    }

    // HUD Banner Controls
    const backBtn = document.getElementById("voiceGuideBackBtn");
    if (backBtn) {
      backBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.goBack();
      };
    }

    const repeatBtn = document.getElementById("voiceGuideRepeatBtn") || document.getElementById("elderRepeatSpeechBtn");
    if (repeatBtn) {
      repeatBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.repeatCurrentStep();
      };
    }

    const stopBtn = document.getElementById("voiceGuideStopBtn") || document.getElementById("elderCloseGuideBtn");
    if (stopBtn) {
      stopBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.stopGuide(true);
      };
    }
  }
}

// Initialize Global Instance
window.citizenVoiceGuide = new CitizenVoiceGuide();
window.elderGuide = window.citizenVoiceGuide; // Compatibility alias

document.addEventListener("DOMContentLoaded", () => {
  window.citizenVoiceGuide.init();
});
