/**
 * Scheme Discovery Assistant - Core Application JavaScript
 * Handles navigation, mobile drawers, bookmarking, dynamic filtering,
 * interactive charts, document vault simulator, predictor gauges, and notifications.
 */

// Toast notification utility
function showToast(message, type = "info") {
  let toastContainer = document.getElementById("toastContainer");
  if (!toastContainer) {
    toastContainer = document.createElement("div");
    toastContainer.id = "toastContainer";
    toastContainer.className = "toast-container";
    document.body.appendChild(toastContainer);
  }

  const toast = document.createElement("div");
  toast.className = `custom-toast toast-${type} animate-slide-in`;
  const icon =
    type === "success"
      ? `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`
      : `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;

  toast.innerHTML = `
    <div class="toast-icon">${icon}</div>
    <div class="toast-body">${message}</div>
    <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
  `;

  toastContainer.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("toast-fade-out");
    setTimeout(() => toast.remove(), 400);
  }, 4000);
}

// Global Save Scheme Handler
async function toggleSaveScheme(schemeId, buttonEl) {
  const isSaved = buttonEl.classList.contains("saved");
  const heartIcon = buttonEl.querySelector("svg");

  // Optimistic UI toggle
  if (isSaved) {
    buttonEl.classList.remove("saved");
    buttonEl.setAttribute("title", "Save Scheme");
    showToast("Scheme removed from saved list", "info");
  } else {
    buttonEl.classList.add("saved");
    buttonEl.setAttribute("title", "Saved in your list");
    showToast("Scheme saved to your watchlist!", "success");
  }

  try {
    const res = await fetch(`/api/schemes/${schemeId}/save`, {
      method: "POST",
      headers: { "Content-Type": "application/json" }
    });
    const data = await res.json();
    if (!data.success) {
      // Revert if error
      buttonEl.classList.toggle("saved");
    }
  } catch (e) {
    console.error("Save scheme error:", e);
  }
}

// Apply for Scheme Modal Trigger
function openApplyModal(schemeId, schemeTitle) {
  const modal = document.getElementById("applyModal");
  if (!modal) return;

  const titleEl = document.getElementById("applyModalSchemeTitle");
  const schemeIdInput = document.getElementById("applyModalSchemeId");

  if (titleEl) titleEl.textContent = schemeTitle;
  if (schemeIdInput) schemeIdInput.value = schemeId;

  modal.classList.add("active");
  document.body.style.overflow = "hidden";
}

function closeApplyModal() {
  const modal = document.getElementById("applyModal");
  if (!modal) return;
  modal.classList.remove("active");
  document.body.style.overflow = "auto";
}

// Universal Search Autocomplete
function initUniversalSearch() {
  const searchInput = document.getElementById("universalSearchInput");
  const dropdown = document.getElementById("universalSearchDropdown");
  if (!searchInput || !dropdown) return;

  let debounceTimer;

  searchInput.addEventListener("input", (e) => {
    clearTimeout(debounceTimer);
    const query = e.target.value.trim();

    if (query.length < 2) {
      dropdown.classList.remove("show");
      dropdown.innerHTML = "";
      return;
    }

    debounceTimer = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        const results = await res.json();

        if (results.length === 0) {
          dropdown.innerHTML = `<div class="search-item empty">No schemes found matching "${query}"</div>`;
        } else {
          dropdown.innerHTML = results
            .slice(0, 5)
            .map(
              (s) => `
              <a href="/schemes/${s.id}" class="search-item">
                <div class="search-item-info">
                  <div class="search-item-title">${s.title}</div>
                  <div class="search-item-category">${s.category} • ${s.state}</div>
                </div>
                <div class="search-item-badge">${s.benefit_type}</div>
              </a>
            `
            )
            .join("");
        }
        dropdown.classList.add("show");
      } catch (err) {
        console.error("Search fetch error:", err);
      }
    }, 250);
  });

  document.addEventListener("click", (e) => {
    if (!searchInput.contains(e.target) && !dropdown.contains(e.target)) {
      dropdown.classList.remove("show");
    }
  });
}

// Help Centers Leaflet Map Initializer
function initHelpCentersMap() {
  const mapElement = document.getElementById("helpCentersMap");
  if (!mapElement || typeof L === "undefined") return;

  // Center on India
  const map = L.map("helpCentersMap").setView([13.0827, 80.2707], 11);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 18,
    attribution: '© OpenStreetMap contributors'
  }).addTo(map);

  // Custom emerald pin
  const customIcon = L.divIcon({
    className: "custom-map-marker",
    html: `<div class="map-marker-pin"><svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg></div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 36],
    popupAnchor: [0, -36]
  });

  // Pull centers from page data
  const centerCards = document.querySelectorAll(".center-card");
  const markers = [];

  centerCards.forEach((card) => {
    const lat = parseFloat(card.getAttribute("data-lat"));
    const lng = parseFloat(card.getAttribute("data-lng"));
    const name = card.getAttribute("data-name");
    const address = card.getAttribute("data-address");
    const phone = card.getAttribute("data-phone");
    const centerType = card.getAttribute("data-type");

    if (!isNaN(lat) && !isNaN(lng)) {
      const marker = L.marker([lat, lng], { icon: customIcon }).addTo(map);
      marker.bindPopup(`
        <div class="map-popup-card">
          <span class="badge badge-success mb-1">${centerType}</span>
          <h4 class="font-bold text-sm mb-1">${name}</h4>
          <p class="text-xs text-muted mb-2">${address}</p>
          <div class="flex items-center gap-2">
            <a href="tel:${phone}" class="btn btn-xs btn-primary-soft">📞 Call Center</a>
            <a href="https://maps.google.com/?q=${lat},${lng}" target="_blank" class="btn btn-xs btn-outline">🗺️ Directions</a>
          </div>
        </div>
      `);
      markers.push(marker);

      // Card hover centers map
      card.addEventListener("click", () => {
        map.setView([lat, lng], 14, { animate: true });
        marker.openPopup();
      });
    }
  });

  if (markers.length > 0) {
    const group = new L.featureGroup(markers);
    map.fitBounds(group.getBounds().pad(0.2));
  }
}

// Document Center Upload Simulator
function initDocumentUpload() {
  const uploadForm = document.getElementById("docUploadForm");
  if (!uploadForm) return;

  uploadForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = uploadForm.querySelector("button[type='submit']");
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner-border spinner-border-sm"></span> Verifying Document...`;

    const formData = new FormData(uploadForm);

    try {
      const res = await fetch("/api/documents/upload", {
        method: "POST",
        body: formData
      });
      const data = await res.json();
      if (data.success) {
        showToast("Document uploaded & verified successfully!", "success");
        setTimeout(() => window.location.reload(), 800);
      } else {
        showToast(data.message || "Upload failed", "error");
        btn.disabled = false;
        btn.innerHTML = originalText;
      }
    } catch (err) {
      console.error(err);
      showToast("Uploaded successfully in demo vault!", "success");
      setTimeout(() => window.location.reload(), 800);
    }
  });
}

// Predictor Scheme Selector
function initPredictorTool() {
  const select = document.getElementById("predictorSchemeSelect");
  if (!select) return;

  select.addEventListener("change", async (e) => {
    const schemeId = e.target.value;
    if (!schemeId) return;

    try {
      const res = await fetch(`/api/predictor/analyze?scheme_id=${schemeId}`);
      const data = await res.json();
      if (data.success) {
        updatePredictorUI(data);
      }
    } catch (err) {
      console.error(err);
    }
  });
}

function updatePredictorUI(data) {
  const scoreVal = document.getElementById("predictorScoreVal");
  const gaugeFill = document.getElementById("predictorGaugeFill");
  const statusBadge = document.getElementById("predictorStatusBadge");
  const recList = document.getElementById("predictorRecList");

  if (scoreVal) scoreVal.textContent = `${data.score}%`;
  if (gaugeFill) gaugeFill.style.strokeDashoffset = 314 - (314 * data.score) / 100;
  if (statusBadge) {
    statusBadge.textContent = data.level;
    statusBadge.className = `badge ${data.score >= 80 ? "badge-success" : data.score >= 60 ? "badge-warning" : "badge-danger"}`;
  }

  if (recList && data.recommendations) {
    recList.innerHTML = data.recommendations
      .map(
        (rec) => `
        <div class="predictor-tip-item ${rec.type}">
          <div class="tip-icon">
            ${rec.type === "good" ? "✅" : rec.type === "warning" ? "⚠️" : "💡"}
          </div>
          <div class="tip-content">
            <div class="tip-title">${rec.title}</div>
            <div class="tip-desc">${rec.description}</div>
          </div>
        </div>
      `
      )
      .join("");
  }
}

// Mobile Sidebar Drawer Toggle
function initNavigationToggles() {
  const menuToggle = document.getElementById("mobileMenuToggle");
  const sidebar = document.getElementById("appSidebar");
  const overlay = document.getElementById("sidebarOverlay");

  if (menuToggle && sidebar) {
    menuToggle.addEventListener("click", () => {
      sidebar.classList.toggle("open");
      if (overlay) overlay.classList.toggle("active");
    });
  }

  if (overlay) {
    overlay.addEventListener("click", () => {
      if (sidebar) sidebar.classList.remove("open");
      overlay.classList.remove("active");
    });
  }

  // Language Dropdown Toggle
  const langBtn = document.getElementById("langDropdownBtn");
  const langMenu = document.getElementById("langDropdownMenu");
  if (langBtn && langMenu) {
    langBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      langMenu.classList.toggle("show");
    });

    document.addEventListener("click", (e) => {
      if (!langBtn.contains(e.target) && !langMenu.contains(e.target)) {
        langMenu.classList.remove("show");
      }
    });
  }

  // User Profile Dropdown Toggle
  const profileBtn = document.getElementById("userProfileBtn");
  const profileMenu = document.getElementById("userProfileMenu");
  if (profileBtn && profileMenu) {
    profileBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      profileMenu.classList.toggle("show");
    });

    document.addEventListener("click", (e) => {
      if (!profileBtn.contains(e.target) && !profileMenu.contains(e.target)) {
        profileMenu.classList.remove("show");
      }
    });
  }

  // Notifications Dropdown
  const notifBtn = document.getElementById("notifDropdownBtn");
  const notifMenu = document.getElementById("notifDropdownMenu");
  if (notifBtn && notifMenu) {
    notifBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      notifMenu.classList.toggle("show");
    });

    document.addEventListener("click", (e) => {
      if (!notifBtn.contains(e.target) && !notifMenu.contains(e.target)) {
        notifMenu.classList.remove("show");
      }
    });
  }
}

// Dom Ready
document.addEventListener("DOMContentLoaded", () => {
  initNavigationToggles();
  initUniversalSearch();
  initHelpCentersMap();
  initDocumentUpload();
  initPredictorTool();

  // Bind any direct Apply buttons
  document.querySelectorAll(".btn-open-apply").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      const id = btn.getAttribute("data-id");
      const title = btn.getAttribute("data-title");
      openApplyModal(id, title);
    });
  });

  // Modal close handlers
  document.querySelectorAll(".modal-close-trigger").forEach((btn) => {
    btn.addEventListener("click", closeApplyModal);
  });
});
