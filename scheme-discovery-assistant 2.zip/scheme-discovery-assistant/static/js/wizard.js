/**
 * Scheme Discovery Assistant - Eligibility Wizard & AI Evaluator
 * Multi-step form with live validation, category selectors,
 * real-time score estimator, and results redirection.
 */

class EligibilityWizard {
  constructor() {
    this.currentStep = 1;
    this.totalSteps = 4;
    this.formData = {
      age: 28,
      gender: "Male",
      state: "Tamil Nadu",
      district: "Chennai",
      social_category: "OBC",
      occupation: "Small Business Owner",
      annual_income: 180000,
      education_level: "Graduate",
      needs: ["business_loan", "health_cover", "clean_energy"]
    };
  }

  init() {
    this.captureCurrentFormValues();
    this.bindEvents();
    this.updateStepUI();
    this.updateIncomeDisplay();
  }

  captureCurrentFormValues() {
    const ageEl = document.getElementById("wizardAge");
    if (ageEl && ageEl.value) this.formData.age = parseInt(ageEl.value) || 28;

    const genderChecked = document.querySelector("input[name='gender']:checked");
    if (genderChecked) this.formData.gender = genderChecked.value;

    const eduEl = document.getElementById("wizardEducation");
    if (eduEl) this.formData.education_level = eduEl.value;

    const stateEl = document.getElementById("wizardState");
    if (stateEl) this.formData.state = stateEl.value;

    const districtEl = document.getElementById("wizardDistrict");
    if (districtEl) this.formData.district = districtEl.value;

    const catEl = document.getElementById("wizardCategory");
    if (catEl) this.formData.social_category = catEl.value;

    const occEl = document.getElementById("wizardOccupation");
    if (occEl) this.formData.occupation = occEl.value;

    const incomeEl = document.getElementById("incomeRangeInput");
    if (incomeEl) this.formData.annual_income = parseInt(incomeEl.value) || 180000;

    const needs = [];
    document.querySelectorAll(".need-checkbox-card input[type='checkbox']:checked").forEach((c) => {
      needs.push(c.value);
    });
    if (needs.length > 0) this.formData.needs = needs;
  }

  bindEvents() {
    // Stepper navigation buttons
    const btnNext = document.getElementById("wizardNextBtn");
    const btnPrev = document.getElementById("wizardPrevBtn");
    const btnSubmit = document.getElementById("wizardSubmitBtn");

    if (btnNext) {
      btnNext.addEventListener("click", () => this.nextStep());
    }
    if (btnPrev) {
      btnPrev.addEventListener("click", () => this.prevStep());
    }
    if (btnSubmit) {
      btnSubmit.addEventListener("click", (e) => {
        e.preventDefault();
        this.submitWizard();
      });
    }

    // Direct step indicators click
    document.querySelectorAll(".step-indicator-item").forEach((item) => {
      item.addEventListener("click", () => {
        const step = parseInt(item.getAttribute("data-step"));
        if (step && step < this.currentStep) {
          this.goToStep(step);
        }
      });
    });

    // Form inputs change tracking
    const incomeSlider = document.getElementById("incomeRangeInput");
    if (incomeSlider) {
      incomeSlider.addEventListener("input", (e) => {
        this.formData.annual_income = parseInt(e.target.value);
        this.updateIncomeDisplay();
        this.recalculateLiveMatchCount();
      });
    }

    // Gender radio selection
    document.querySelectorAll("input[name='gender']").forEach((radio) => {
      radio.addEventListener("change", (e) => {
        this.formData.gender = e.target.value;
        this.recalculateLiveMatchCount();
      });
    });

    // Age input
    const ageInput = document.getElementById("wizardAge");
    if (ageInput) {
      ageInput.addEventListener("input", (e) => {
        this.formData.age = parseInt(e.target.value) || 0;
        this.recalculateLiveMatchCount();
      });
    }

    // Identity Number (Aadhaar / Voter ID) input with Verhoeff validation
    const idInput = document.getElementById("wizardAadhaar");
    const idFeedback = document.getElementById("wizardIdFeedback");
    if (idInput && idFeedback) {
      idInput.addEventListener("input", (e) => {
        const val = e.target.value;
        const digits = val.replace(/\D/g, "");
        const lettersOnly = val.replace(/[^A-Za-z]/g, "");

        idFeedback.style.display = "block";

        if (digits.length >= 10 || (digits.length > 0 && lettersOnly.length === 0)) {
          if (digits.length <= 12) {
            let parts = [];
            for (let i = 0; i < digits.length; i += 4) {
              parts.push(digits.substring(i, i + 4));
            }
            idInput.value = parts.join(" ");
          }

          if (digits.length === 12) {
            if (digits[0] === '0' || digits[0] === '1') {
              idFeedback.textContent = "Aadhaar cannot begin with 0 or 1. First digit must be 2 to 9.";
              idFeedback.style.color = "#dc2626";
            } else if (!this.validateVerhoeff(digits)) {
              idFeedback.textContent = "⚠️ Checksum validation failed. Please check your Aadhaar digits.";
              idFeedback.style.color = "#d97706";
            } else {
              idFeedback.textContent = "✓ Valid Aadhaar Number (Verhoeff Checksum verified).";
              idFeedback.style.color = "#16a34a";
              this.formData.aadhaar_number = `•••• •••• ${digits.slice(8, 12)}`;
              this.formData.id_verified = true;
            }
          } else {
            idFeedback.textContent = `You entered ${digits.length} digits. Exactly 12 digits are required.`;
            idFeedback.style.color = "#dc2626";
          }
        } else if (val.trim().length > 0) {
          const clean = val.replace(/[\s\-]/g, "").toUpperCase();
          idInput.value = clean;
          if (clean.length === 10 && /^[A-Z]{3}[0-9]{7}$/.test(clean)) {
            idFeedback.textContent = "✓ Valid Voter ID EPIC format (3 letters + 7 numbers).";
            idFeedback.style.color = "#16a34a";
            this.formData.voter_id = clean;
            this.formData.id_verified = true;
          } else {
            idFeedback.textContent = `EPIC format: 3 letters + 7 numbers (e.g. ABC1234567). Current length: ${clean.length}/10.`;
            idFeedback.style.color = "#dc2626";
          }
        } else {
          idFeedback.style.display = "none";
        }
      });
    }

    // State select
    const stateSelect = document.getElementById("wizardState");
    if (stateSelect) {
      stateSelect.addEventListener("change", (e) => {
        this.formData.state = e.target.value;
        this.recalculateLiveMatchCount();
      });
    }

    // District input
    const distInput = document.getElementById("wizardDistrict");
    if (distInput) {
      distInput.addEventListener("input", (e) => {
        this.formData.district = e.target.value;
      });
    }

    // Occupation select
    const occSelect = document.getElementById("wizardOccupation");
    if (occSelect) {
      occSelect.addEventListener("change", (e) => {
        this.formData.occupation = e.target.value;
        this.recalculateLiveMatchCount();
      });
    }

    // Social category
    const catSelect = document.getElementById("wizardCategory");
    if (catSelect) {
      catSelect.addEventListener("change", (e) => {
        this.formData.social_category = e.target.value;
        this.recalculateLiveMatchCount();
      });
    }

    // Need checkboxes
    document.querySelectorAll(".need-checkbox-card input[type='checkbox']").forEach((cb) => {
      cb.addEventListener("change", () => {
        const checkedValues = [];
        document.querySelectorAll(".need-checkbox-card input[type='checkbox']:checked").forEach((c) => {
          checkedValues.push(c.value);
        });
        this.formData.needs = checkedValues;
        this.recalculateLiveMatchCount();
      });
    });
  }

  updateIncomeDisplay() {
    const display = document.getElementById("incomeDisplayValue");
    if (display) {
      const val = parseInt(this.formData.annual_income);
      display.textContent = `₹${val.toLocaleString("en-IN")} / year`;
    }
  }

  goToStep(step) {
    if (step >= 1 && step <= this.totalSteps) {
      this.currentStep = step;
      this.updateStepUI();
    }
  }

  nextStep() {
    if (this.validateCurrentStep()) {
      if (this.currentStep < this.totalSteps) {
        this.currentStep++;
        this.updateStepUI();
      }
    }
  }

  prevStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
      this.updateStepUI();
    }
  }

  validateCurrentStep() {
    if (this.currentStep === 1) {
      const age = parseInt(document.getElementById("wizardAge")?.value || 0);
      if (isNaN(age) || age < 5 || age > 115) {
        alert("Please enter a valid age between 5 and 115.");
        return false;
      }
      this.formData.age = age;
    }
    return true;
  }

  updateStepUI() {
    for (let i = 1; i <= this.totalSteps; i++) {
      const section = document.getElementById(`wizardStepSection_${i}`);
      const stepItem = document.querySelector(`.step-indicator-item[data-step="${i}"]`);
      if (section) {
        if (i === this.currentStep) {
          section.style.display = "block";
          section.classList.add("animate-fade-in");
        } else {
          section.style.display = "none";
        }
      }
      if (stepItem) {
        if (i < this.currentStep) {
          stepItem.classList.add("completed");
          stepItem.classList.remove("active");
        } else if (i === this.currentStep) {
          stepItem.classList.add("active");
          stepItem.classList.remove("completed");
        } else {
          stepItem.classList.remove("active", "completed");
        }
      }
    }

    const progressBar = document.getElementById("wizardProgressFill");
    if (progressBar) {
      const pct = Math.round(((this.currentStep - 1) / (this.totalSteps - 1)) * 100);
      progressBar.style.width = `${pct}%`;
    }

    const btnPrev = document.getElementById("wizardPrevBtn");
    const btnNext = document.getElementById("wizardNextBtn");
    const btnSubmit = document.getElementById("wizardSubmitBtn");

    if (btnPrev) {
      btnPrev.style.visibility = this.currentStep === 1 ? "hidden" : "visible";
    }
    if (btnNext) {
      btnNext.style.display = this.currentStep === this.totalSteps ? "none" : "inline-flex";
    }
    if (btnSubmit) {
      btnSubmit.style.display = this.currentStep === this.totalSteps ? "inline-flex" : "none";
    }

    window.scrollTo({ top: 120, behavior: "smooth" });
  }

  recalculateLiveMatchCount() {
    const countBadge = document.getElementById("liveSchemeCounter");
    if (!countBadge) return;

    let base = 12;
    if (this.formData.annual_income <= 300000) base += 4;
    if (this.formData.occupation.includes("Farmer") || this.formData.occupation.includes("Business")) base += 2;
    if (this.formData.gender === "Female") base += 3;
    if (this.formData.social_category !== "General") base += 2;

    countBadge.textContent = `${base} Schemes`;
  }

  validateVerhoeff(numStr) {
    const d = [[0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],[3,4,0,1,2,8,9,5,6,7],[4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],[6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],[8,7,6,5,9,3,2,1,0,4],[9,8,7,6,5,4,3,2,1,0]];
    const p = [[0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],[8,9,1,6,0,4,3,5,2,7],[9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],[2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8]];
    if (!/^\d+$/.test(numStr)) return false;
    let c = 0;
    const rev = numStr.split("").reverse().map(Number);
    for (let i = 0; i < rev.length; i++) {
      c = d[c][p[i % 8][rev[i]]];
    }
    return c === 0;
  }

  async submitWizard() {
    this.captureCurrentFormValues();

    const btnSubmit = document.getElementById("wizardSubmitBtn");
    if (btnSubmit) {
      btnSubmit.disabled = true;
      btnSubmit.innerHTML = `
        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
        Evaluating with AI Engine...
      `;
    }

    try {
      const response = await fetch("/api/evaluate-eligibility", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(this.formData)
      });

      const result = await response.json();
      if (result.success) {
        sessionStorage.setItem("latest_eligibility_eval", JSON.stringify(result));
        window.location.href = "/eligibility-summary";
      } else {
        window.location.href = "/eligibility-summary";
      }
    } catch (err) {
      console.error("Evaluation error:", err);
      window.location.href = "/eligibility-summary";
    }
  }
}

document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("eligibilityWizardForm")) {
    window.eligibilityWizard = new EligibilityWizard();
    window.eligibilityWizard.init();
  }
});
