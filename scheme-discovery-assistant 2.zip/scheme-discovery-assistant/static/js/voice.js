/**
 * Scheme Discovery Assistant - Multilingual Voice Assistant Engine
 * Features:
 * - Speech-to-Text (STT) supporting ta-IN, hi-IN, te-IN, en-IN, etc.
 * - Text-to-Speech (TTS) with Indian voice synthesizers and regional accents
 * - Native Tamil & Regional Language Responses
 * - Live Canvas Waveform Oscilloscope Animation
 * - Intelligent Tamil & Multilingual Intent Parser
 */

// Localized response dictionaries for all intents
const VOICE_RESPONSES = {
  education: {
    en: "Showing top education and student scholarships, including Post-Matric Scholarship and Pudhumai Penn scheme.",
    ta: "மாணவர்களுக்கான சிறந்த கல்வி உதவித்தொகை திட்டங்களை காட்டுகிறேன். இதில் புதுமைப் பெண் திட்டம் மற்றும் போஸ்ட்-மெட்ரிக் கல்வி உதவித்தொகை ஆகியவை அடங்கும்.",
    hi: "छात्रों के लिए शीर्ष शिक्षा और छात्रवृत्ति योजनाएं दिखाई जा रही हैं, जिनमें पोस्ट-मैट्रिक छात्रवृत्ति शामिल है।",
    te: "విద్యార్థుల కోసం ఉత్తమ విద్య మరియు స్కాలర్‌షిప్ పథకాలను చూపిస్తున్నాను.",
    kn: "ವಿದ್ಯಾರ್ಥಿಗಳಿಗೆ ಉತ್ತಮ ಶಿಕ್ಷಣ ಮತ್ತು ವಿದ್ಯಾರ್ಥಿವೇತನ ಯೋಜನೆಗಳನ್ನು ತೋರಿಸಲಾಗುತ್ತಿದೆ.",
    ml: "വിദ്യാർത്ഥികൾക്കായുള്ള മികച്ച വിദ്യാഭ്യാസ പദ്ധതികളും സ്കോളർഷിപ്പുകളും കാണിക്കുന്നു.",
    bn: "শিক্ষার্থীদের জন্য শীর্ষ শিক্ষা এবং বৃত্তি প্রকল্পগুলি প্রদর্শিত হচ্ছে।",
    mr: "विद्यार्थ्यांसाठी सर्वोत्तम शिक्षण आणि शिष्यवृत्ती योजना दाखवत आहे.",
    gu: "વિદ્યાર્થીઓ માટે શ્રેષ્ઠ શિક્ષણ અને શિષ્યવૃત્તિ યોજનાઓ દર્શાવી રહ્યા છીએ.",
    pa: "ਵਿਦਿਆਰਥੀਆਂ ਲਈ ਸਿੱਖਿਆ ਅਤੇ ਵਜ਼ੀਫ਼ਾ ਸਕੀਮਾਂ ਦਿਖਾਈਆਂ ਜਾ ਰਹੀਆਂ ਹਨ।",
    or: "ଛାତ୍ରଛାତ୍ରୀଙ୍କ ପାଇଁ ଶିକ୍ଷା ଏବଂ ବୃତ୍ତି ଯୋଜନା ଦେଖାଉଛି।",
    as: "শিক্ষাৰ্থীৰ বাবে শিক্ষা আৰু জলপানী আঁচনি দেখুওৱা হৈছে।",
    ur: "طلباء کے لیے اعلیٰ تعلیمی اور اسکالرشپ اسکیمیں دکھائی جا رہی ہیں۔",
    url: "/schemes?category=Education"
  },
  agriculture: {
    en: "Showing agriculture schemes for farmers including PM-Kisan Samman Nidhi (₹6,000/yr) and crop insurance.",
    ta: "விவசாயிகளுக்கான நலத்திட்டங்களை காட்டுகிறேன். இதில் பி.எம். கிசான் திட்டத்தின் கீழ் ஆண்டுக்கு ₹6,000 நேரடி உதவி மற்றும் பயிர் காப்பீட்டு திட்டங்கள் உள்ளன.",
    hi: "किसानों के लिए कृषि योजनाएं दिखाई जा रही हैं, जिनमें पीएम-किसान सम्मान निधि (₹6,000/वर्ष) शामिल है।",
    te: "రైతుల కోసం పీఎం-కిసాన్ సమ్మాన్ నిధితో సహా వ్యవసాయ పథకాలను చూపిస్తున్నాను.",
    kn: "ರೈತರಿಗಾಗಿ ಪಿಎಂ-ಕಿಸಾನ್ ಸಮ್ಮಾನ್ ನಿಧಿ ಒಳಗೊಂಡಂತೆ ಕೃಷಿ ಯೋಜನೆಗಳನ್ನು ತೋರಿಸಲಾಗುತ್ತಿದೆ.",
    ml: "കർഷകർക്കായി പിഎം-കിസാൻ ഉൾപ്പെടെയുള്ള കാർഷിക പദ്ധതികൾ കാണിക്കുന്നു.",
    bn: "কৃষকদের জন্য পিএম-কিসান সম্মান নিধি সহ কৃষি প্রকল্পগুলি প্রদর্শিত হচ্ছে।",
    mr: "शेतकऱ्यांसाठी पीएम-किसान सन्मान निधीसह कृषी योजना दाखवत आहे.",
    gu: "ખેડૂતો માટે પીએમ-કિસાન સહિતની કૃષિ યોજનાઓ બતાવી રહ્યા છીએ.",
    pa: "ਕਿਸਾਨਾਂ ਲਈ ਪੀਐਮ-ਕਿਸਾਨ ਸਮੇਤ ਖੇਤੀਬਾੜੀ ਸਕੀਮਾਂ ਦਿਖਾਈਆਂ ਜਾ ਰਹੀਆਂ ਹਨ।",
    or: "କୃଷକମାନଙ୍କ ପାଇଁ ପ୍ରଧାନମନ୍ତ୍ରୀ କିସାନ ସମ୍ମାନ ନିଧି ଯୋଜନା ଦେଖାଉଛି।",
    as: "কৃষকৰ বাবে পিএম-কিষাণ আঁচনি দেখুওৱা হৈছে।",
    ur: "کسانوں کے لیے پی ایم کسان سمیت زرعی اسکیمیں دکھائی جا رہی ہیں۔",
    url: "/schemes?category=Agriculture"
  },
  healthcare: {
    en: "Found health protection schemes including Ayushman Bharat PM-JAY and CMCHIS with up to ₹5 Lakh cashless coverage.",
    ta: "மருத்துவக் காப்பீட்டு திட்டங்களை காட்டுகிறேன். இதில் முதலமைச்சரின் விரிவான மருத்துவக் காப்பீட்டுத் திட்டம் (CMCHIS) மற்றும் ஆயுஷ்மான் பாரத் மூலம் ₹5 லட்சம் வரை கட்டணமில்லா சிகிச்சை பெறலாம்.",
    hi: "आयुष्मान भारत पीएम-जेएवाई सहित स्वास्थ्य बीमा योजनाएं मिली हैं, जिसमें ₹5 लाख तक का कैशलेस इलाज मिलता है।",
    te: "ఆయుష్మాన్ భారత్‌తో సహా ₹5 లక్షల వరకు ఉచిత వైద్య చికిత్స అందించే ఆరోగ్య పథకాలను చూపిస్తున్నాను.",
    kn: "ಆಯುಷ್ಮಾನ್ ಭಾರತ್ ಒಳಗೊಂಡಂತೆ ₹5 ಲಕ್ಷದವರೆಗೆ ಉಚಿತ ಆರೋಗ್ಯ ರಕ್ಷಣಾ ಯೋಜನೆಗಳನ್ನು ತೋರಿಸಲಾಗುತ್ತಿದೆ.",
    ml: "ആയുഷ്മാൻ ഭാരത് ഉൾപ്പെടെ ₹5 ലക്ഷം രൂപ വരെയുള്ള ആരോഗ്യ ഇൻഷുറൻസ് പദ്ധതികൾ ലഭ്യമാണ്.",
    bn: "আয়ুষ্মান ভারত সহ ₹৫ লাখ পর্যন্ত বিনামূল্যে স্বাস্থ্য বীমা প্রকল্পগুলি প্রদর্শিত হচ্ছে।",
    mr: "आयुष्मान भारतसह ₹५ लाखांपर्यंत मोफत आरोग्य संरक्षण योजना दाखवत आहे.",
    gu: "આયુષ્માન ભારત સહિત ₹૫ લાખ સુધીની મફત સારવાર આપતી આરોગ્ય યોજનાઓ બતાવી રહ્યા છીએ.",
    pa: "ਆਯੁਸ਼ਮਾਨ ਭਾਰਤ ਸਮੇਤ ₹5 ਲੱਖ ਤੱਕ ਦਾ ਮੁਫਤ ਸਿਹਤ ਬੀਮਾ ਸਕੀਮਾਂ ਮਿਲੀਆਂ ਹਨ।",
    or: "ଆୟୁଷ୍ମାନ ଭାରତ ସମେତ ₹୫ ଲକ୍ଷ ପର୍ଯ୍ୟନ୍ତ ମାଗଣା ସ୍ୱାସ୍ଥ୍ୟ ବୀମା ଯୋଜନା ମିଳିଛି।",
    as: "আয়ুষ্মান ভাৰতকে ধৰি ৫ লাখ টকালৈকে বিনামূলীয়া চিকিৎসা আঁচনি উপলব্ধ।",
    ur: "آیوشمان بھارت سمیت 5 لاکھ روپے تک مفت علاج فراہم کرنے والی اسکیمیں دستیاب ہیں۔",
    url: "/schemes?category=Healthcare"
  },
  women: {
    en: "Showing dedicated schemes for women and girl children including Kalaignar Magalir Urimai Thogai and Sukanya Samriddhi.",
    ta: "மகளிர் மற்றும் பெண் குழந்தைகளுக்கான சிறப்பு திட்டங்களை காட்டுகிறேன். இதில் கலைஞர் மகளிர் உரிமைத் தொகை (மாதம் ₹1,000) மற்றும் சுகன்யா சம்ரிதி திட்டங்கள் அடங்கும்.",
    hi: "महिलाओं और बालिकाओं के लिए समर्पित योजनाएं दिखाई जा रही हैं, जिनमें लाडली बहना और सुकन्या समृद्धि शामिल हैं।",
    te: "మహిళలు మరియు ఆడపిల్లల కోసం ప్రత్యేక సంక్షేమ పథకాలను చూపిస్తున్నాను.",
    kn: "ಮಹಿಳೆಯರು ಮತ್ತು ಹೆಣ್ಣು ಮಕ್ಕಳಿಗಾಗಿ ಮೀಸಲಾದ ಯೋಜನೆಗಳನ್ನು ತೋರಿಸಲಾಗುತ್ತಿದೆ.",
    ml: "സ്ത്രീകൾക്കും പെൺകുട്ടികൾക്കുമായുള്ള പ്രത്യേക പദ്ധതികൾ കാണിക്കുന്നു.",
    bn: "মহিলা ও কন্যা শিশুদের জন্য বিশেষ প্রকল্পগুলি প্রদর্শিত হচ্ছে।",
    mr: "महिला आणि मुलींसाठी विशेष सरकारी योजना दाखवत आहे.",
    gu: "મહિલાઓ અને દીકરીઓ માટેની વિશેષ સરકારી યોજનાઓ બતાવી રહ્યા છીએ.",
    pa: "ਔਰਤਾਂ ਅਤੇ ਬੱਚੀਆਂ ਲਈ ਵਿਸ਼ੇਸ਼ ਭਲਾਈ ਸਕੀਮਾਂ ਦਿਖਾਈਆਂ ਜਾ ਰਹੀਆਂ ਹਨ।",
    or: "ମହିଳା ଏବଂ କନ୍ୟା ସନ୍ତାନମାନଙ୍କ ପାଇଁ ସ୍ୱତନ୍ତ୍ର ଯୋଜନା ଦେଖାଉଛି।",
    as: "মহিলা আৰু কন্যা সন্তানৰ বাবে বিশেষ আঁচনি দেখুওৱা হৈছে।",
    ur: "خواتین اور بچیوں کے لیے مخصوص فلاحی اسکیمیں دکھائی جا رہی ہیں۔",
    url: "/schemes?category=Women%20%26%20Child"
  },
  business: {
    en: "Showing business credit & micro enterprise schemes including PM Mudra Yojana up to ₹20 Lakh collateral-free loan.",
    ta: "தொழில் தொடங்குவதற்கான கடன் திட்டங்களை காட்டுகிறேன். இதில் பி.எம். முத்ரா திட்டம் மூலம் ₹20 லட்சம் வரை பிணையில்லா கடன் பெறலாம்.",
    hi: "पीएम मुद्रा योजना सहित व्यापार ऋण योजनाएं दिखाई जा रही हैं, जिसमें ₹20 लाख तक का बिना गारंटी ऋण मिलता है।",
    te: "పీఎం ముద్ర యోజనతో సహా వ్యాపార రుణ పథకాలను చూపిస్తున్నాను.",
    kn: "ಪಿಎಂ ಮುದ್ರಾ ಯೋಜನೆ ಒಳಗೊಂಡಂತೆ ವ್ಯಾಪಾರ ಸಾಲ ಯೋಜನೆಗಳನ್ನು ತೋರಿಸಲಾಗುತ್ತಿದೆ.",
    ml: "പിഎം മുദ്ര ഉൾപ്പെടെയുള്ള ചെറുകിട ബിസിനസ് വായ്പാ പദ്ധതികൾ കാണിക്കുന്നു.",
    bn: "পিএম মুদ্রা সহ ব্যবসা ঋণ এবং ক্ষুদ্র শিল্প প্রকল্পগুলি প্রদর্শিত হচ্ছে।",
    mr: "पीएम मुद्रा योजनेसह व्यवसाय कर्ज योजना दाखवत आहे.",
    gu: "પીએમ મુદ્રા યોજના સહિતની બિઝનેસ લોન યોજનાઓ બતાવી રહ્યા છીએ.",
    pa: "ਪੀਐਮ ਮੁਦਰਾ ਸਮੇਤ ਕਾਰੋਬਾਰੀ ਕਰਜ਼ਾ ਸਕੀਮਾਂ ਦਿਖਾਈਆਂ ਜਾ ਰਹੀਆਂ ਹਨ।",
    or: "ପ୍ରଧାନମନ୍ତ୍ରୀ ମୁଦ୍ରା ଯୋଜନା ସମେତ ବ୍ୟବସାୟ ଋଣ ଯୋଜନା ଦେଖାଉଛି।",
    as: "পিএম মুদ্ৰাকে ধৰি ব্যৱসায়িক ঋণ আঁচনি দেখুওৱা হৈছে।",
    ur: "پی ایم مدرا سمیت کاروباری قرضوں کی اسکیمیں دکھائی جا رہی ہیں۔",
    url: "/schemes?category=Business%20%26%20MSME"
  },
  general_entitlement: {
    en: "Based on Indian citizen welfare rules, you can receive direct income support, health insurance, and subsidies. Showing your top matching schemes.",
    ta: "வணக்கம்! உங்கள் தகுதிக்கு ஏற்ப கலைஞர் மகளிர் உரிமைத் தொகை, புதுமைப் பெண் திட்டம், ஆயுஷ்மான் பாரத் மற்றும் பி.எம். கிசான் போன்ற தகுதியான திட்டங்கள் உள்ளன. முழு பட்டியலை கீழே காணலாம்.",
    hi: "आपकी नागरिक पहचान और पात्रता के अनुसार पीएम किसान, आयुष्मान भारत और आवास योजना जैसी योजनाएं उपलब्ध हैं।",
    te: "మీ అర్హతకు తగినట్లుగా పీఎం కిసాన్, ఆయుష్మాన్ భారత్ వంటి అనేక ప్రభుత్వ పథకాలు అందుబాటులో ఉన్నాయి.",
    kn: "ನಿಮ್ಮ ಅರ್ಹತೆಗೆ ತಕ್ಕಂತೆ ವಿವಿಧ ಸರಕಾರಿ ಕಲ್ಯಾಣ ಯೋಜನೆಗಳನ್ನು ಇಲ್ಲಿ ಪಟ್ಟಿ ಮಾಡಲಾಗಿದೆ.",
    ml: "നിങ്ങൾക്ക് അർഹതപ്പെട്ട സർക്കാർ ക്ഷേമ പദ്ധതികൾ ചുവടെ കാണാം.",
    bn: "আপনার যোগ্যতানুযায়ী সরকারি কল্যাণ প্রকল্পগুলির তালিকা নিচে দেওয়া হলো।",
    mr: "तुमच्या पात्रतेनुसार सर्व उपलब्ध सरकारी योजनांची यादी खाली दिली आहे.",
    gu: "તમારી પાત્રતા અનુસાર તમામ ઉપલબ્ધ સરકારી યોજનાઓની યાદી નીચે આપેલ છે.",
    pa: "ਤੁਹਾਡੀ ਯੋਗਤਾ ਅਨੁਸਾਰ ਸਰਕਾਰੀ ਸਕੀਮਾਂ ਦੀ ਸੂਚੀ ਹੇਠਾਂ ਦਿੱਤੀ ਗਈ ਹੈ।",
    or: "ଆପଣଙ୍କ ଯୋଗ୍ୟତା ଅନୁଯାୟୀ ସରକାରୀ ଯୋଜନାଗୁଡ଼ିକ ତଳେ ଦର୍ଶାଯାଇଛି।",
    as: "আপোনাৰ যোগ্যতা অনুসৰি চৰকাৰী আঁচনিসমূহ তলত দিয়া হৈছে।",
    ur: "آپ کی اہلیت کے مطابق دستیاب تمام سرکاری فلاحی اسکیمیں نیچے درج ہیں۔",
    url: "/schemes"
  },
  check_eligibility: {
    en: "Opening the interactive AI Eligibility Wizard. Answer 4 quick questions to see all schemes you qualify for.",
    ta: "உங்கள் தகுதியை கணக்கிட வழிகாட்டி படிவத்தை திறக்கிறேன். இதில் 4 எளிய கேள்விகளுக்கு பதிலளித்து உங்களுக்கான திட்டங்களை கண்டறியலாம்.",
    hi: "पात्रता विज़ार्ड खोला जा रहा है। 4 आसान सवालों के जवाब देकर अपनी योग्य योजनाएं जानें।",
    te: "అర్హత విజార్డ్ తెరవబడుతోంది. 4 ప్రశ్నలకు సమాధానమిచ్చి మీ పథకాలను తెలుసుకోండి.",
    kn: "ಅರ್ಹತೆ ಪರಿಶೀಲನಾ ಪುಟವನ್ನು ತೆರೆಯಲಾಗುತ್ತಿದೆ.",
    ml: "നിങ്ങളുടെ യോഗ്യത പരിശോധിക്കാനുള്ള വിസാർഡ് തുറക്കുന്നു.",
    bn: "যোগ্যতা উইজার্ড খোলা হচ্ছে।",
    mr: "पात्रता तपासणी विझार्ड उघडत आहे.",
    gu: "પાત્રતા વિઝાર્ડ ખોલી રહ્યા છીએ.",
    pa: "ਯੋਗਤਾ ਜਾਂਚ ਵਿਜ਼ਾਰਡ ਖੋਲ੍ਹਿਆ ਜਾ ਰਿਹਾ ਹੈ।",
    or: "ଯୋଗ୍ୟତା ୱିଜାର୍ଡ ଖୋଲାଯାଉଛି।",
    as: "যোগ্যতা উইজাৰ্ড খোলা হৈছে।",
    ur: "اہلیت کا وزرڈ کھولا جا رہا ہے۔",
    url: "/wizard"
  },
  documents: {
    en: "Taking you to Document Vault to verify your Aadhaar, Income Certificate, and check your readiness score.",
    ta: "உங்கள் ஆவண பெட்டகத்திற்கு அழைத்துச் செல்கிறேன். அங்கு உங்கள் ஆதார், வருமானச் சான்றிதழ் மற்றும் குடும்ப அட்டை ஆவணங்களை சரிபார்க்கலாம்.",
    hi: "दस्तावेज़ वॉल्ट खोला जा रहा है जहां आप अपने आधार और आय प्रमाण पत्र की जांच कर सकते हैं।",
    te: "మీ ఆధార్ మరియు ఇతర పత్రాలను ధృవీకరించడానికి డాక్యుమెంట్ వాల్ట్‌కు తీసుకెళ్తున్నాను.",
    kn: "ದಾಖಲೆ ವಾಲ್ಟ್‌ಗೆ ಕರೆದೊಯ್ಯಲಾಗುತ್ತಿದೆ.",
    ml: "ഡോക്യുമെന്റ് വോൾട്ടിലേക്ക് കൊണ്ടുപോകുന്നു.",
    bn: "ডকুমেন্ট ভল্টে নিয়ে যাওয়া হচ্ছে।",
    mr: "कागदपत्रे व्हॉल्ट उघडत आहे.",
    gu: "દસ્તાવેજ વૉલ્ટ ખોલી રહ્યા છીએ.",
    pa: "ਦਸਤਾਵੇਜ਼ ਵਾਲਟ ਖੋਲ੍ਹਿਆ ਜਾ ਰਿਹਾ ਹੈ।",
    or: "ଦଲିଲ ଭଲ୍ଟ ଖୋଲାଯାଉଛି।",
    as: "নথিপত্ৰ ভল্ট খোলা হৈছে।",
    ur: "دستاویز والٹ کھولا جا رہا ہے۔",
    url: "/documents"
  },
  help_centers: {
    en: "Locating verified Common Service Centers (CSC) and e-Sevai Kendra near your district.",
    ta: "உங்கள் மாவட்டத்திற்கு அருகிலுள்ள சரிபார்க்கப்பட்ட அரசு இ-சேவை மையங்கள் மற்றும் சி.எஸ்.சி (CSC) சேவை மையங்களின் முகவரிகளை காட்டுகிறேன்.",
    hi: "आपके जिले के नजदीकी जन सेवा केंद्र (CSC) और सहायता केंद्र खोजे जा रहे हैं।",
    te: "మీ జిల్లాలోని కామన్ సర్వీస్ సెంటర్లు మరియు సహాయ కేంద్రాలను చూపిస్తున్నాను.",
    kn: "ನಿಮ್ಮ ಜಿಲ್ಲೆಯ ಹತ್ತಿರದ ಸೇವಾ ಕೇಂದ್ರಗಳನ್ನು ತೋರಿಸಲಾಗುತ್ತಿದೆ.",
    ml: "അടുത്തുള്ള സേവന കേന്ദ്രങ്ങൾ കണ്ടെത്തുന്നു.",
    bn: "নিকটবর্তী কমন সার্ভিস সেন্টার (CSC) সন্ধান করা হচ্ছে।",
    mr: "जवळपासचे मदत केंद्र आणि महा ई-सेवा केंद्र शोधत आहे.",
    gu: "નજીકના જન સેવા કેન્દ્રો શોધી રહ્યા છીએ.",
    pa: "ਨਜ਼ਦੀਕੀ ਸੇਵਾ ਕੇਂਦਰ ਲੱਭੇ ਜਾ ਰਹੇ ਹਨ।",
    or: "ନିକଟସ୍ଥ ଜନ ସେବା କେନ୍ଦ୍ର ଖୋଜୁଛି।",
    as: "ওচৰৰ সেৱা কেন্দ্ৰসমূহ বিচৰা হৈছে।",
    ur: "آپ کے قریبی امدادی مراکز تلاش کیے جا رہے ہیں۔",
    url: "/help-centers"
  }
};

class VoiceAssistantEngine {
  constructor() {
    this.recognition = null;
    this.isListening = false;
    this.isSpeaking = false;
    this.currentLang = localStorage.getItem("scheme_lang_pref") || "ta"; // default to Tamil if preferred
    this.currentLangCode = this.getLangSpeechCode(this.currentLang);
    this.speechSynth = window.speechSynthesis || null;
    this.waveCanvas = null;
    this.canvasCtx = null;
    this.animFrameId = null;
    this.wavePhase = 0;

    this.initSpeechRecognition();
  }

  getLangSpeechCode(lang) {
    const map = {
      ta: "ta-IN",
      hi: "hi-IN",
      en: "en-IN",
      te: "te-IN",
      kn: "kn-IN",
      ml: "ml-IN",
      bn: "bn-IN",
      mr: "mr-IN",
      gu: "gu-IN",
      pa: "pa-IN",
      or: "or-IN",
      as: "as-IN",
      ur: "ur-IN"
    };
    return map[lang] || "en-IN";
  }

  setVoiceLanguage(lang) {
    this.currentLang = lang;
    this.currentLangCode = this.getLangSpeechCode(lang);

    if (this.recognition) {
      this.recognition.lang = this.currentLangCode;
    }

    if (window.i18n) {
      window.i18n.setLanguage(lang);
    }

    // Update active state in UI
    document.querySelectorAll(".voice-lang-btn").forEach((btn) => {
      if (btn.getAttribute("data-lang") === lang) {
        btn.classList.add("active");
      } else {
        btn.classList.remove("active");
      }
    });

    // Provide friendly greeting in selected language
    let greeting = "";
    if (lang === "ta") {
      greeting = "வணக்கம்! திட்டங்கள் கண்டறிதல் உதவியாளர் உங்களுடன் தமிழில் பேச தயாராக உள்ளது. கீழே உள்ள மைக்ரோஃபோனை அழுத்தி பேசவும்.";
    } else if (lang === "hi") {
      greeting = "नमस्ते! योजना खोज सहायक हिंदी में बात करने के लिए तैयार है। बोलने के लिए नीचे दिए गए माइक पर टैप करें।";
    } else {
      greeting = "Hello! Voice assistant is ready. Tap the microphone below and speak your query.";
    }

    this.addChatMessage("assistant", greeting);
    this.speakText(greeting);
  }

  initSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = false;
      this.recognition.interimResults = true;
      this.recognition.lang = this.currentLangCode;

      this.recognition.onstart = () => {
        this.isListening = true;
        this.updateUIState("listening");
        this.startWaveformAnimation();
      };

      this.recognition.onresult = (event) => {
        let transcript = "";
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
        }

        const transcriptEl = document.getElementById("voiceTranscript");
        if (transcriptEl) {
          transcriptEl.textContent = `"${transcript}"`;
        }

        if (event.results[0].isFinal) {
          this.handleVoiceCommand(transcript);
        }
      };

      this.recognition.onerror = (event) => {
        console.warn("Speech Recognition Error:", event.error);
        this.isListening = false;
        this.updateUIState("error", event.error);
        this.stopWaveformAnimation();
      };

      this.recognition.onend = () => {
        this.isListening = false;
        this.updateUIState("idle");
        this.stopWaveformAnimation();
      };
    } else {
      console.warn("Web Speech API not supported in this browser.");
    }

    // Sync language from i18n
    window.addEventListener("schemeLanguageChanged", (e) => {
      if (e.detail && e.detail.lang) {
        this.currentLang = e.detail.lang;
        this.currentLangCode = this.getLangSpeechCode(this.currentLang);
        if (this.recognition) {
          this.recognition.lang = this.currentLangCode;
        }
      }
    });
  }

  toggleListening() {
    if (!this.recognition) {
      alert("Speech recognition is not supported in this browser. You can still type your query in the chat box!");
      return;
    }

    if (this.isListening) {
      this.recognition.stop();
    } else {
      try {
        this.recognition.lang = this.currentLangCode;
        this.recognition.start();
      } catch (err) {
        console.error("Speech recognition start failed:", err);
      }
    }
  }

  detectLanguageFromText(text) {
    // Check for Tamil Unicode range
    if (/[\u0B80-\u0BFF]/.test(text)) return "ta";
    // Check for Devanagari (Hindi/Marathi)
    if (/[\u0900-\u097F]/.test(text)) return "hi";
    // Check for Telugu
    if (/[\u0C00-\u0C7F]/.test(text)) return "te";
    // Check for Kannada
    if (/[\u0C80-\u0CFF]/.test(text)) return "kn";
    // Check for Malayalam
    if (/[\u0D00-\u0D7F]/.test(text)) return "ml";
    // Check for Bengali/Assamese
    if (/[\u0980-\u09FF]/.test(text)) return "bn";
    // Check for Gujarati
    if (/[\u0A80-\u0AFF]/.test(text)) return "gu";
    // Check for Punjabi
    if (/[\u0A00-\u0A7F]/.test(text)) return "pa";
    // Check for Odia
    if (/[\u0B00-\u0B7F]/.test(text)) return "or";
    // Check for Urdu/Arabic
    if (/[\u0600-\u06FF]/.test(text)) return "ur";

    // Common Tanglish keywords
    const lower = text.toLowerCase();
    if (lower.includes("enakku") || lower.includes("enna") || lower.includes("kidaikkum") || lower.includes("kalvi") || lower.includes("thittam") || lower.includes("magalir") || lower.includes("aracu")) {
      return "ta";
    }

    return this.currentLang;
  }

  handleVoiceCommand(transcriptText) {
    const cleanText = transcriptText.trim().toLowerCase();
    this.addChatMessage("user", transcriptText);

    // Auto-detect language if citizen spoke in Tamil script or Tanglish
    const detectedLang = this.detectLanguageFromText(transcriptText);
    const replyLang = detectedLang || this.currentLang || "ta";

    let intentKey = null;

    // Pattern matching
    if (
      cleanText.includes("enakku enna") ||
      cleanText.includes("kidaikkum") ||
      cleanText.includes("what can i get") ||
      cleanText.includes("mujhe kya") ||
      cleanText.includes("எனக்கு என்ன") ||
      cleanText.includes("கிடைக்கும்")
    ) {
      intentKey = "general_entitlement";
    } else if (
      cleanText.includes("education") ||
      cleanText.includes("scholarship") ||
      cleanText.includes("school") ||
      cleanText.includes("college") ||
      cleanText.includes("கல்வி") ||
      cleanText.includes("படிப்பு") ||
      cleanText.includes("உதவித்தொகை") ||
      cleanText.includes("शिक्षा")
    ) {
      intentKey = "education";
    } else if (
      cleanText.includes("agriculture") ||
      cleanText.includes("farmer") ||
      cleanText.includes("kisan") ||
      cleanText.includes("crop") ||
      cleanText.includes("விவசாயம்") ||
      cleanText.includes("விவசாயி") ||
      cleanText.includes("பயிர்") ||
      cleanText.includes("கிசான்") ||
      cleanText.includes("कृषि") ||
      cleanText.includes("किसान")
    ) {
      intentKey = "agriculture";
    } else if (
      cleanText.includes("health") ||
      cleanText.includes("hospital") ||
      cleanText.includes("ayushman") ||
      cleanText.includes("cmchis") ||
      cleanText.includes("மருத்துவம்") ||
      cleanText.includes("மருத்துவமனை") ||
      cleanText.includes("காப்பீடு") ||
      cleanText.includes("ஆயுஷ்மான்") ||
      cleanText.includes("स्वास्थ्य")
    ) {
      intentKey = "healthcare";
    } else if (
      cleanText.includes("women") ||
      cleanText.includes("girl") ||
      cleanText.includes("magalir") ||
      cleanText.includes("pudhumai") ||
      cleanText.includes("பெண்") ||
      cleanText.includes("மகளிர்") ||
      cleanText.includes("புதுமை") ||
      cleanText.includes("महिला")
    ) {
      intentKey = "women";
    } else if (
      cleanText.includes("business") ||
      cleanText.includes("loan") ||
      cleanText.includes("mudra") ||
      cleanText.includes("தொழில்") ||
      cleanText.includes("கடன்") ||
      cleanText.includes("முத்ரா") ||
      cleanText.includes("व्यापार") ||
      cleanText.includes("ऋण")
    ) {
      intentKey = "business";
    } else if (
      cleanText.includes("eligibility") ||
      cleanText.includes("qualify") ||
      cleanText.includes("தகுதி") ||
      cleanText.includes("பார்க்க") ||
      cleanText.includes("சோதிக்க") ||
      cleanText.includes("पात्रता")
    ) {
      intentKey = "check_eligibility";
    } else if (
      cleanText.includes("document") ||
      cleanText.includes("aadhaar") ||
      cleanText.includes("certificate") ||
      cleanText.includes("ஆவணம்") ||
      cleanText.includes("ஆதார்") ||
      cleanText.includes("சான்றிதழ்") ||
      cleanText.includes("दस्तावेज़")
    ) {
      intentKey = "documents";
    } else if (
      cleanText.includes("help") ||
      cleanText.includes("center") ||
      cleanText.includes("csc") ||
      cleanText.includes("esevai") ||
      cleanText.includes("e-sevai") ||
      cleanText.includes("மையம்") ||
      cleanText.includes("உதவி") ||
      cleanText.includes("இ-சேவை")
    ) {
      intentKey = "help_centers";
    }

    let responseText = "";
    let actionUrl = null;

    if (intentKey && VOICE_RESPONSES[intentKey]) {
      const intentObj = VOICE_RESPONSES[intentKey];
      responseText = intentObj[replyLang] || intentObj["ta"] || intentObj["en"];
      actionUrl = intentObj.url;
    } else {
      if (replyLang === "ta") {
        responseText = `"${transcriptText}" குறித்த அரசு நலத்திட்டங்களை கண்டறிந்துள்ளேன். உங்களுக்கான பொருத்தமான திட்டங்களை கீழே உள்ள இணைப்பில் காண்க.`;
      } else if (replyLang === "hi") {
        responseText = `"${transcriptText}" के लिए सरकारी योजनाएं खोजी गईं। आपके लिए उपयुक्त योजनाएं नीचे देखें।`;
      } else {
        responseText = `I searched government schemes for "${transcriptText}". Here are the matching welfare programs tailored for you.`;
      }
      actionUrl = `/schemes?q=${encodeURIComponent(transcriptText)}`;
    }

    setTimeout(() => {
      this.addChatMessage("assistant", responseText, actionUrl);
      this.speakText(responseText, replyLang);
    }, 400);
  }

  speakText(text, lang = null) {
    if (!this.speechSynth) return;
    this.speechSynth.cancel(); // cancel any ongoing speech

    const targetLang = lang || this.currentLang || "ta";
    const speechCode = this.getLangSpeechCode(targetLang);

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = speechCode;
    utterance.rate = 0.95; // Clear natural pacing
    utterance.pitch = 1.0;

    // Search specifically for matching voices in the browser
    const voices = this.speechSynth.getVoices();
    let selectedVoice = null;

    if (targetLang === "ta") {
      // Prioritize Tamil voices (Google தமிழ், Microsoft Valluvar, Microsoft Pallavi, ta-IN)
      selectedVoice = voices.find(
        (v) =>
          v.lang.toLowerCase() === "ta-in" ||
          v.lang.toLowerCase().startsWith("ta") ||
          v.name.toLowerCase().includes("tamil") ||
          v.name.toLowerCase().includes("valluvar") ||
          v.name.toLowerCase().includes("pallavi")
      );
    } else if (targetLang === "hi") {
      selectedVoice = voices.find(
        (v) =>
          v.lang.toLowerCase() === "hi-in" ||
          v.lang.toLowerCase().startsWith("hi") ||
          v.name.toLowerCase().includes("hindi") ||
          v.name.toLowerCase().includes("kalpana")
      );
    } else {
      selectedVoice = voices.find(
        (v) =>
          v.lang.toLowerCase().startsWith(speechCode.toLowerCase()) ||
          v.lang.toLowerCase().includes("in")
      );
    }

    if (selectedVoice && (targetLang === "en" || selectedVoice.lang.toLowerCase().startsWith(targetLang))) {
      utterance.voice = selectedVoice;

      utterance.onstart = () => {
        this.isSpeaking = true;
        this.startWaveformAnimation();
      };

      utterance.onend = () => {
        this.isSpeaking = false;
        this.stopWaveformAnimation();
      };

      utterance.onerror = () => {
        this.isSpeaking = false;
        this.stopWaveformAnimation();
      };

      this.speechSynth.speak(utterance);
    } else {
      // Local voice missing (e.g. Telugu, Kannada, Malayalam, Urdu on Windows/Android):
      // Stream native cloud audio from backend /api/tts
      if (this.currentAudio) {
        try { this.currentAudio.pause(); } catch(e) {}
      }
      const audioUrl = `/api/tts?lang=${encodeURIComponent(targetLang)}&text=${encodeURIComponent(text)}`;
      const audio = new Audio(audioUrl);
      this.currentAudio = audio;

      audio.onplay = () => {
        this.isSpeaking = true;
        this.startWaveformAnimation();
      };
      audio.onended = () => {
        this.isSpeaking = false;
        this.stopWaveformAnimation();
        this.currentAudio = null;
      };
      audio.onerror = () => {
        this.isSpeaking = false;
        this.stopWaveformAnimation();
        this.currentAudio = null;
      };

      audio.play().catch(e => {
        console.warn("Cloud TTS play prevented:", e);
        this.isSpeaking = false;
        this.stopWaveformAnimation();
      });
    }
  }

  addChatMessage(sender, text, actionUrl = null) {
    const chatContainer = document.getElementById("voiceChatHistory");
    if (!chatContainer) return;

    const messageRow = document.createElement("div");
    messageRow.className = `voice-message ${sender}-message animate-fade-in`;

    const buttonLabel = this.currentLang === "ta" ? "திட்டங்களை காண்க" : "Open Relevant Schemes";

    let html = `
      <div class="message-bubble ${sender}-bubble">
        <div class="message-meta">
          <span class="sender-name">${sender === "user" ? (this.currentLang === "ta" ? "நீங்கள்" : "You") : (this.currentLang === "ta" ? "திட்ட உதவியாளர்" : "Scheme Assistant")}</span>
          <span class="message-time">${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
        </div>
        <div class="message-text">${text}</div>
    `;

    if (actionUrl && sender === "assistant") {
      html += `
        <div class="message-action-btn-row">
          <a href="${actionUrl}" class="btn btn-sm btn-primary-soft">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
            ${buttonLabel}
          </a>
        </div>
      `;
    }

    html += `</div>`;
    messageRow.innerHTML = html;
    chatContainer.appendChild(messageRow);
    chatContainer.scrollTop = chatContainer.scrollHeight;
  }

  updateUIState(state, errorMsg = "") {
    const micButtons = document.querySelectorAll(".voice-mic-btn");
    const statusLabels = document.querySelectorAll(".voice-status-text");

    if (state === "listening") {
      micButtons.forEach((btn) => {
        btn.classList.add("listening");
        btn.setAttribute("aria-label", "Listening... Click to stop");
      });
      statusLabels.forEach((lbl) => {
        lbl.textContent = this.currentLang === "ta" ? "உங்கள் குரலைக் கேட்கிறது... இப்போது பேசுங்கள்" : "Listening to your voice... Speak now";
        lbl.classList.add("status-active");
      });
    } else if (state === "error") {
      micButtons.forEach((btn) => btn.classList.remove("listening"));
      statusLabels.forEach((lbl) => {
        lbl.textContent = errorMsg ? `Microphone: ${errorMsg}` : (this.currentLang === "ta" ? "மைக்ரோஃபோன் இடைநிறுத்தப்பட்டது. மீண்டும் தட்டவும்." : "Microphone paused. Tap to retry.");
        lbl.classList.remove("status-active");
      });
    } else {
      micButtons.forEach((btn) => {
        btn.classList.remove("listening");
        btn.setAttribute("aria-label", "Click microphone to speak");
      });
      statusLabels.forEach((lbl) => {
        lbl.textContent = this.currentLang === "ta" ? "பேச மைக்ரோஃபோனைத் தட்டவும் அல்லது கட்டளையை தேர்வு செய்யவும்" : "Tap microphone to speak or choose a command below";
        lbl.classList.remove("status-active");
      });
    }
  }

  initWaveform(canvasId = "voiceWaveformCanvas") {
    this.waveCanvas = document.getElementById(canvasId);
    if (!this.waveCanvas) return;
    this.canvasCtx = this.waveCanvas.getContext("2d");
    this.drawIdleWaveform();
  }

  startWaveformAnimation() {
    if (!this.waveCanvas || !this.canvasCtx) return;
    cancelAnimationFrame(this.animFrameId);

    const animate = () => {
      this.wavePhase += 0.08;
      const width = this.waveCanvas.width;
      const height = this.waveCanvas.height;
      const ctx = this.canvasCtx;

      ctx.clearRect(0, 0, width, height);

      // Draw dynamic multi-layer wave
      const lines = [
        { color: "rgba(4, 106, 56, 0.75)", freq: 0.035, amp: 26, speed: 1.0 },
        { color: "rgba(255, 103, 31, 0.75)", freq: 0.045, amp: 20, speed: -1.2 },
        { color: "rgba(4, 106, 56, 0.35)", freq: 0.02, amp: 14, speed: 0.8 }
      ];

      lines.forEach((line) => {
        ctx.beginPath();
        ctx.lineWidth = 3.5;
        ctx.strokeStyle = line.color;
        ctx.lineCap = "round";

        for (let x = 0; x < width; x += 3) {
          const y =
            height / 2 +
            Math.sin(x * line.freq + this.wavePhase * line.speed) *
              line.amp *
              (Math.sin((x / width) * Math.PI) + 0.2);

          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      });

      if (this.isListening || this.isSpeaking) {
        this.animFrameId = requestAnimationFrame(animate);
      } else {
        this.drawIdleWaveform();
      }
    };

    this.animFrameId = requestAnimationFrame(animate);
  }

  stopWaveformAnimation() {
    cancelAnimationFrame(this.animFrameId);
    this.drawIdleWaveform();
  }

  drawIdleWaveform() {
    if (!this.waveCanvas || !this.canvasCtx) return;
    const ctx = this.canvasCtx;
    const width = this.waveCanvas.width;
    const height = this.waveCanvas.height;

    ctx.clearRect(0, 0, width, height);
    ctx.beginPath();
    ctx.strokeStyle = "#CBD5E1";
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 6]);
    ctx.moveTo(0, height / 2);
    ctx.lineTo(width, height / 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }
}

// Global Voice Assistant Instance
window.voiceAssistant = new VoiceAssistantEngine();

document.addEventListener("DOMContentLoaded", () => {
  // Bind all microphone trigger buttons
  document.querySelectorAll(".voice-mic-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      window.voiceAssistant.toggleListening();
    });
  });

  // Voice language selector buttons
  document.querySelectorAll(".voice-lang-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.getAttribute("data-lang");
      if (lang) {
        window.voiceAssistant.setVoiceLanguage(lang);
      }
    });
  });

  // Quick Command Prompt Chips
  document.querySelectorAll(".quick-voice-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const text = chip.getAttribute("data-command") || chip.textContent.trim();
      const input = document.getElementById("voiceTextInput");
      if (input) input.value = text;
      window.voiceAssistant.handleVoiceCommand(text);
    });
  });

  // Text message submit inside voice chat
  const voiceForm = document.getElementById("voiceChatForm");
  if (voiceForm) {
    voiceForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const input = document.getElementById("voiceTextInput");
      if (input && input.value.trim() !== "") {
        window.voiceAssistant.handleVoiceCommand(input.value.trim());
        input.value = "";
      }
    });
  }

  // Preload browser voices on user interaction
  if (window.speechSynthesis) {
    window.speechSynthesis.onvoiceschanged = () => {
      // voices loaded in browser
    };
  }

  // Initialize canvas if present
  window.voiceAssistant.initWaveform();
});
