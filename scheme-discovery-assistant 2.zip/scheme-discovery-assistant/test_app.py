"""
Automated Test Suite for Scheme Discovery Assistant
Verifies all 10 pages, strict security/authentication, real document upload/view/delete,
data entry synchronization, and Tamil/multilingual voice assistant.
"""

import io
import unittest
from app import app
from database import init_db

class SchemeDiscoveryAssistantTestCase(unittest.TestCase):
    def setUp(self):
        init_db()
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        self.client = app.test_client()

    def test_01_home_page(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Scheme Discovery Assistant', response.data)
        self.assertIn(b'PM-Kisan', response.data)

    def test_02_wizard_page_and_data_entry(self):
        response = self.client.get('/wizard')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Citizen Eligibility Wizard', response.data)

        # Enter data via wizard API
        payload = {
            "age": 24,
            "annual_income": 95000,
            "state": "Tamil Nadu",
            "district": "Madurai",
            "gender": "Female",
            "social_category": "OBC",
            "occupation": "Student",
            "education_level": "Graduate",
            "needs": ["education_scholarship", "health_cover"]
        }
        response = self.client.post('/api/evaluate-eligibility', json=payload)
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertTrue(data.get("success"))
        self.assertGreater(data.get("matched_count"), 0)

        # Check that eligibility summary shows user's entered data
        summary_res = self.client.get('/eligibility-summary')
        self.assertEqual(summary_res.status_code, 200)
        self.assertIn(b'24', summary_res.data) # user age
        self.assertIn(b'Tamil Nadu', summary_res.data) # user state

    def test_03_schemes_page_and_filters(self):
        response = self.client.get('/schemes')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Discover Government Welfare Schemes', response.data)

        # Test Agriculture category filter
        response_filtered = self.client.get('/schemes?category=Agriculture')
        self.assertEqual(response_filtered.status_code, 200)
        self.assertIn(b'PM-Kisan', response_filtered.data)

        # Test Tamil Nadu state filter
        response_state = self.client.get('/schemes?state=Tamil%20Nadu')
        self.assertEqual(response_state.status_code, 200)
        self.assertIn(b'Kalaignar Magalir', response_state.data)

    def test_04_scheme_detail_page(self):
        response = self.client.get('/schemes/1')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Why You Qualify', response.data)
        self.assertIn(b'PM-Kisan Samman Nidhi', response.data)

    def test_05_security_unauthenticated_access_blocked(self):
        # Unauthenticated users must be redirected to /login for protected routes
        for protected_url in ['/dashboard', '/documents', '/profile']:
            res = self.client.get(protected_url)
            self.assertEqual(res.status_code, 302)
            self.assertIn('/login', res.headers['Location'])

    def test_06_auth_login_and_dashboard(self):
        # Login with valid citizen credentials
        res = self.client.post('/login', data={
            'email': 'citizen@example.com',
            'password': 'Password@123'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Welcome back, Ramesh Kannan', res.data)
        self.assertIn(b'Application Status Tracker', res.data)

    def test_07_real_document_upload_view_delete(self):
        # 1. Log in
        self.client.post('/login', data={
            'email': 'citizen@example.com',
            'password': 'Password@123'
        })

        # 2. View documents page
        doc_page_res = self.client.get('/documents')
        self.assertEqual(doc_page_res.status_code, 200)
        self.assertIn(b'Document Center & Readiness Vault', doc_page_res.data)

        # 3. Real file upload
        test_file = (io.BytesIO(b"%PDF-1.4 test document content"), "test_income_certificate.pdf")
        upload_res = self.client.post('/api/documents/upload', data={
            'doc_type': 'Income Certificate',
            'doc_number': 'TN-TEST-INC-2026',
            'doc_file': test_file
        }, content_type='multipart/form-data')
        self.assertEqual(upload_res.status_code, 200)
        upload_data = upload_res.get_json()
        self.assertTrue(upload_data.get("success"))

        # 4. View document (ID 1 pre-seeded aadhaar)
        view_res = self.client.get('/documents/view/1')
        self.assertEqual(view_res.status_code, 200)

        # 5. Download document
        download_res = self.client.get('/documents/download/1')
        self.assertEqual(download_res.status_code, 200)
        self.assertIn('attachment', download_res.headers.get('Content-Disposition', ''))

    def test_08_voice_assistant_page_with_tamil(self):
        response = self.client.get('/voice')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Multilingual Voice Assistant', response.data)
        self.assertIn('\u0ba4\u0bae\u0bbf\u0bb4\u0bcd'.encode('utf-8'), response.data) # 'தமிழ்'

    def test_09_help_centers_page(self):
        response = self.client.get('/help-centers')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Help Centers', response.data)
        self.assertIn(b'e-Sevai', response.data)

    def test_10_predictor_page_and_api(self):
        response = self.client.get('/predictor')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Application Success Predictor', response.data)

        api_res = self.client.get('/api/predictor/analyze?scheme_id=1')
        self.assertEqual(api_res.status_code, 200)
        data = api_res.get_json()
        self.assertTrue(data.get("success"))
        self.assertIn("score", data)

    def test_11_user_registration_flow(self):
        # Register a brand new citizen with unique email
        import time
        unique_email = f"newcitizen_{int(time.time()*1000)}@example.com"
        reg_res = self.client.post('/register', data={
            'full_name': 'Meenakshi Sundaram',
            'email': unique_email,
            'phone': '+91 94433 22110',
            'age': '22',
            'gender': 'Female',
            'state': 'Tamil Nadu',
            'occupation': 'Student',
            'annual_income': '120000',
            'social_category': 'OBC',
            'password': 'SecurePassword@123',
            'confirm_password': 'SecurePassword@123'
        }, follow_redirects=True)
        self.assertEqual(reg_res.status_code, 200)
        self.assertIn(b'Meenakshi Sundaram', reg_res.data)

    def test_12_search_autocomplete_api(self):
        res = self.client.get('/api/search?q=kisan')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(len(data) > 0)
        self.assertIn("Kisan", data[0]["title"])

    def test_13_validate_id_aadhaar_and_voter(self):
        # 1. Valid Aadhaar with Verhoeff checksum
        res1 = self.client.post('/api/validate-id', json={
            'id_type': 'aadhaar',
            'id_number': '2345 6789 0124'
        })
        self.assertEqual(res1.status_code, 200)
        data1 = res1.get_json()
        self.assertTrue(data1.get("valid"))
        self.assertEqual(data1.get("digit_count"), 12)
        self.assertIn("•••• •••• 0124", data1.get("masked"))

        # 2. 11-digit Aadhaar (must report 11 digits and explain 12 are needed)
        res2 = self.client.post('/api/validate-id', json={
            'id_type': 'aadhaar',
            'id_number': '2345 6789 012'
        })
        data2 = res2.get_json()
        self.assertFalse(data2.get("valid"))
        self.assertIn("11", data2.get("message"))
        self.assertIn("12", data2.get("message"))

        # 3. 13-digit Aadhaar (must report 13 digits)
        res3 = self.client.post('/api/validate-id', json={
            'id_type': 'aadhaar',
            'id_number': '2345 6789 0124 5'
        })
        data3 = res3.get_json()
        self.assertFalse(data3.get("valid"))
        self.assertIn("13", data3.get("message"))

        # 4. Valid Voter ID (EPIC: 3 letters + 7 numbers)
        res4 = self.client.post('/api/validate-id', json={
            'id_type': 'voter',
            'id_number': 'ABC1234567'
        })
        data4 = res4.get_json()
        self.assertTrue(data4.get("valid"))
        self.assertEqual(data4.get("clean"), "ABC1234567")

        # 5. Invalid Voter ID format
        res5 = self.client.post('/api/validate-id', json={
            'id_type': 'voter',
            'id_number': '1234567890'
        })
        data5 = res5.get_json()
        self.assertFalse(data5.get("valid"))

    def test_14_api_tts_all_7_languages(self):
        # Verify TTS endpoint delivers audio/mpeg for all 7 core languages
        core_langs = ['ta', 'en', 'te', 'kn', 'ml', 'hi', 'ur']
        for lang in core_langs:
            res = self.client.get(f'/api/tts?lang={lang}&text=test')
            self.assertEqual(res.status_code, 200, f"TTS failed for {lang}")
            self.assertEqual(res.mimetype, 'audio/mpeg')
            self.assertGreater(len(res.data), 100)

    def test_15_nearest_help_center_api(self):
        res = self.client.get('/api/help-centers/nearest?lat=13.0827&lng=80.2707')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data.get("success"))
        self.assertIsNotNone(data.get("nearest"))
        self.assertIn("distance_km", data.get("nearest"))

    def test_16_multilingual_registration_guidance_and_i18n(self):
        # 1. Verify register page contains full data-i18n tags
        res = self.client.get('/register')
        self.assertEqual(res.status_code, 200)
        content = res.data.decode('utf-8')
        for tag in ['data-i18n="reg_title"', 'data-i18n="reg_lbl_name"', 'data-i18n="reg_lbl_phone"',
                    'data-i18n="reg_lbl_age"', 'data-i18n="reg_lbl_gender"', 'data-i18n="reg_lbl_category"',
                    'data-i18n="reg_lbl_state"', 'data-i18n="reg_lbl_income"', 'data-i18n="reg_lbl_occupation"',
                    'data-i18n="reg_lbl_password"', 'data-i18n="reg_btn_submit"']:
            self.assertIn(tag, content, f"Missing {tag} in register.html")

        # 2. Verify elder_guide.js contains 7-language localized field prompts
        with open('static/js/elder_guide.js', 'r', encoding='utf-8') as f:
            elder_js = f.read()
        self.assertIn('parseSpokenDigits', elder_js)
        self.assertIn('parseSpokenAge', elder_js)
        self.assertIn('matchMultilingualOption', elder_js)
        self.assertIn('முழு சட்டப்பூர்வ பெயர்', elder_js) # Tamil legal name prompt
        self.assertIn('10 இலக்க மொபைல் எண்', elder_js) # Tamil phone prompt
        self.assertIn('விவசாயி', elder_js) # Tamil farmer option
        self.assertIn('பெண்', elder_js) # Tamil female option
        self.assertIn('పూర్తి చట్టబద్ధమైన పేరు', elder_js) # Telugu prompt
        self.assertIn('पूरा कानूनी नाम', elder_js) # Hindi prompt

        # 3. Verify i18n.js has the translation keys
        with open('static/js/i18n.js', 'r', encoding='utf-8') as f:
            i18n_js = f.read()
        self.assertIn('reg_lbl_name', i18n_js)
        self.assertIn('opt_gender_male', i18n_js)
        self.assertIn('opt_occ_farmer', i18n_js)
        self.assertIn('விவசாயி / வேளாண்மை', i18n_js)

if __name__ == '__main__':
    unittest.main()
