"""
Document Rules and Verification Engine
=======================================
Implements manual ID validation (Aadhaar with Verhoeff checksum, Voter ID EPIC format)
and automated document verification rules for Indian welfare scheme applications.

NOTE: This system performs optical, keyword, and structural integrity checks to verify
that the uploaded file conforms to the expected document type, resolution, and format.
It verifies that the image looks like the right document; it is not proof that the
document is legally authentic or government-verified.
"""

import re
import io
import math
from PIL import Image, ImageStat

# ==============================================================================
# 1. VERHOEFF ALGORITHM IMPLEMENTATION (Aadhaar 12-Digit Checksum)
# ==============================================================================

# Multiplication table d
VERHOEFF_D = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
    [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
    [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
    [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
    [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
    [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
    [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
    [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
    [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
]

# Permutation table p
VERHOEFF_P = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
    [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
    [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
    [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
    [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
    [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
    [7, 0, 4, 6, 9, 1, 3, 2, 5, 8]
]

# Inverse table inv
VERHOEFF_INV = [0, 4, 3, 2, 1, 5, 6, 7, 8, 9]


def validate_verhoeff(num_str: str) -> bool:
    """Validates a numeric string using the Verhoeff checksum algorithm."""
    if not num_str.isdigit():
        return False
    c = 0
    reversed_digits = [int(x) for x in reversed(num_str)]
    for i, digit in enumerate(reversed_digits):
        c = VERHOEFF_D[c][VERHOEFF_P[i % 8][digit]]
    return c == 0


def generate_verhoeff_checksum(num_str: str) -> int:
    """Computes the Verhoeff checksum digit for a numeric string."""
    c = 0
    reversed_digits = [int(x) for x in reversed(num_str)]
    for i, digit in enumerate(reversed_digits):
        c = VERHOEFF_D[c][VERHOEFF_P[(i + 1) % 8][digit]]
    return VERHOEFF_INV[c]


def clean_id_number(raw_str: str) -> str:
    """Removes spaces, hyphens, and punctuation from an ID string."""
    if not raw_str:
        return ""
    return re.sub(r"[\s\-\./_]+", "", raw_str).strip()


def validate_aadhaar_number(raw_num: str):
    """
    Validates Aadhaar number:
    - Must be exactly 12 digits (after stripping spaces/dashes)
    - Digits only
    - First digit 2 to 9
    - Verhoeff checksum must pass
    Returns (is_valid, error_code, clean_digits, formatted_444)
    """
    clean = clean_id_number(raw_num)
    if not clean:
        return False, "EMPTY_NUMBER", "", ""

    # Check non-digit characters
    if not clean.isdigit():
        return False, "NON_DIGITS", clean, ""

    digit_count = len(clean)
    if digit_count != 12:
        return False, f"WRONG_LENGTH_{digit_count}", clean, ""

    # First digit check (2 to 9)
    first_digit = int(clean[0])
    if first_digit < 2:
        return False, "INVALID_FIRST_DIGIT", clean, ""

    # Verhoeff checksum check
    if not validate_verhoeff(clean):
        return False, "CHECKSUM_FAILED", clean, ""

    formatted = f"{clean[0:4]} {clean[4:8]} {clean[8:12]}"
    masked = f"•••• •••• {clean[8:12]}"
    return True, "VALID", clean, formatted


def validate_voter_id(raw_num: str):
    """
    Validates Voter ID (EPIC):
    - Exactly 10 characters
    - 3 uppercase letters followed by 7 digits
    Returns (is_valid, error_code, clean_str)
    """
    clean = clean_id_number(raw_num).upper()
    if not clean:
        return False, "EMPTY_NUMBER", ""

    if len(clean) != 10:
        return False, f"WRONG_LENGTH_{len(clean)}", clean

    # Regex: 3 letters + 7 digits
    if not re.match(r"^[A-Z]{3}[0-9]{7}$", clean):
        return False, "INVALID_FORMAT", clean

    return True, "VALID", clean


# ==============================================================================
# 2. DOCUMENT KEYWORDS & VERIFICATION CONFIGURATION
# ==============================================================================

DOC_REQUIREMENTS = {
    "Aadhaar Card": {
        "title": "Aadhaar Card",
        "header_keywords": [
            "aadhaar", "unique identification", "uidai", "government of india",
            "मेरा आधार", "मेरी पहचान", "आधार", "भारत सरकार",
            "ஆதார்", "இந்திய அரசு", "எனது ஆதார்",
            "యూఐడీఏఐ", "ఆధార్", "భారత ప్రభుత్వం",
            "ಭಾರತ ಸರ್ಕಾರ", "ಆಧಾರ್",
            "ആധാർ", "ഭാരത സർക്കാർ",
            "حکومت ہند", "آدھار"
        ],
        "demographic_keywords": [
            "dob", "date of birth", "year of birth", "yob", "birth",
            "பிறந்த தேதி", "जन्म तिथि", "పుట్టిన తేదీ", "ಜನ್ಮ ದಿನಾಂಕ", "ജനന തീയതി", "تاریخ پیدائش",
            "male", "female", "transgender", "ஆண்", "பெண்", "पुरुष", "महिला", "స్త్రీ", "పురుషుడు", "ಗಂಡು", "ಹೆಣ್ಣು", "مرد", "عورت"
        ],
        "qr_keywords": ["qr", "code", "secure qr", "uidai.gov.in"],
        "back_address_keywords": ["address", "s/o", "w/o", "d/o", "c/o", "முகவரி", "पता", "చిరునామా", "ವಿಳಾಸ", "മേൽവിലാസം", "پتہ"],
        "id_type": "aadhaar"
    },
    "Voter ID": {
        "title": "Election Photo Identity Card (EPIC)",
        "header_keywords": [
            "election commission of india", "election commission", "epic",
            "भारत निर्वाचन आयोग", "मतदाता फोटो पहचान पत्र",
            "இந்திய தேர்தல் ஆணையம்", "வாக்காளர் அடையாள அட்டை",
            "భారత ఎన్నికల సంఘం", "ఓటరు గుర్తింపు కార్డు",
            "ಭಾರತ ಚುನಾವಣಾ ಆಯೋಗ",
            "ഇലക്ഷൻ കമ്മീഷൻ ഓഫ് ഇന്ത്യ",
            "الیکشن کمیشن آف انڈیا"
        ],
        "demographic_keywords": [
            "elector", "name", "father", "husband", "gender", "age",
            "வாக்காளர் பெயர்", "தந்தை", "கணவர்", "வயது",
            "निर्वाचक", "पिता", "पति", "लिंग", "आयु",
            "తండ్రి", "భర్త", "ತಂದೆ", "ಗಂಡ", "പിതാവ്", "ഭർത്താവ്", "والد", "شوہر"
        ],
        "id_type": "voter"
    },
    "Income Certificate": {
        "title": "Income Certificate",
        "header_keywords": [
            "revenue department", "tahsildar", "district collector", "taluk", "revenue",
            "வருவாய்த்துறை", "வட்டாட்சியர்", "வருமானச் சான்றிதழ்",
            "राजस्व विभाग", "तहसीलदार", "आय प्रमाण पत्र",
            "రెవెన్యూ శాఖ", "ಆದಾಯ ಪ್ರಮಾಣ ಪತ್ರ", "വരുമാന സർട്ടിഫിക്കറ്റ്", "آمدنی کا سرٹیفکیٹ"
        ],
        "content_keywords": [
            "certificate no", "cert no", "annual income", "rupees", "rs", "inr", "family income",
            "ஆண்டு வருமானம்", "ரூபாய்", "சான்றிதழ் எண்",
            "वार्षिक आय", "रुपये", "प्रमाण पत्र क्रमांक"
        ],
        "validity_keywords": ["digitally signed", "signature", "seal", "date of issue", "கையொப்பம்", "முத்திரை", "हस्ताक्षर", "دستخط"],
        "id_type": "certificate"
    },
    "Community Certificate": {
        "title": "Community / Caste Certificate",
        "header_keywords": [
            "revenue department", "tahsildar", "zonal deputy tahsildar", "taluk",
            "வருவாய்த்துறை", "வட்டாட்சியர்", "சாதிச் சான்றிதழ்", "இனச் சான்றிதழ்",
            "जाति प्रमाण पत्र", "राजस्व विभाग", "కుల ధృవీకరణ పత్రం", "ಜಾತಿ ಪ್ರಮಾಣ ಪತ್ರ"
        ],
        "content_keywords": [
            "community", "caste", "sub-caste", "scheduled caste", "scheduled tribe", "backward class", "obc", "sc", "st", "mbc",
            "வகுப்பு", "சாதி", "பிற்படுத்தப்பட்டோர்", "தாழ்த்தப்பட்டோர்",
            "जाति", "वर्ग", "अनुसूचित जाति", "अन्य पिछड़ा वर्ग"
        ],
        "validity_keywords": ["digitally signed", "signature", "seal", "date of issue", "கையொப்பம்", "मुத்திரை"],
        "id_type": "certificate"
    },
    "Residence Certificate": {
        "title": "Nativity / Residence Certificate",
        "header_keywords": [
            "revenue department", "tahsildar", "taluk",
            "இருப்பிடச் சான்றிதழ்", "வசிப்பிடச் சான்றிதழ்",
            "निवास प्रमाण पत्र", "मूल निवास", "స్థానిక ధృవీకరణ పత్రం"
        ],
        "content_keywords": [
            "residing at", "residence", "native", "nativity", "permanent resident",
            "வசித்து வருகிறார்", "இருப்பிடம்", "निवास", "నివాసి"
        ],
        "validity_keywords": ["digitally signed", "signature", "seal", "date of issue"],
        "id_type": "certificate"
    },
    "Bank Passbook": {
        "title": "Bank Account Passbook",
        "header_keywords": [
            "bank", "state bank", "canara", "indian bank", "hdfc", "icici", "punjab national", "baroda",
            "வங்கி", "பாரத ஸ்டேட் வங்கி", "இந்தியன் வங்கி", "கனரா வங்கி",
            "बैंक", "स्टेट बैंक", "खाता", "بینک"
        ],
        "content_keywords": [
            "account no", "ac no", "ifsc", "branch", "micr", "cif",
            "கணக்கு எண்", "கிளை", "ఐఎఫ్ఎస్సీ", "खाता संख्या", "शाखा"
        ],
        "validity_keywords": ["account holder", "balance", "ledger", "passbook"],
        "id_type": "bank"
    }
}


# ==============================================================================
# 3. IMAGE QUALITY & READABILITY CHECK
# ==============================================================================

def check_image_quality(image_bytes: bytes):
    """
    Checks resolution, brightness, contrast, and basic clarity.
    Returns (passed, reason, metrics)
    """
    try:
        img = Image.open(io.BytesIO(image_bytes))
        width, height = img.size

        # Check resolution (min 400x250)
        if width < 380 or height < 240:
            return False, f"Image resolution ({width}x{height}) is too low. Please upload a clear photo with at least 400x250 pixels.", {"width": width, "height": height}

        # Convert to grayscale to check brightness & contrast
        gray = img.convert("L")
        stat = ImageStat.Stat(gray)
        mean_brightness = stat.mean[0]
        std_contrast = stat.stddev[0]

        # Too dark: mean < 32
        if mean_brightness < 32:
            return False, "The document image is too dark to read. Please retake the photo in good lighting.", {"brightness": round(mean_brightness, 1), "contrast": round(std_contrast, 1)}

        # Too bright / washed out: mean > 248
        if mean_brightness > 248:
            return False, "The document image is washed out or overexposed. Please retake the photo without direct flash glare.", {"brightness": round(mean_brightness, 1), "contrast": round(std_contrast, 1)}

        # Flat / blank image: stddev < 12
        if std_contrast < 12:
            return False, "The image appears blank or has extremely low contrast. Please ensure the card text is clearly visible.", {"brightness": round(mean_brightness, 1), "contrast": round(std_contrast, 1)}

        return True, "QUALITY_OK", {
            "width": width,
            "height": height,
            "brightness": round(mean_brightness, 1),
            "contrast": round(std_contrast, 1)
        }
    except Exception as e:
        return False, f"Could not analyze image format: {str(e)}", {}


# ==============================================================================
# 4. DOCUMENT OCR & KEYWORD VERIFICATION
# ==============================================================================

def verify_document_text(doc_type: str, ocr_text: str, typed_number: str = None):
    """
    Verifies extracted OCR text against document rules.
    Checks:
    1. Header / Authority keywords
    2. Specific document numbers (Aadhaar / Voter ID format)
    3. Cross-reference between typed number and OCR extracted number
    Returns dict with verification details.
    """
    rule = DOC_REQUIREMENTS.get(doc_type)
    if not rule:
        # Unknown custom certificate - accept with basic sanity
        return {
            "valid": True,
            "doc_type": doc_type,
            "message": "Custom certificate recorded.",
            "details": {}
        }

    text_lower = ocr_text.lower() if ocr_text else ""
    found_headers = [kw for kw in rule.get("header_keywords", []) if kw.lower() in text_lower]
    found_demographics = [kw for kw in rule.get("demographic_keywords", []) if kw.lower() in text_lower]
    found_contents = [kw for kw in rule.get("content_keywords", []) if kw.lower() in text_lower]

    missing_items = []
    extracted_number = None

    if doc_type == "Aadhaar Card":
        # Search for 12-digit Aadhaar patterns
        # Matches: 1234 5678 9012 or 123456789012
        aadhaar_matches = re.findall(r"\b([2-9]\d{3}[\s\-]?[0-9]{4}[\s\-]?[0-9]{4})\b", ocr_text)
        valid_found_numbers = []
        for match in aadhaar_matches:
            clean = clean_id_number(match)
            if len(clean) == 12 and validate_verhoeff(clean):
                valid_found_numbers.append(clean)

        if valid_found_numbers:
            extracted_number = valid_found_numbers[0]
        else:
            missing_items.append("12-digit valid Aadhaar number")

        if len(found_headers) == 0:
            missing_items.append("Words 'Government of India' or 'Aadhaar' (or regional equivalent)")

        if len(found_demographics) == 0:
            missing_items.append("Date of Birth / Gender details")

    elif doc_type == "Voter ID":
        voter_matches = re.findall(r"\b([A-Za-z]{3}\s?[0-9]{7})\b", ocr_text)
        if voter_matches:
            extracted_number = clean_id_number(voter_matches[0]).upper()
        else:
            missing_items.append("10-character EPIC Voter ID number (3 letters + 7 digits)")

        if len(found_headers) == 0:
            missing_items.append("Words 'Election Commission of India' (or regional equivalent)")

    else:
        # Certificates / Bank Passbook
        if len(found_headers) == 0:
            missing_items.append("Issuing authority / Bank name")

        if "content_keywords" in rule and len(found_contents) == 0:
            missing_items.append("Document details / Certificate number")

    # Cross-match typed number with OCR extracted number
    number_mismatch = False
    if typed_number and extracted_number:
        clean_typed = clean_id_number(typed_number).upper()
        clean_extracted = clean_id_number(extracted_number).upper()
        if clean_typed != clean_extracted:
            number_mismatch = True

    is_valid = len(missing_items) == 0 and not number_mismatch

    return {
        "valid": is_valid,
        "doc_type": doc_type,
        "extracted_number": extracted_number,
        "number_mismatch": number_mismatch,
        "missing_items": missing_items,
        "found_headers": found_headers,
        "disclaimer": "This check verifies the visual structure and required keywords of the document. It is not legal proof of government authenticity."
    }
