# Scheme Discovery Assistant (SDA)
### Indian Citizen Welfare & Government Schemes Discovery Platform

A full-stack, desktop-first, tablet, and mobile responsive web application designed for Indian citizens to discover, evaluate, and apply for Central and State government welfare schemes with instant AI eligibility matching, document verification, and voice assistant support.

---

## 🚀 Key Features

### 1. Desktop-First + Tablet + Mobile Responsive Layout
- **Desktop**: Full-width SaaS dashboard with persistent collapsible sidebar, analytics cards, tables, circular SVG gauges, and leaflet interactive map.
- **Tablet**: Gracefully adapts with flexible 2-column grids and slide-out navigation.
- **Mobile**: Touch-optimized card layouts, mobile header drawer, and persistent bottom navigation bar featuring a quick-access Voice Assistant button.

### 2. Design System & Accessibility
- **Background**: `#F8FAFC`
- **Primary Color**: `#046A38` (Forest Emerald)
- **Secondary Color**: `#FF671F` (Vibrant Saffron)
- **Typography**: Google Font *Plus Jakarta Sans*
- **Border Radius**: `16px` with soft fintech shadows
- **Compliance**: Custom geometric shield branding without any restricted national emblems, flags, or official government logos.

### 3. 13 Indian Languages Dynamic Translation System
Instant client-side language switching with `localStorage` persistence across:
1. **English** (`en`)
2. **Tamil** (`ta` - தமிழ்)
3. **Hindi** (`hi` - हिन्दी)
4. **Telugu** (`te` - తెలుగు)
5. **Kannada** (`kn` - ಕನ್ನಡ)
6. **Malayalam** (`ml` - മലയാളം)
7. **Bengali** (`bn` - বাংলা)
8. **Marathi** (`mr` - मराठी)
9. **Gujarati** (`gu` - ગુજરાતી)
10. **Punjabi** (`pa` - ਪੰਜਾਬੀ)
11. **Odia** (`or` - ଓଡ଼ିଆ)
12. **Assamese** (`as` - অসমীয়া)
13. **Urdu** (`ur` - اردو - RTL supported)

### 4. Multilingual Voice Assistant
- **Speech-to-Text (STT)** & **Text-to-Speech (TTS)** via Web Speech API with regional Indian language accents.
- **Live Canvas Audio Waveform**: Real-time oscilloscope wave reacting when listening or speaking.
- **Voice Commands Engine**:
  - *"Show education schemes"*
  - *"Find agriculture schemes"*
  - *"Check my eligibility"*
  - *"Enakku enna government schemes kidaikkum?"* (Tamil natural language intent)
  - *"Mujhe kaunsi yojana mil sakti hai?"* (Hindi natural language intent)
- Integrated voice and text chat interface with clickable scheme preview cards.

### 5. The 10 Application Modules & Pages
1. **Home Page (`/`)**: Hero section, live statistics counters, welfare category grid, featured schemes, 3-step workflow guide.
2. **Eligibility Wizard (`/wizard`)**: 4-step interactive form (Demographics, Location & Social Category, Livelihood & Income, Welfare Needs) with live matching counter.
3. **AI Eligibility Summary (`/eligibility-summary`)**: Circular SVG eligibility score gauges, total annual entitlement valuation, and ranked recommendations.
4. **Scheme Results (`/schemes`)**: Search bar, category quick pills, state filters, match percentage badges, direct apply modal, and bookmarking.
5. **Scheme Detail Page (`/schemes/<id>`)**: "Why You Qualify" breakdown, direct DBT benefits, mandatory documents checklist, workflow timeline, and official portal link.
6. **Document Center (`/documents`)**: Citizen digital vault for Aadhaar, Income Certificate, Community Certificate, Residence Certificate, and Bank Passbook with an 80% readiness progress ring and upload simulator.
7. **Application Success Predictor (`/predictor`)**: Pre-submission audit engine with approval odds gauge, data consistency checks, risk warnings, and actionable recommendations.
8. **Voice Assistant Hub (`/voice`)**: Dedicated voice interface with large animated mic button, waveform canvas, command prompts, and conversational stream.
9. **Help Centers Page (`/help-centers`)**: Interactive Leaflet.js map with custom pins for Common Service Centers (CSCs), Tamil Nadu e-Sevai Kendras, and Jan Seva Desks with direct calling and directions.
10. **Citizen Dashboard (`/dashboard`)**: Active applications status tracker with stage progress, saved schemes watchlist, and real-time alert notifications.

### 6. Authentication & Security
- Sign In (`/login`), Registration (`/register`), Forgot Password (`/forgot-password`), and Citizen Profile (`/profile`).
- Password hashing with `werkzeug.security`.
- Session management.
- Pre-seeded Demo Citizen Account:
  - **Email**: `citizen@example.com`
  - **Password**: `Password@123`

---

## 🛠️ Project Structure

```
scheme-discovery-assistant/
├── app.py                      # Flask backend controller & REST API endpoints
├── database.py                 # SQLite database schema initialization & seeder
├── schemes.db                  # SQLite database with 20+ realistic schemes & demo records
├── test_app.py                 # Automated unit & integration test suite (14 tests)
├── requirements.txt            # Python dependencies
├── static/
│   ├── css/
│   │   └── style.css           # Master desktop-first responsive stylesheet
│   ├── js/
│   │   ├── i18n.js             # 13 Indian languages dictionary & instant page translator
│   │   ├── voice.js            # Speech recognition, audio synthesis & waveform visualizer
│   │   ├── wizard.js           # Multi-step eligibility wizard logic & score estimator
│   │   └── main.js             # Application tracker, leaflet maps, search autocomplete
│   └── uploads/                # Document vault storage folder
└── templates/
    ├── base.html               # Base layout shell (Top navbar, sidebar, mobile bottom nav)
    ├── home.html               # 1. Home page
    ├── wizard.html             # 2. Eligibility wizard
    ├── eligibility_summary.html# 3. AI eligibility summary
    ├── schemes.html            # 4. Scheme catalog & filters
    ├── scheme_detail.html      # 5. Scheme detail page
    ├── documents.html          # 6. Document center & vault
    ├── predictor.html          # 7. Application success predictor
    ├── voice.html              # 8. Voice assistant page
    ├── help_centers.html       # 9. Help centers interactive map
    ├── dashboard.html          # 10. Citizen dashboard
    ├── login.html              # Authentication: Sign in
    ├── register.html           # Authentication: Register
    ├── forgot_password.html    # Authentication: Forgot password
    └── profile.html            # User profile settings
```

---

## 🏃 Running the Application

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Initialize Database (Already pre-seeded)
```bash
python database.py
```

### 3. Run Automated Tests
```bash
python test_app.py
```

### 4. Start the Flask Server
```bash
python app.py
```
Open your browser and navigate to:
**`http://localhost:5000`**
